# GeoTools

## البناء
**Android Studio:** افتح المجلد ← Sync ← Build ▸ Build APK(s). الملف: `app/build/outputs/apk/debug/app-debug.apk`

**GitHub Actions:** ارفع المشروع إلى مستودع GitHub، ثم Actions ▸ Build APK ▸ حمّل الملف من Artifacts.
