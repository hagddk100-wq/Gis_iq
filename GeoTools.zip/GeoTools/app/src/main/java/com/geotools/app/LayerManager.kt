package com.geotools.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val PALETTE = listOf(
    0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF00ACC1,
    0xFF1E88E5, 0xFF8E24AA, 0xFFD81B60, 0xFF37474F, 0xFF000000
).map { it.toInt() }

private fun layerName(lang: String, key: String) = if (key == "gplaces") tx(lang, "gplaces") else tr(lang, key)

/** Turn layers on/off and change their color, opacity, width and order. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LayerManagerDialog(
    lang: String, styles: Map<String, LayerStyle>,
    onChange: (Map<String, LayerStyle>) -> Unit, onClose: () -> Unit, click: () -> Unit
) {
    val ordered = styles.entries.sortedBy { it.value.order }

    fun put(key: String, s: LayerStyle) {
        val m = LinkedHashMap(styles)
        m[key] = s
        onChange(m)
    }

    fun move(index: Int, delta: Int) {
        val j = index + delta
        if (j < 0 || j >= ordered.size) return
        val a = ordered[index]
        val b = ordered[j]
        val m = LinkedHashMap(styles)
        m[a.key] = LayerStyle(a.value.visible, a.value.color, a.value.alpha, a.value.width, b.value.order)
        m[b.key] = LayerStyle(b.value.visible, b.value.color, b.value.alpha, b.value.width, a.value.order)
        onChange(m)
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tx(lang, "layers")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tx(lang, "layers_hint"), style = MaterialTheme.typography.bodySmall)
                ordered.forEachIndexed { i, e ->
                    val st = e.value
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = st.visible, onCheckedChange = {
                                    click(); put(e.key, LayerStyle(it, st.color, st.alpha, st.width, st.order))
                                })
                                Text(layerName(lang, e.key), Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                                TextButton(onClick = { click(); move(i, -1) }) { Text("\u25B2") }
                                TextButton(onClick = { click(); move(i, 1) }) { Text("\u25BC") }
                            }
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                PALETTE.forEach { c ->
                                    Box(
                                        Modifier.size(28.dp).clip(CircleShape).background(Color(c))
                                            .clickable { click(); put(e.key, LayerStyle(st.visible, c, st.alpha, st.width, st.order)) }
                                    )
                                }
                            }
                            Text(tx(lang, "opacity") + ": " + (st.alpha * 100 / 255) + "%", style = MaterialTheme.typography.labelMedium)
                            Slider(
                                value = st.alpha.toFloat(), valueRange = 20f..255f,
                                onValueChange = { put(e.key, LayerStyle(st.visible, st.color, it.toInt(), st.width, st.order)) }
                            )
                            Text(tx(lang, "width") + ": " + String.format(java.util.Locale.US, "%.0f", st.width), style = MaterialTheme.typography.labelMedium)
                            Slider(
                                value = st.width, valueRange = 2f..14f,
                                onValueChange = { put(e.key, LayerStyle(st.visible, st.color, st.alpha, it, st.order)) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text(tx(lang, "close")) } }
    )
}
