package com.geotools.app

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Calendar
import java.util.Locale

class Attr(
    val name: String, val type: String, val cat: String,
    val district: String, val qada: String, val gov: String,
    val x: Double, val y: Double, val zone: String
)

object ShapefileWriter {
    private const val WKT =
        "GEOGCS[\"GCS_WGS_1984\",DATUM[\"D_WGS_1984\",SPHEROID[\"WGS_1984\",6378137.0,298.257223563]]," +
                "PRIMEM[\"Greenwich\",0.0],UNIT[\"Degree\",0.0174532925199433]]"

    private class Fld(val name: String, val type: Char, val len: Int, val dec: Int)

    private val FIELDS = listOf(
        Fld("NAME", 'C', 80, 0), Fld("TYPE", 'C', 40, 0), Fld("CATEGORY", 'C', 30, 0),
        Fld("DISTRICT", 'C', 60, 0), Fld("QADA", 'C', 60, 0), Fld("GOVERNORAT", 'C', 60, 0),
        Fld("X_UTM", 'N', 18, 2), Fld("Y_UTM", 'N', 18, 2), Fld("UTM_ZONE", 'C', 4, 0)
    )

    fun build(base: String, kind: Kind, feats: List<Feature>, attrs: List<Attr>): Map<String, ByteArray> {
        val shapeType = when (kind) { Kind.POINT -> 1; Kind.LINE -> 3; Kind.POLYGON -> 5 }
        val contents = feats.map { content(kind, shapeType, it) }

        var xmin = Double.MAX_VALUE; var ymin = Double.MAX_VALUE
        var xmax = -Double.MAX_VALUE; var ymax = -Double.MAX_VALUE
        feats.forEach { f -> f.parts.forEach { p -> p.forEach {
            xmin = minOf(xmin, it.lon); xmax = maxOf(xmax, it.lon)
            ymin = minOf(ymin, it.lat); ymax = maxOf(ymax, it.lat)
        } } }

        val shpLen = 100 + contents.sumOf { 8 + it.size }
        val shp = ByteBuffer.allocate(shpLen)
        header(shp, shpLen / 2, shapeType, xmin, ymin, xmax, ymax)
        val shxLen = 100 + 8 * contents.size
        val shx = ByteBuffer.allocate(shxLen)
        header(shx, shxLen / 2, shapeType, xmin, ymin, xmax, ymax)

        var offset = 50
        contents.forEachIndexed { i, c ->
            shp.order(ByteOrder.BIG_ENDIAN).putInt(i + 1).putInt(c.size / 2)
            shp.put(c)
            shx.order(ByteOrder.BIG_ENDIAN).putInt(offset).putInt(c.size / 2)
            offset += 4 + c.size / 2
        }

        return mapOf(
            "$base.shp" to shp.array(),
            "$base.shx" to shx.array(),
            "$base.dbf" to dbf(attrs),
            "$base.prj" to WKT.toByteArray(Charsets.US_ASCII),
            "$base.cpg" to "UTF-8".toByteArray(Charsets.US_ASCII)
        )
    }

    private fun header(b: ByteBuffer, lenWords: Int, type: Int, x0: Double, y0: Double, x1: Double, y1: Double) {
        b.order(ByteOrder.BIG_ENDIAN)
        b.putInt(9994)
        repeat(5) { b.putInt(0) }
        b.putInt(lenWords)
        b.order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(1000)
        b.putInt(type)
        b.putDouble(x0); b.putDouble(y0); b.putDouble(x1); b.putDouble(y1)
        repeat(4) { b.putDouble(0.0) }
    }

    private fun content(kind: Kind, shapeType: Int, f: Feature): ByteArray {
        if (kind == Kind.POINT) {
            val p = f.parts[0][0]
            return ByteBuffer.allocate(20).order(ByteOrder.LITTLE_ENDIAN)
                .putInt(shapeType).putDouble(p.lon).putDouble(p.lat).array()
        }
        val parts = if (kind == Kind.POLYGON) f.parts.map { clockwise(it) } else f.parts
        val n = parts.sumOf { it.size }
        var x0 = Double.MAX_VALUE; var y0 = Double.MAX_VALUE
        var x1 = -Double.MAX_VALUE; var y1 = -Double.MAX_VALUE
        parts.forEach { p -> p.forEach {
            x0 = minOf(x0, it.lon); x1 = maxOf(x1, it.lon)
            y0 = minOf(y0, it.lat); y1 = maxOf(y1, it.lat)
        } }
        val bb = ByteBuffer.allocate(44 + 4 * parts.size + 16 * n).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(shapeType)
        bb.putDouble(x0); bb.putDouble(y0); bb.putDouble(x1); bb.putDouble(y1)
        bb.putInt(parts.size); bb.putInt(n)
        var idx = 0
        parts.forEach { bb.putInt(idx); idx += it.size }
        parts.forEach { p -> p.forEach { bb.putDouble(it.lon); bb.putDouble(it.lat) } }
        return bb.array()
    }

    private fun clockwise(ring: List<Ll>): List<Ll> {
        var area = 0.0
        for (i in 0 until ring.size - 1) {
            area += ring[i].lon * ring[i + 1].lat - ring[i + 1].lon * ring[i].lat
        }
        return if (area > 0) ring.reversed() else ring
    }

    private fun dbf(rows: List<Attr>): ByteArray {
        val recLen = 1 + FIELDS.sumOf { it.len }
        val hdrLen = 32 + 32 * FIELDS.size + 1
        val out = ByteArrayOutputStream()
        val cal = Calendar.getInstance()
        val h = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN)
        h.put(3.toByte())
        h.put((cal.get(Calendar.YEAR) - 1900).toByte())
        h.put((cal.get(Calendar.MONTH) + 1).toByte())
        h.put(cal.get(Calendar.DAY_OF_MONTH).toByte())
        h.putInt(rows.size)
        h.putShort(hdrLen.toShort())
        h.putShort(recLen.toShort())
        out.write(h.array())
        for (f in FIELDS) {
            val d = ByteArray(32)
            f.name.toByteArray(Charsets.US_ASCII).copyInto(d)
            d[11] = f.type.code.toByte()
            d[16] = f.len.toByte()
            d[17] = f.dec.toByte()
            out.write(d)
        }
        out.write(0x0D)
        for (r in rows) {
            out.write(0x20)
            out.write(cfield(r.name, 80)); out.write(cfield(r.type, 40)); out.write(cfield(r.cat, 30))
            out.write(cfield(r.district, 60)); out.write(cfield(r.qada, 60)); out.write(cfield(r.gov, 60))
            out.write(nfield(r.x, 18)); out.write(nfield(r.y, 18)); out.write(cfield(r.zone, 4))
        }
        out.write(0x1A)
        return out.toByteArray()
    }

    private fun cfield(s: String, len: Int): ByteArray {
        val b = s.toByteArray(Charsets.UTF_8)
        var l = minOf(len, b.size)
        if (l < b.size) while (l > 0 && (b[l].toInt() and 0xC0) == 0x80) l--
        val r = ByteArray(len) { 0x20 }
        b.copyInto(r, 0, 0, l)
        return r
    }

    private fun nfield(v: Double, len: Int): ByteArray =
        String.format(Locale.US, "%${len}.2f", v).toByteArray(Charsets.US_ASCII)
}
