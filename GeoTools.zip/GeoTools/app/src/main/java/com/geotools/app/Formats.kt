package com.geotools.app

import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

fun xmlEsc(s: String): String {
    val sb = StringBuilder()
    for (ch in s) {
        if (ch.code < 0x20 && ch != '\n' && ch != '\t') continue
        when (ch) {
            '&' -> sb.append("&amp;")
            '<' -> sb.append("&lt;")
            '>' -> sb.append("&gt;")
            '"' -> sb.append("&quot;")
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}

/** Google Maps link to a position. */
fun mapLink(c: Ll): String = "https://www.google.com/maps?q=" + String.format(Locale.US, "%.6f,%.6f", c.lat, c.lon)

fun catLabel(f: Feature, lang: String): String {
    val base = tr(lang, f.cat.key)
    if (f.sub.isEmpty()) return base
    return base + " - " + (if (f.cat == Cat.PLACES) tr(lang, f.sub) else f.sub)
}

fun featureCenter(f: Feature): Ll {
    val p = f.parts[0]
    return Ll(p.map { it.lat }.average(), p.map { it.lon }.average())
}

private fun zipOf(entries: List<Pair<String, String>>): ByteArray {
    val bo = ByteArrayOutputStream()
    ZipOutputStream(bo).use { z ->
        for ((n, s) in entries) {
            z.putNextEntry(ZipEntry(n))
            z.write(s.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }
    return bo.toByteArray()
}

object Xlsx {
    private const val NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private val COLS = listOf("name", "type", "Gategory", "gather", "Nahia", "mohafadha", "x", "y", "link")

    private fun str(ref: String, v: String, style: Int = 0): String =
        "<c r=\"$ref\" t=\"inlineStr\"" + (if (style > 0) " s=\"$style\"" else "") +
                "><is><t xml:space=\"preserve\">" + xmlEsc(v) + "</t></is></c>"

    private fun num(ref: String, v: String): String = "<c r=\"$ref\"><v>$v</v></c>"

    fun build(feats: List<Feature>, admin: Admin, zone: Int, lang: String, idx: AdminIndex? = null): ByteArray {
        val sb = StringBuilder()
        sb.append(HEAD).append("<worksheet xmlns=\"$NS\">")
        sb.append("<sheetViews><sheetView workbookViewId=\"0\"")
            .append(if (lang == "ar") " rightToLeft=\"1\"" else "").append("/></sheetViews>")
        sb.append("<cols><col min=\"1\" max=\"1\" width=\"34\" customWidth=\"1\"/>")
            .append("<col min=\"2\" max=\"6\" width=\"18\" customWidth=\"1\"/>")
            .append("<col min=\"7\" max=\"8\" width=\"16\" customWidth=\"1\"/>")
            .append("<col min=\"9\" max=\"9\" width=\"60\" customWidth=\"1\"/></cols>")
        sb.append("<sheetData><row r=\"1\">")
        COLS.forEachIndexed { i, h -> sb.append(str("${'A' + i}1", h, 1)) }
        sb.append("</row>")
        feats.forEachIndexed { idxRow, f ->
            val r = idxRow + 2
            val c = featureCenter(f)
            val u = GeoConverter.toUtm(c.lat, c.lon, zone)
            val (qd, nh) = idx?.of(f) ?: (admin.qada to admin.district)
            val cells: List<Pair<Boolean, String>> = listOf(
                false to f.name, false to f.type, false to catLabel(f, lang), false to qd, false to nh,
                false to admin.gov,
                true to String.format(Locale.US, "%.2f", u.e), true to String.format(Locale.US, "%.2f", u.n),
                false to mapLink(c)
            )
            sb.append("<row r=\"$r\">")
            cells.forEachIndexed { i, (isNum, v) ->
                val ref = "${'A' + i}$r"
                sb.append(if (isNum) num(ref, v) else str(ref, v))
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")

        val ct = HEAD + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "</Types>"
        val rels = HEAD + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>"
        val wb = HEAD + "<workbook xmlns=\"$NS\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"Features\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
        val wbRels = HEAD + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>"
        val styles = HEAD + "<styleSheet xmlns=\"$NS\">" +
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>" +
                "</styleSheet>"
        return zipOf(listOf(
            "[Content_Types].xml" to ct,
            "_rels/.rels" to rels,
            "xl/workbook.xml" to wb,
            "xl/_rels/workbook.xml.rels" to wbRels,
            "xl/styles.xml" to styles,
            "xl/worksheets/sheet1.xml" to sb.toString()
        ))
    }
}

object Kml {
    // KML colors are aabbggrr
    private fun color(c: Cat): String = when (c) {
        Cat.ROADS_MAIN -> "ff3539e5"
        Cat.ROADS_SEC -> "ff008cfb"
        Cat.LAKES -> "ffe5881e"
        Cat.RIVERS -> "ffc1ac00"
        Cat.DAMS -> "ff414c6d"
        Cat.TOURIST -> "ffaa248e"
        Cat.ADMIN -> "ff47a043"
        Cat.AREAS -> "ffb2355e"
        Cat.RAIL -> "ff4f4737"
        Cat.PLACES -> "ff7b8900"
        Cat.USER -> "ff601bd8"
    }

    private fun coords(p: List<Ll>) =
        p.joinToString(" ") { String.format(Locale.US, "%.7f,%.7f,0", it.lon, it.lat) }

    private fun geometry(f: Feature): String {
        val parts: List<String> = when (f.kind) {
            Kind.POINT -> listOf("<Point><coordinates>${coords(f.parts[0].take(1))}</coordinates></Point>")
            Kind.LINE -> f.parts.map { "<LineString><tessellate>1</tessellate><coordinates>${coords(it)}</coordinates></LineString>" }
            Kind.POLYGON -> f.parts.map {
                "<Polygon><outerBoundaryIs><LinearRing><coordinates>${coords(it)}</coordinates></LinearRing></outerBoundaryIs></Polygon>"
            }
        }
        return if (parts.size == 1) parts[0] else "<MultiGeometry>" + parts.joinToString("") + "</MultiGeometry>"
    }

    private fun data(k: String, v: String) = "<Data name=\"$k\"><value>${xmlEsc(v)}</value></Data>"

    fun build(feats: List<Feature>, admin: Admin, zone: Int, lang: String, idx: AdminIndex? = null): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>GeoTools</name>")
        Cat.values().forEach { c ->
            sb.append("<Style id=\"s_${c.key}\"><LineStyle><color>${color(c)}</color><width>3</width></LineStyle>")
                .append("<PolyStyle><color>66${color(c).substring(2)}</color></PolyStyle></Style>")
        }
        feats.groupBy { it.cat }.forEach { (cat, list) ->
            sb.append("<Folder><name>${xmlEsc(tr(lang, cat.key))}</name>")
            list.forEach { f ->
                val c = featureCenter(f)
                val u = GeoConverter.toUtm(c.lat, c.lon, zone)
                val (qd, nh) = idx?.of(f) ?: (admin.qada to admin.district)
                sb.append("<Placemark><name>${xmlEsc(f.name.ifEmpty { f.type })}</name>")
                sb.append("<styleUrl>#s_${cat.key}</styleUrl><ExtendedData>")
                sb.append(data("type", f.type)).append(data("Gategory", tr(lang, cat.key)))
                sb.append(data("gather", qd)).append(data("Nahia", nh)).append(data("mohafadha", admin.gov))
                sb.append(data("x", String.format(Locale.US, "%.2f", u.e)))
                sb.append(data("y", String.format(Locale.US, "%.2f", u.n)))
                sb.append(data("link", mapLink(c)))
                sb.append("</ExtendedData>").append(geometry(f)).append("</Placemark>")
            }
            sb.append("</Folder>")
        }
        sb.append("</Document></kml>")
        return sb.toString()
    }

    fun toKmz(kml: String): ByteArray = zipOf(listOf("doc.kml" to kml))
}
