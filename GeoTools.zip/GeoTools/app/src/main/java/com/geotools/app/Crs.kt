package com.geotools.app

import org.locationtech.proj4j.CRSFactory
import org.locationtech.proj4j.CoordinateReferenceSystem
import org.locationtech.proj4j.CoordinateTransform
import org.locationtech.proj4j.CoordinateTransformFactory
import org.locationtech.proj4j.ProjCoordinate

class CrsItem(val code: Int, val ar: String, val en: String) {
    fun label(lang: String) = "EPSG:$code  " + if (lang == "ar") ar else en
}

/**
 * Coordinate reference systems through the Proj4J library (EPSG registry).
 * Convention: x = easting / longitude, y = northing / latitude. The UI shows latitude first for geographic systems.
 */
object Crs {
    val COMMON = listOf(
        CrsItem(4326, "WGS84 جغرافي", "WGS84 geographic"),
        CrsItem(32638, "WGS84 / UTM 38N (بغداد)", "WGS84 / UTM 38N (Baghdad)"),
        CrsItem(32637, "WGS84 / UTM 37N", "WGS84 / UTM 37N"),
        CrsItem(32639, "WGS84 / UTM 39N", "WGS84 / UTM 39N"),
        CrsItem(3857, "Web Mercator", "Web Mercator")
    )

    private val factory = CRSFactory()
    private val ctf = CoordinateTransformFactory()
    private val crsCache = HashMap<Int, CoordinateReferenceSystem>()
    private val trCache = HashMap<Long, CoordinateTransform>()

    @Synchronized
    private fun crs(code: Int): CoordinateReferenceSystem =
        crsCache.getOrPut(code) { factory.createFromName("EPSG:$code") }

    /** EPSG 4000-4999 are geographic (degrees) systems. */
    fun isGeographic(code: Int) = code in 4000..4999

    fun valid(code: Int): Boolean = try { crs(code); true } catch (e: Exception) { false }

    fun name(code: Int): String = try { crs(code).name } catch (e: Exception) { "EPSG:$code" }

    @Synchronized
    fun transform(from: Int, to: Int, x: Double, y: Double): Pair<Double, Double> {
        if (from == to) return x to y
        val t = trCache.getOrPut(from.toLong() * 100000L + to) { ctf.createTransform(crs(from), crs(to)) }
        val out = ProjCoordinate()
        t.transform(ProjCoordinate(x, y), out)
        return out.x to out.y
    }

    fun fromWgs(ll: Ll, to: Int): Pair<Double, Double> = transform(4326, to, ll.lon, ll.lat)

    fun toWgs(from: Int, x: Double, y: Double): Ll {
        val (lon, lat) = transform(from, 4326, x, y)
        return Ll(lat, lon)
    }

    fun decimalsOf(token: String): Int = if (token.contains('.')) token.substringAfter('.').length else 0

    /** Meter decimals worth showing for a geographic value given with [degDecimals] decimals (no false precision). */
    fun metersDecimals(degDecimals: Int): Int {
        val prec = 111320.0 * Math.pow(10.0, -degDecimals.toDouble())
        return Math.max(0, Math.ceil(-Math.log10(prec)).toInt())
    }

    /** Degree decimals worth showing for a projected value given with [meterDecimals] decimals. */
    fun degDecimals(meterDecimals: Int): Int = Math.min(9, 5 + meterDecimals)
}
