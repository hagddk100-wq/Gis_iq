package com.geotools.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import java.security.MessageDigest
import java.util.UUID

object PinStore {
    private fun p(ctx: Context) = ctx.getSharedPreferences("lock", 0)
    fun isSet(ctx: Context) = p(ctx).contains("hash")
    fun length(ctx: Context) = p(ctx).getInt("len", 4)

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { String.format("%02x", it) }

    fun set(ctx: Context, pin: String) {
        val salt = UUID.randomUUID().toString()
        p(ctx).edit().putString("salt", salt).putString("hash", hash(pin, salt)).putInt("len", pin.length).apply()
    }

    fun check(ctx: Context, pin: String): Boolean {
        val pr = p(ctx)
        val salt = pr.getString("salt", null) ?: return false
        return pr.getString("hash", null) == hash(pin, salt)
    }

    fun clear(ctx: Context) {
        p(ctx).edit().clear().apply()
    }
}

@Composable
fun LockScreen(lang: String, onOk: () -> Unit) {
    val ctx = LocalContext.current
    val len = PinStore.length(ctx)
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Surface(
        Modifier.fillMaxSize().pointerInput(Unit) {},
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(tr(lang, "enter_pin"), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(len) { i ->
                    Box(
                        Modifier.size(16.dp).clip(CircleShape).background(
                            if (i < pin.length) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outlineVariant
                        )
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (wrong) tr(lang, "wrong_pin") else " ",
                color = MaterialTheme.colorScheme.error
            )
            Spacer(Modifier.height(12.dp))
            val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "<")
            keys.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    row.forEach { k ->
                        if (k.isEmpty()) {
                            Spacer(Modifier.size(72.dp))
                        } else {
                            FilledTonalButton(
                                onClick = {
                                    wrong = false
                                    if (k == "<") {
                                        pin = pin.dropLast(1)
                                    } else if (pin.length < len) {
                                        pin += k
                                        if (pin.length == len) {
                                            if (PinStore.check(ctx, pin)) onOk() else { wrong = true; pin = "" }
                                        }
                                    }
                                },
                                modifier = Modifier.size(72.dp),
                                shape = CircleShape,
                                contentPadding = PaddingValues(0.dp)
                            ) { Text(k, style = MaterialTheme.typography.headlineSmall) }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun PinField(label: String, v: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = v, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}

private fun digits(s: String) = GeoConverter.normalize(s).filter { it.isDigit() }

@Composable
fun PinDialog(lang: String, mode: String, onDismiss: () -> Unit, onDone: (String) -> Unit) {
    val ctx = LocalContext.current
    var old by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val needOld = mode != "set"
    val needNew = mode != "disable"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(tr(lang, when (mode) { "set" -> "set_pin"; "change" -> "change_pin"; else -> "disable_lock" }))
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (needOld) PinField(tr(lang, "old_pin"), old) { old = it }
                if (needNew) {
                    PinField(tr(lang, "new_pin"), n1) { n1 = it }
                    PinField(tr(lang, "confirm_pin"), n2) { n2 = it }
                }
                if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val o = digits(old); val a = digits(n1); val b = digits(n2)
                val msg = when {
                    needOld && !PinStore.check(ctx, o) -> tr(lang, "wrong_pin")
                    needNew && a.length !in 4..8 -> tr(lang, "pin_len")
                    needNew && a != b -> tr(lang, "pin_mismatch")
                    else -> ""
                }
                if (msg.isEmpty()) onDone(a) else err = msg
            }) { Text(tr(lang, "ok")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr(lang, "cancel")) } }
    )
}
