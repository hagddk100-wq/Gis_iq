package com.geotools.app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class GisProject(val id: String, val name: String, val created: Long, val updated: Long)

/** One feature of a project (point, line or polygon) with its attributes. */
data class GisFeature(
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val name: String,
    val nameEn: String = "",
    val category: String = "",
    val kind: Kind,
    val parts: List<List<Ll>>,
    val gov: String = "",
    val qadha: String = "",
    val nahiya: String = "",
    val description: String = "",
    val notes: String = "",
    val source: String = "",
    val status: String = "new",
    val accuracy: Double = 0.0,
    val props: Map<String, String> = emptyMap(),
    val updated: Long = System.currentTimeMillis()
) {
    fun center(): Ll {
        val all = parts.flatten()
        return Ll(all.map { it.lat }.average(), all.map { it.lon }.average())
    }

    fun toJson(): JSONObject {
        val pj = JSONArray()
        parts.forEach { part ->
            val a = JSONArray()
            part.forEach { a.put(JSONArray().put(it.lat).put(it.lon)) }
            pj.put(a)
        }
        return JSONObject()
            .put("id", id).put("pid", projectId).put("name", name).put("name_en", nameEn).put("cat", category)
            .put("kind", kind.name).put("parts", pj).put("gov", gov).put("qadha", qadha).put("nahiya", nahiya)
            .put("desc", description).put("notes", notes).put("source", source).put("status", status)
            .put("acc", accuracy).put("props", JSONObject(props)).put("upd", updated)
    }

    companion object {
        fun fromJson(o: JSONObject): GisFeature {
            val pa = o.getJSONArray("parts")
            val parts = (0 until pa.length()).map { i ->
                val a = pa.getJSONArray(i)
                (0 until a.length()).map { j -> Ll(a.getJSONArray(j).getDouble(0), a.getJSONArray(j).getDouble(1)) }
            }
            val pr = o.optJSONObject("props")
            val props = LinkedHashMap<String, String>()
            if (pr != null) {
                val ks = pr.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    props[k] = pr.optString(k)
                }
            }
            return GisFeature(
                id = o.getString("id"), projectId = o.getString("pid"), name = o.optString("name"),
                nameEn = o.optString("name_en"), category = o.optString("cat"),
                kind = Kind.valueOf(o.getString("kind")), parts = parts,
                gov = o.optString("gov"), qadha = o.optString("qadha"), nahiya = o.optString("nahiya"),
                description = o.optString("desc"), notes = o.optString("notes"), source = o.optString("source"),
                status = o.optString("status", "new"), accuracy = o.optDouble("acc", 0.0), props = props,
                updated = o.optLong("upd", System.currentTimeMillis())
            )
        }
    }
}

/**
 * Local SQLite store: projects, features (with a bounding-box index for fast area queries)
 * and an edit history that supports undo / redo.
 */
class GisDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "gis.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE projects(id TEXT PRIMARY KEY, name TEXT NOT NULL, created INTEGER, updated INTEGER)")
        db.execSQL(
            "CREATE TABLE features(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, name TEXT, name_en TEXT, category TEXT, " +
                "kind TEXT, coords TEXT, min_lat REAL, min_lon REAL, max_lat REAL, max_lon REAL, gov TEXT, qadha TEXT, " +
                "nahiya TEXT, descr TEXT, notes TEXT, source TEXT, status TEXT, accuracy REAL, props TEXT, updated INTEGER)"
        )
        db.execSQL("CREATE INDEX idx_f_proj ON features(project_id)")
        db.execSQL("CREATE INDEX idx_f_bbox ON features(project_id, min_lat, max_lat, min_lon, max_lon)")
        db.execSQL(
            "CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT, feature_id TEXT, action TEXT, " +
                "before_json TEXT, after_json TEXT, ts INTEGER, undone INTEGER DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX idx_h_proj ON history(project_id, id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---------- projects ----------
    fun ensureDefault() {
        val c = readableDatabase.rawQuery("SELECT COUNT(*) FROM projects WHERE id=?", arrayOf(DEFAULT_ID))
        val has = c.use { it.moveToFirst() && it.getInt(0) > 0 }
        if (!has) {
            val now = System.currentTimeMillis()
            val v = ContentValues()
            v.put("id", DEFAULT_ID); v.put("name", "default"); v.put("created", now); v.put("updated", now)
            writableDatabase.insert("projects", null, v)
        }
    }

    fun projects(): List<GisProject> {
        ensureDefault()
        val out = ArrayList<GisProject>()
        readableDatabase.rawQuery("SELECT id, name, created, updated FROM projects ORDER BY created", null).use { c ->
            while (c.moveToNext()) out.add(GisProject(c.getString(0), c.getString(1), c.getLong(2), c.getLong(3)))
        }
        return out
    }

    fun createProject(name: String): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val v = ContentValues()
        v.put("id", id); v.put("name", name); v.put("created", now); v.put("updated", now)
        writableDatabase.insert("projects", null, v)
        return id
    }

    fun renameProject(id: String, name: String) {
        val v = ContentValues()
        v.put("name", name); v.put("updated", System.currentTimeMillis())
        writableDatabase.update("projects", v, "id=?", arrayOf(id))
    }

    fun deleteProject(id: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("features", "project_id=?", arrayOf(id))
            db.delete("history", "project_id=?", arrayOf(id))
            if (id != DEFAULT_ID) db.delete("projects", "id=?", arrayOf(id))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun count(pid: String): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM features WHERE project_id=?", arrayOf(pid)).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    // ---------- features ----------
    private fun cv(f: GisFeature): ContentValues {
        val all = f.parts.flatten()
        val pj = JSONArray()
        f.parts.forEach { part ->
            val a = JSONArray()
            part.forEach { a.put(JSONArray().put(it.lat).put(it.lon)) }
            pj.put(a)
        }
        val v = ContentValues()
        v.put("id", f.id); v.put("project_id", f.projectId); v.put("name", f.name); v.put("name_en", f.nameEn)
        v.put("category", f.category); v.put("kind", f.kind.name); v.put("coords", pj.toString())
        v.put("min_lat", all.minOf { it.lat }); v.put("min_lon", all.minOf { it.lon })
        v.put("max_lat", all.maxOf { it.lat }); v.put("max_lon", all.maxOf { it.lon })
        v.put("gov", f.gov); v.put("qadha", f.qadha); v.put("nahiya", f.nahiya)
        v.put("descr", f.description); v.put("notes", f.notes); v.put("source", f.source); v.put("status", f.status)
        v.put("accuracy", f.accuracy); v.put("props", JSONObject(f.props).toString()); v.put("updated", f.updated)
        return v
    }

    private fun row(c: Cursor): GisFeature {
        val pa = JSONArray(c.getString(6))
        val parts = (0 until pa.length()).map { i ->
            val a = pa.getJSONArray(i)
            (0 until a.length()).map { j -> Ll(a.getJSONArray(j).getDouble(0), a.getJSONArray(j).getDouble(1)) }
        }
        val props = LinkedHashMap<String, String>()
        try {
            val pr = JSONObject(c.getString(19) ?: "{}")
            pr.keys().forEach { k -> props[k] = pr.optString(k) }
        } catch (e: Exception) {
        }
        return GisFeature(
            id = c.getString(0), projectId = c.getString(1), name = c.getString(2) ?: "", nameEn = c.getString(3) ?: "",
            category = c.getString(4) ?: "", kind = Kind.valueOf(c.getString(5)), parts = parts,
            gov = c.getString(11) ?: "", qadha = c.getString(12) ?: "", nahiya = c.getString(13) ?: "",
            description = c.getString(14) ?: "", notes = c.getString(15) ?: "", source = c.getString(16) ?: "",
            status = c.getString(17) ?: "new", accuracy = c.getDouble(18), props = props, updated = c.getLong(20)
        )
    }

    private val COLS = "id, project_id, name, name_en, category, kind, coords, min_lat, min_lon, max_lat, max_lon, " +
        "gov, qadha, nahiya, descr, notes, source, status, accuracy, props, updated"

    fun get(id: String): GisFeature? =
        readableDatabase.rawQuery("SELECT $COLS FROM features WHERE id=?", arrayOf(id)).use { if (it.moveToFirst()) row(it) else null }

    fun features(pid: String, query: String = "", status: String? = null, limit: Int = -1): List<GisFeature> {
        val args = ArrayList<String>()
        var sql = "SELECT $COLS FROM features WHERE project_id=?"
        args.add(pid)
        if (query.isNotBlank()) {
            sql += " AND (name LIKE ? OR name_en LIKE ? OR category LIKE ? OR descr LIKE ? OR qadha LIKE ? OR nahiya LIKE ? OR gov LIKE ?)"
            val q = "%" + query.trim() + "%"
            repeat(7) { args.add(q) }
        }
        if (status != null) {
            sql += " AND status=?"
            args.add(status)
        }
        sql += " ORDER BY updated DESC"
        if (limit > 0) sql += " LIMIT $limit"
        val out = ArrayList<GisFeature>()
        readableDatabase.rawQuery(sql, args.toTypedArray()).use { c -> while (c.moveToNext()) out.add(row(c)) }
        return out
    }

    /** Features whose bounding box touches the given box (uses the bbox index). */
    fun featuresIn(pid: String, minLat: Double, minLon: Double, maxLat: Double, maxLon: Double): List<GisFeature> {
        val out = ArrayList<GisFeature>()
        readableDatabase.rawQuery(
            "SELECT $COLS FROM features WHERE project_id=? AND max_lat>=? AND min_lat<=? AND max_lon>=? AND min_lon<=?",
            arrayOf(pid, minLat.toString(), maxLat.toString(), minLon.toString(), maxLon.toString())
        ).use { c -> while (c.moveToNext()) out.add(row(c)) }
        return out
    }

    private fun log(db: SQLiteDatabase, pid: String, fid: String, action: String, before: GisFeature?, after: GisFeature?) {
        db.delete("history", "project_id=? AND undone=1", arrayOf(pid))
        val v = ContentValues()
        v.put("project_id", pid); v.put("feature_id", fid); v.put("action", action)
        v.put("before_json", before?.toJson()?.toString()); v.put("after_json", after?.toJson()?.toString())
        v.put("ts", System.currentTimeMillis())
        db.insert("history", null, v)
    }

    fun insert(f: GisFeature) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict("features", null, cv(f), SQLiteDatabase.CONFLICT_REPLACE)
            log(db, f.projectId, f.id, "insert", null, f)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Adds many features in one transaction (large imports); not recorded in the undo history. */
    fun insertAll(list: List<GisFeature>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            list.forEach { db.insertWithOnConflict("features", null, cv(it), SQLiteDatabase.CONFLICT_REPLACE) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun update(f: GisFeature) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val before = get(f.id)
            val after = f.copy(updated = System.currentTimeMillis())
            db.insertWithOnConflict("features", null, cv(after), SQLiteDatabase.CONFLICT_REPLACE)
            log(db, f.projectId, f.id, "update", before, after)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun delete(id: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val before = get(id)
            if (before != null) {
                db.delete("features", "id=?", arrayOf(id))
                log(db, before.projectId, id, "delete", before, null)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // ---------- undo / redo ----------
    fun canUndo(pid: String): Boolean =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM history WHERE project_id=? AND undone=0", arrayOf(pid)).use { it.moveToFirst() && it.getInt(0) > 0 }

    fun canRedo(pid: String): Boolean =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM history WHERE project_id=? AND undone=1", arrayOf(pid)).use { it.moveToFirst() && it.getInt(0) > 0 }

    private class Entry(val id: Long, val action: String, val before: GisFeature?, val after: GisFeature?)

    private fun entry(sql: String, pid: String): Entry? =
        readableDatabase.rawQuery(sql, arrayOf(pid)).use { c ->
            if (!c.moveToFirst()) null
            else Entry(
                c.getLong(0), c.getString(1),
                c.getString(2)?.let { GisFeature.fromJson(JSONObject(it)) },
                c.getString(3)?.let { GisFeature.fromJson(JSONObject(it)) }
            )
        }

    private fun put(db: SQLiteDatabase, f: GisFeature) {
        db.insertWithOnConflict("features", null, cv(f), SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun undo(pid: String): Boolean {
        val e = entry("SELECT id, action, before_json, after_json FROM history WHERE project_id=? AND undone=0 ORDER BY id DESC LIMIT 1", pid) ?: return false
        val db = writableDatabase
        db.beginTransaction()
        try {
            when (e.action) {
                "insert" -> e.after?.let { db.delete("features", "id=?", arrayOf(it.id)) }
                else -> e.before?.let { put(db, it) }
            }
            db.execSQL("UPDATE history SET undone=1 WHERE id=?", arrayOf<Any>(e.id))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return true
    }

    fun redo(pid: String): Boolean {
        val e = entry("SELECT id, action, before_json, after_json FROM history WHERE project_id=? AND undone=1 ORDER BY id ASC LIMIT 1", pid) ?: return false
        val db = writableDatabase
        db.beginTransaction()
        try {
            when (e.action) {
                "delete" -> e.before?.let { db.delete("features", "id=?", arrayOf(it.id)) }
                else -> e.after?.let { put(db, it) }
            }
            db.execSQL("UPDATE history SET undone=0 WHERE id=?", arrayOf<Any>(e.id))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return true
    }

    // ---------- features drawn on the map ----------
    /** Mirrors the features drawn on the map into the default project (keeps edits made to them in the project). */
    fun syncMapFeatures(list: List<Feature>) {
        ensureDefault()
        val existing = HashMap<String, GisFeature>()
        features(DEFAULT_ID).filter { it.source == "map" }.forEach { existing[it.id] = it }
        val keep = HashSet<String>()
        val db = writableDatabase
        db.beginTransaction()
        try {
            list.forEach { f ->
                if (f.parts.isEmpty() || f.parts[0].isEmpty()) return@forEach
                val part = f.parts[0]
                val key = f.kind.name + "|" + f.name + "|" + part.joinToString(";") { "${it.lat},${it.lon}" }
                val id = "map-" + UUID.nameUUIDFromBytes(key.toByteArray()).toString()
                keep.add(id)
                val old = existing[id]
                if (old == null) {
                    put(db, GisFeature(id = id, projectId = DEFAULT_ID, name = f.name, kind = f.kind, parts = listOf(part), source = "map"))
                }
            }
            existing.keys.filter { it !in keep }.forEach { db.delete("features", "id=?", arrayOf(it)) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // ---------- backup / restore ----------
    fun exportJson(): String {
        val pa = JSONArray()
        projects().forEach { pa.put(JSONObject().put("id", it.id).put("name", it.name).put("created", it.created).put("updated", it.updated)) }
        val fa = JSONArray()
        projects().forEach { p -> features(p.id).forEach { fa.put(it.toJson()) } }
        return JSONObject().put("app", "GeoTools").put("version", 1).put("projects", pa).put("features", fa).toString()
    }

    /** Counts (projects, features) inside a backup without changing anything. */
    fun peekJson(text: String): Pair<Int, Int> {
        val o = JSONObject(text)
        require(o.optString("app") == "GeoTools")
        return o.getJSONArray("projects").length() to o.getJSONArray("features").length()
    }

    /** Merges a backup into the database; existing data is never deleted. */
    fun importJson(text: String): Pair<Int, Int> {
        val o = JSONObject(text)
        require(o.optString("app") == "GeoTools")
        val pa = o.getJSONArray("projects")
        val fa = o.getJSONArray("features")
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (i in 0 until pa.length()) {
                val p = pa.getJSONObject(i)
                val v = ContentValues()
                v.put("id", p.getString("id")); v.put("name", p.getString("name"))
                v.put("created", p.optLong("created")); v.put("updated", p.optLong("updated"))
                db.insertWithOnConflict("projects", null, v, SQLiteDatabase.CONFLICT_REPLACE)
            }
            for (i in 0 until fa.length()) put(db, GisFeature.fromJson(fa.getJSONObject(i)))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return pa.length() to fa.length()
    }

    companion object {
        const val DEFAULT_ID = "default"

        @Volatile
        private var inst: GisDb? = null

        fun get(ctx: Context): GisDb = inst ?: synchronized(this) { inst ?: GisDb(ctx).also { inst = it } }
    }
}
