package com.geotools.app

enum class Kind { POINT, LINE, POLYGON }

enum class Cat(val key: String) {
    ROADS_MAIN("roads_main"), ROADS_SEC("roads_sec"), RAIL("rail"), LAKES("lakes"), RIVERS("rivers"),
    DAMS("dams"), TOURIST("tourist"), PLACES("places"), ADMIN("admin"), AREAS("areas"), USER("user")
}

class Feature(
    val cat: Cat,
    val kind: Kind,
    val name: String,
    val type: String,
    val parts: List<List<Ll>>,
    val owner: String = "",
    val sub: String = ""
)

/** Selection rectangle; s/w/n/e is the unrotated box, [rot] rotates it clockwise (degrees) around its center. */
data class Rect(val s: Double, val w: Double, val n: Double, val e: Double, val rot: Double = 0.0)

data class Admin(val gov: String = "", val qada: String = "", val district: String = "")

fun boxAround(c: Ll, wMeters: Double, hMeters: Double): Rect {
    val dLat = hMeters / 2 / 111320.0
    val dLon = wMeters / 2 / (111320.0 * Math.cos(Math.toRadians(c.lat)).coerceAtLeast(0.01))
    return Rect(c.lat - dLat, c.lon - dLon, c.lat + dLat, c.lon + dLon)
}

const val M_LAT = 111320.0
fun mLon(latDeg: Double) = M_LAT * Math.cos(Math.toRadians(latDeg)).coerceAtLeast(0.01)

/** Corners NW, NE, SE, SW of the (possibly rotated) rectangle. */
fun rectCorners(r: Rect): List<Ll> {
    val cLat = (r.s + r.n) / 2
    val cLon = (r.w + r.e) / 2
    val ml = mLon(cLat)
    val hw = (r.e - r.w) / 2 * ml
    val hh = (r.n - r.s) / 2 * M_LAT
    val a = Math.toRadians(r.rot)
    val cs = Math.cos(a)
    val sn = Math.sin(a)
    return listOf(-hw to hh, hw to hh, hw to -hh, -hw to -hh).map { (x, y) ->
        Ll(cLat + (-x * sn + y * cs) / M_LAT, cLon + (x * cs + y * sn) / ml)
    }
}

fun pointInPoly(p: Ll, poly: List<Ll>): Boolean = inPoly(p, poly)

private fun inPoly(p: Ll, poly: List<Ll>): Boolean {
    var inside = false
    var j = poly.size - 1
    for (i in poly.indices) {
        val a = poly[i]
        val b = poly[j]
        if ((a.lat > p.lat) != (b.lat > p.lat) &&
            p.lon < (b.lon - a.lon) * (p.lat - a.lat) / (b.lat - a.lat) + a.lon
        ) inside = !inside
        j = i
    }
    return inside
}

private fun orient(a: Ll, b: Ll, c: Ll) = (b.lon - a.lon) * (c.lat - a.lat) - (b.lat - a.lat) * (c.lon - a.lon)

private fun segCross(a: Ll, b: Ll, c: Ll, d: Ll): Boolean {
    val o1 = orient(a, b, c)
    val o2 = orient(a, b, d)
    val o3 = orient(c, d, a)
    val o4 = orient(c, d, b)
    return (o1 > 0) != (o2 > 0) && (o3 > 0) != (o4 > 0)
}

/** True when the feature touches the (rotated) rectangle. */
fun touchesRect(f: Feature, r: Rect): Boolean {
    val quad = rectCorners(r)
    val center = Ll((r.s + r.n) / 2, (r.w + r.e) / 2)
    for (part in f.parts) {
        if (part.any { inPoly(it, quad) }) return true
        for (i in 0 until part.size - 1) {
            for (k in 0 until 4) if (segCross(part[i], part[i + 1], quad[k], quad[(k + 1) % 4])) return true
        }
        if (f.kind == Kind.POLYGON && part.size >= 4 && inPoly(center, part)) return true
    }
    return false
}

/** Bounding box (with a small margin) around the centers of the features. */
fun boundsOf(feats: List<Feature>): Rect {
    var s = 90.0
    var w = 180.0
    var n = -90.0
    var e = -180.0
    for (f in feats) {
        val c = featureCenter(f)
        s = Math.min(s, c.lat); n = Math.max(n, c.lat)
        w = Math.min(w, c.lon); e = Math.max(e, c.lon)
    }
    val pad = 0.003
    return Rect(s - pad, w - pad, n + pad, e + pad)
}
