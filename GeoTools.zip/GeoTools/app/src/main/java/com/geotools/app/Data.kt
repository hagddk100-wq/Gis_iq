package com.geotools.app

enum class Kind { POINT, LINE, POLYGON }

enum class Cat(val key: String) {
    ROADS_MAIN("roads_main"), ROADS_SEC("roads_sec"), RAIL("rail"), LAKES("lakes"), RIVERS("rivers"),
    DAMS("dams"), TOURIST("tourist"), PLACES("places"), ADMIN("admin"), USER("user")
}

class Feature(
    val cat: Cat,
    val kind: Kind,
    val name: String,
    val type: String,
    val parts: List<List<Ll>>,
    val owner: String = "",
    val sub: String = ""
)

data class Rect(val s: Double, val w: Double, val n: Double, val e: Double)

data class Admin(val gov: String = "", val qada: String = "", val district: String = "")

fun boxAround(c: Ll, wMeters: Double, hMeters: Double): Rect {
    val dLat = hMeters / 2 / 111320.0
    val dLon = wMeters / 2 / (111320.0 * Math.cos(Math.toRadians(c.lat)).coerceAtLeast(0.01))
    return Rect(c.lat - dLat, c.lon - dLon, c.lat + dLat, c.lon + dLon)
}
