package com.geotools.app

import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.MapTileIndex
import java.net.HttpURLConnection
import java.net.URL

/** Google maps through the official Map Tiles API (needs an API key with Map Tiles API enabled). */
object GoogleTiles {
    private const val BASE = "https://tile.googleapis.com/v1/2dtiles/"

    /** kind: 0 roadmap, 1 satellite, 2 hybrid (satellite + roads layer), 3 terrain + roads layer. */
    fun source(key: String, kind: Int, lang: String): ITileSource {
        val mapType = when (kind) { 0 -> "roadmap"; 1, 2 -> "satellite"; else -> "terrain" }
        val body = JSONObject()
            .put("mapType", mapType)
            .put("language", if (lang == "ar") "ar" else "en-US")
            .put("region", "IQ")
        if (kind >= 2) body.put("layerTypes", JSONArray().put("layerRoadmap"))
        val conn = URL("https://tile.googleapis.com/v1/createSession?key=" + java.net.URLEncoder.encode(key, "UTF-8"))
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        if (conn.responseCode != 200) {
            val err = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val msg = try { JSONObject(err).getJSONObject("error").getString("message") } catch (e: Exception) { err.take(200) }
            throw RuntimeException("Google ${conn.responseCode}: $msg")
        }
        val session = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }).getString("session")
        val name = "GoogleTiles_$kind"
        return object : OnlineTileSourceBase(name, 0, 22, 256, ".png", arrayOf(BASE), "\u00A9 Google") {
            override fun getTileURLString(pMapTileIndex: Long): String {
                val z = MapTileIndex.getZoom(pMapTileIndex)
                val x = MapTileIndex.getX(pMapTileIndex)
                val y = MapTileIndex.getY(pMapTileIndex)
                return "$BASE$z/$x/$y?session=$session&key=$key"
            }
        }
    }
}
