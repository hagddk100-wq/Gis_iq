package com.geotools.app

import java.util.Locale
import kotlin.math.*

data class Ll(val lat: Double, val lon: Double)
data class Utm(val zone: Int, val north: Boolean, val e: Double, val n: Double)

object GeoConverter {
    private const val A = 6378137.0
    private const val F = 1 / 298.257223563
    private const val K0 = 0.9996
    private val E2 = F * (2 - F)
    private val EP2 = E2 / (1 - E2)
    private const val BANDS = "CDEFGHJKLMNPQRSTUVWX"
    private val COLS = arrayOf("ABCDEFGH", "JKLMNPQR", "STUVWXYZ")
    private const val ROWS = "ABCDEFGHJKLMNPQRSTUV"

    fun zoneOf(lon: Double) = (floor((lon + 180) / 6).toInt() + 1).coerceIn(1, 60)
    private fun lon0(zone: Int) = Math.toRadians((zone - 1) * 6 - 180 + 3.0)

    fun toUtm(lat: Double, lon: Double, forceZone: Int? = null): Utm {
        val zone = forceZone ?: zoneOf(lon)
        val phi = Math.toRadians(lat)
        val lam = Math.toRadians(lon) - lon0(zone)
        val s = sin(phi); val c = cos(phi); val tn = tan(phi)
        val nn = A / sqrt(1 - E2 * s * s)
        val t = tn * tn
        val cc = EP2 * c * c
        val a = c * lam
        val e2 = E2; val e4 = e2 * e2; val e6 = e4 * e2
        val m = A * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi -
                (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * sin(2 * phi) +
                (15 * e4 / 256 + 45 * e6 / 1024) * sin(4 * phi) -
                (35 * e6 / 3072) * sin(6 * phi))
        val x = K0 * nn * (a + (1 - t + cc) * a.pow(3) / 6 +
                (5 - 18 * t + t * t + 72 * cc - 58 * EP2) * a.pow(5) / 120) + 500000.0
        var y = K0 * (m + nn * tn * (a * a / 2 + (5 - t + 9 * cc + 4 * cc * cc) * a.pow(4) / 24 +
                (61 - 58 * t + t * t + 600 * cc - 330 * EP2) * a.pow(6) / 720))
        if (lat < 0) y += 10000000.0
        return Utm(zone, lat >= 0, x, y)
    }

    fun fromUtm(zone: Int, north: Boolean, easting: Double, northing: Double): Ll {
        val x = easting - 500000.0
        val y = if (north) northing else northing - 10000000.0
        val e2 = E2; val e4 = e2 * e2; val e6 = e4 * e2
        val m = y / K0
        val mu = m / (A * (1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256))
        val e1 = (1 - sqrt(1 - e2)) / (1 + sqrt(1 - e2))
        val phi1 = mu + (3 * e1 / 2 - 27 * e1.pow(3) / 32) * sin(2 * mu) +
                (21 * e1 * e1 / 16 - 55 * e1.pow(4) / 32) * sin(4 * mu) +
                (151 * e1.pow(3) / 96) * sin(6 * mu) +
                (1097 * e1.pow(4) / 512) * sin(8 * mu)
        val s = sin(phi1); val c = cos(phi1); val tn = tan(phi1)
        val n1 = A / sqrt(1 - e2 * s * s)
        val t1 = tn * tn
        val c1 = EP2 * c * c
        val r1 = A * (1 - e2) / (1 - e2 * s * s).pow(1.5)
        val d = x / (n1 * K0)
        val lat = phi1 - (n1 * tn / r1) * (d * d / 2 -
                (5 + 3 * t1 + 10 * c1 - 4 * c1 * c1 - 9 * EP2) * d.pow(4) / 24 +
                (61 + 90 * t1 + 298 * c1 + 45 * t1 * t1 - 252 * EP2 - 3 * c1 * c1) * d.pow(6) / 720)
        val lon = lon0(zone) + (d - (1 + 2 * t1 + c1) * d.pow(3) / 6 +
                (5 - 2 * c1 + 28 * t1 - 3 * c1 * c1 + 8 * EP2 + 24 * t1 * t1) * d.pow(5) / 120) / c
        return Ll(Math.toDegrees(lat), Math.toDegrees(lon))
    }

    fun fmtUtm(u: Utm) =
        "${u.zone}${if (u.north) "N" else "S"} ${u.e.roundToLong()} ${u.n.roundToLong()}"

    fun toMgrs(lat: Double, lon: Double): String {
        val u = toUtm(lat, lon)
        val bi = floor((lat + 80) / 8).toInt().coerceIn(0, 19)
        val ci = (floor(u.e / 100000).toInt() - 1).coerceIn(0, 7)
        val col = COLS[(u.zone - 1) % 3][ci]
        val ri = ((floor(u.n / 100000).toLong() + (if (u.zone % 2 == 0) 5 else 0)) % 20).toInt()
        val ee = floor(u.e % 100000).toLong()
        val nn = floor(u.n % 100000).toLong()
        return String.format(Locale.US, "%d%c %c%c %05d %05d", u.zone, BANDS[bi], col, ROWS[ri], ee, nn)
    }

    fun mgrsToLatLon(input: String): Ll {
        val t = normalize(input).uppercase().replace(" ", "")
        val m = Regex("^(\\d{1,2})([C-HJ-NP-X])([A-HJ-NP-Z])([A-HJ-NP-V])(\\d*)$").matchEntire(t)
            ?: throw IllegalArgumentException("MGRS")
        val zone = m.groupValues[1].toInt()
        val band = m.groupValues[2][0]
        val col = m.groupValues[3][0]
        val row = m.groupValues[4][0]
        val digits = m.groupValues[5]
        require(zone in 1..60 && digits.length % 2 == 0 && digits.length <= 10)
        val half = digits.length / 2
        val scale = 10.0.pow(5 - half)
        val e = if (half == 0) 0.0 else digits.substring(0, half).toDouble() * scale
        val n = if (half == 0) 0.0 else digits.substring(half).toDouble() * scale
        val ci = COLS[(zone - 1) % 3].indexOf(col)
        require(ci >= 0)
        val easting = (ci + 1) * 100000.0 + e
        var ri = ROWS.indexOf(row)
        if (zone % 2 == 0) ri = (ri - 5 + 20) % 20
        val bandIdx = BANDS.indexOf(band)
        val lat0 = -80.0 + 8 * bandIdx
        val centralLon = (zone - 1) * 6 - 180 + 3.0
        val minN = floor(toUtm(lat0, centralLon, zone).n / 100000) * 100000
        var northing = ri * 100000.0 + n
        while (northing < minN) northing += 2000000.0
        return fromUtm(zone, band >= 'N', easting, northing)
    }

    fun parseUtm(zoneStr: String, e: String, n: String): Ll {
        val z = Regex("^(\\d{1,2})\\s*([A-Z])?$").matchEntire(normalize(zoneStr).uppercase().trim())
            ?: throw IllegalArgumentException("UTM")
        val zone = z.groupValues[1].toInt()
        require(zone in 1..60)
        val letter = z.groupValues[2]
        val north = letter.isEmpty() || letter[0] >= 'N'
        return fromUtm(zone, north, normalize(e).trim().toDouble(), normalize(n).trim().toDouble())
    }

    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s) sb.append(
            when (ch) {
                in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                '\u066B', '\u060C', ',' -> if (ch == ',') '.' else '.'
                else -> ch
            }
        )
        return sb.toString()
    }

    fun parseAngle(input: String): Double {
        val t = normalize(input).uppercase().trim()
        val neg = t.startsWith("-") || t.endsWith("S") || t.endsWith("W") ||
                t.startsWith("S") || t.startsWith("W")
        val nums = Regex("\\d+(?:\\.\\d+)?").findAll(t).map { it.value.toDouble() }.toList()
        require(nums.isNotEmpty())
        val v = nums[0] + nums.getOrElse(1) { 0.0 } / 60 + nums.getOrElse(2) { 0.0 } / 3600
        return if (neg) -v else v
    }

    fun fmtDd(ll: Ll) = String.format(Locale.US, "%.6f, %.6f", ll.lat, ll.lon)

    private fun dms(v: Double, pos: Char, neg: Char): String {
        val a = abs(v)
        var d = a.toInt()
        var m = ((a - d) * 60).toInt()
        var s = ((a - d) * 60 - m) * 60
        s = (s * 100).roundToLong() / 100.0
        if (s >= 60) { s -= 60; m++ }
        if (m >= 60) { m -= 60; d++ }
        return String.format(Locale.US, "%d°%02d′%05.2f″%c", d, m, s, if (v >= 0) pos else neg)
    }

    fun fmtDms(ll: Ll) = dms(ll.lat, 'N', 'S') + "  " + dms(ll.lon, 'E', 'W')

    fun fmtByType(ll: Ll, type: Int, forceZone: Int? = null): String = when (type) {
        0 -> fmtDd(ll)
        1 -> fmtDms(ll)
        2 -> fmtUtm(toUtm(ll.lat, ll.lon, forceZone))
        else -> toMgrs(ll.lat, ll.lon)
    }
}
