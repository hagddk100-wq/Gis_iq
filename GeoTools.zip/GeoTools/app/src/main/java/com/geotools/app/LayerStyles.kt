package com.geotools.app

import android.content.Context
import org.json.JSONObject

/** Look of one map layer: visibility, color, opacity (0..255), line width and drawing order (0 = top). */
class LayerStyle(val visible: Boolean, val color: Int, val alpha: Int, val width: Float, val order: Int) {
    fun colorA(): Int = (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
}

object LayerStyles {
    /** Layer keys: one per category plus the online-places layer. */
    val KEYS: List<String> = Cat.values().map { it.key } + "gplaces"

    fun load(ctx: Context, defColor: (String) -> Int): Map<String, LayerStyle> {
        val saved = try {
            JSONObject(ctx.getSharedPreferences("layer_styles", 0).getString("s", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        val out = LinkedHashMap<String, LayerStyle>()
        KEYS.forEachIndexed { i, k ->
            val o = saved.optJSONObject(k)
            out[k] = if (o != null) {
                LayerStyle(o.optBoolean("v", true), o.optInt("c", defColor(k)), o.optInt("a", 255), o.optDouble("w", 5.0).toFloat(), o.optInt("o", i))
            } else {
                LayerStyle(true, defColor(k), 255, 5f, i)
            }
        }
        return out
    }

    fun save(ctx: Context, m: Map<String, LayerStyle>) {
        val o = JSONObject()
        m.forEach { (k, s) ->
            o.put(k, JSONObject().put("v", s.visible).put("c", s.color).put("a", s.alpha).put("w", s.width.toDouble()).put("o", s.order))
        }
        ctx.getSharedPreferences("layer_styles", 0).edit().putString("s", o.toString()).apply()
    }
}
