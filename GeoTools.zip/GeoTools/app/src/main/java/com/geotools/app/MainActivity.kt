package com.geotools.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Polygon
import java.io.File
import kotlin.math.cos
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osm")
            osmdroidTileCache = File(cacheDir, "osm/tiles")
        }
        setContent { App() }
    }
}

data class Cfg(
    val theme: Int = 0, val lang: String = "ar", val sound: Boolean = true,
    val fmt: Int = 0, val selMode: Int = 0,
    val w: Double = 2000.0, val h: Double = 2000.0, val tree: String = ""
)

fun loadCfg(c: Context): Cfg {
    val p = c.getSharedPreferences("cfg", 0)
    return Cfg(
        p.getInt("theme", 0), p.getString("lang", "ar")!!, p.getBoolean("sound", true),
        p.getInt("fmt", 0), p.getInt("sel", 0),
        p.getFloat("w", 2000f).toDouble(), p.getFloat("h", 2000f).toDouble(),
        p.getString("tree", "")!!
    )
}

fun saveCfg(c: Context, x: Cfg) {
    c.getSharedPreferences("cfg", 0).edit()
        .putInt("theme", x.theme).putString("lang", x.lang).putBoolean("sound", x.sound)
        .putInt("fmt", x.fmt).putInt("sel", x.selMode)
        .putFloat("w", x.w.toFloat()).putFloat("h", x.h.toFloat())
        .putString("tree", x.tree).apply()
}

@Composable
fun rememberClick(sound: Boolean): () -> Unit {
    val view = LocalView.current
    return {
        if (sound) view.playSoundEffect(SoundEffectConstants.CLICK)
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(loadCfg(ctx)) }
    val setCfg: (Cfg) -> Unit = { cfg = it; saveCfg(ctx, it) }
    var screen by remember { mutableStateOf("conv") }
    val dark = when (cfg.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val dir = if (cfg.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    val click = rememberClick(cfg.sound)
    val t = { k: String -> tr(cfg.lang, k) }

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Color(0xFF90CAF9))
        else lightColorScheme(primary = Color(0xFF0D47A1))
    ) {
        val drawer = rememberDrawerState(DrawerValue.Closed)
        val scope = rememberCoroutineScope()
        // The drawer container is forced LTR so the menu always opens from the left side.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            ModalNavigationDrawer(
                drawerState = drawer,
                drawerContent = {
                    CompositionLocalProvider(LocalLayoutDirection provides dir) {
                        ModalDrawerSheet {
                            Text(t("app"), style = MaterialTheme.typography.titleLarge,
                                modifier = Modifier.padding(20.dp))
                            listOf("conv" to "converter", "map" to "map", "set" to "settings").forEach { (id, k) ->
                                NavigationDrawerItem(
                                    label = { Text(t(k)) }, selected = screen == id,
                                    onClick = { click(); screen = id; scope.launch { drawer.close() } },
                                    modifier = Modifier.padding(horizontal = 12.dp)
                                )
                            }
                        }
                    }
                }
            ) {
                Scaffold(topBar = {
                    TopAppBar(
                        title = {
                            Text(t(when (screen) { "conv" -> "converter"; "map" -> "map"; else -> "settings" }))
                        },
                        navigationIcon = {
                            IconButton(onClick = { click(); scope.launch { drawer.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = null)
                            }
                        }
                    )
                }) { pad ->
                    CompositionLocalProvider(LocalLayoutDirection provides dir) {
                        Box(Modifier.padding(pad).fillMaxSize()) {
                            when (screen) {
                                "conv" -> ConverterScreen(cfg, click)
                                "map" -> MapScreen(cfg, setCfg, click)
                                else -> SettingsScreen(cfg, setCfg, click)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Field(label: String, v: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = v, onValueChange = onChange, label = { Text(label) },
        singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Choice(options: List<String>, sel: Int, click: () -> Unit, onSel: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, s ->
            FilterChip(selected = sel == i, onClick = { click(); onSel(i) }, label = { Text(s) })
        }
    }
}

@Composable
fun ConverterScreen(cfg: Cfg, click: () -> Unit) {
    val t = { k: String -> tr(cfg.lang, k) }
    var mode by remember { mutableIntStateOf(0) }
    var f1 by remember { mutableStateOf("") }
    var f2 by remember { mutableStateOf("") }
    var f3 by remember { mutableStateOf("") }
    var res by remember { mutableStateOf<Ll?>(null) }
    var err by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Choice(listOf("DD / DMS", "UTM", "MGRS"), mode, click) { mode = it; res = null; err = false }
        when (mode) {
            0 -> { Field(t("lat"), f1) { f1 = it }; Field(t("lon"), f2) { f2 = it } }
            1 -> { Field(t("zone"), f1) { f1 = it }; Field(t("easting"), f2) { f2 = it }; Field(t("northing"), f3) { f3 = it } }
            else -> Field(t("mgrs"), f1) { f1 = it }
        }
        Button(onClick = {
            click()
            err = false
            res = try {
                when (mode) {
                    0 -> Ll(GeoConverter.parseAngle(f1), GeoConverter.parseAngle(f2)).also {
                        require(Math.abs(it.lat) <= 90 && Math.abs(it.lon) <= 180)
                    }
                    1 -> GeoConverter.parseUtm(f1, f2, f3)
                    else -> GeoConverter.mgrsToLatLon(f1)
                }
            } catch (e: Exception) { err = true; null }
        }, modifier = Modifier.fillMaxWidth()) { Text(t("convert")) }

        if (err) Text(t("invalid"), color = MaterialTheme.colorScheme.error)

        res?.let { ll ->
            val rows = listOf(
                "DD" to GeoConverter.fmtDd(ll),
                "DMS" to GeoConverter.fmtDms(ll),
                "UTM" to GeoConverter.fmtUtm(GeoConverter.toUtm(ll.lat, ll.lon)),
                "MGRS" to GeoConverter.toMgrs(ll.lat, ll.lon),
                t("meridian") to String.format(java.util.Locale.US, "%.6f°", ll.lon),
                t("parallel") to String.format(java.util.Locale.US, "%.6f°", ll.lat)
            )
            rows.forEach { (k, v) ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(k, style = MaterialTheme.typography.labelMedium)
                            Text(v, style = MaterialTheme.typography.bodyLarge)
                        }
                        TextButton(onClick = { click(); clip.setText(AnnotatedString(v)) }) { Text(t("copy")) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MapScreen(cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val t = { k: String -> tr(cfg.lang, k) }
    var p1 by remember { mutableStateOf<Ll?>(null) }
    var p2 by remember { mutableStateOf<Ll?>(null) }
    var cats by remember { mutableStateOf(setOf(Cat.ROADS_MAIN)) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var shared by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var wTxt by remember { mutableStateOf(cfg.w.roundToInt().toString()) }
    var hTxt by remember { mutableStateOf(cfg.h.roundToInt().toString()) }
    val mode by rememberUpdatedState(cfg.selMode)

    val rect: Rect? = if (cfg.selMode == 0) {
        p1?.let { boxAround(it, cfg.w, cfg.h) }
    } else {
        val a = p1; val b = p2
        if (a != null && b != null)
            Rect(minOf(a.lat, b.lat), minOf(a.lon, b.lon), maxOf(a.lat, b.lat), maxOf(a.lon, b.lon))
        else null
    }

    val mapView = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(4.0)
            controller.setCenter(GeoPoint(30.0, 40.0))
            overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    val q = Ll(p.latitude, p.longitude)
                    if (mode == 0) { p1 = q; p2 = null }
                    else if (p1 == null || p2 != null) { p1 = q; p2 = null }
                    else p2 = q
                    return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
        }
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs); mapView.onDetach() }
    }

    Column(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { mapView },
            update = { mv ->
                mv.overlays.removeAll { it is Polygon }
                rect?.let { r ->
                    val poly = Polygon(mv)
                    poly.points = listOf(
                        GeoPoint(r.s, r.w), GeoPoint(r.n, r.w), GeoPoint(r.n, r.e), GeoPoint(r.s, r.e)
                    )
                    poly.fillPaint.color = 0x330066FF
                    poly.outlinePaint.color = 0xFF0066FF.toInt()
                    poly.outlinePaint.strokeWidth = 4f
                    mv.overlays.add(poly)
                }
                mv.invalidate()
            },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        Column(
            Modifier.fillMaxWidth().heightIn(max = 320.dp).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (rect == null) {
                Text(t(if (cfg.selMode == 0) "tap_center" else "tap_corners"))
            } else {
                val zone = GeoConverter.zoneOf((rect.w + rect.e) / 2)
                Text("SW: " + GeoConverter.fmtByType(Ll(rect.s, rect.w), cfg.fmt, zone))
                Text("NE: " + GeoConverter.fmtByType(Ll(rect.n, rect.e), cfg.fmt, zone))
            }
            if (cfg.selMode == 0) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = wTxt, singleLine = true, label = { Text(t("width")) },
                        onValueChange = {
                            wTxt = it
                            GeoConverter.normalize(it).toDoubleOrNull()?.let { v -> if (v > 0) setCfg(cfg.copy(w = v)) }
                        }, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = hTxt, singleLine = true, label = { Text(t("height")) },
                        onValueChange = {
                            hTxt = it
                            GeoConverter.normalize(it).toDoubleOrNull()?.let { v -> if (v > 0) setCfg(cfg.copy(h = v)) }
                        }, modifier = Modifier.weight(1f)
                    )
                }
            }
            Text(t("categories"), style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Cat.values().forEach { c ->
                    FilterChip(
                        selected = c in cats,
                        onClick = { click(); cats = if (c in cats) cats - c else cats + c },
                        label = { Text(t(c.key)) })
                }
            }
            Button(
                enabled = rect != null && cats.isNotEmpty() && !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    click()
                    val r = rect ?: return@Button
                    val wM = (r.e - r.w) * 111320.0 * cos(Math.toRadians((r.s + r.n) / 2))
                    val hM = (r.n - r.s) * 111320.0
                    if (wM > 100000 || hM > 100000) { status = t("too_big"); return@Button }
                    busy = true
                    status = t("fetching")
                    val chosen = cats
                    scope.launch {
                        try {
                            val center = Ll((r.s + r.n) / 2, (r.w + r.e) / 2)
                            val feats = withContext(Dispatchers.IO) { Overpass.fetch(r, chosen) }
                            if (feats.isEmpty()) {
                                status = t("none_found")
                            } else {
                                val admin = withContext(Dispatchers.IO) { Nominatim.reverse(center) }
                                val res = withContext(Dispatchers.IO) {
                                    val files = Exporter.build(feats, admin, GeoConverter.zoneOf(center.lon))
                                    Exporter.save(ctx, cfg.tree, files)
                                }
                                shared = res.uris
                                status = t("saved") + ": " + res.where + "\n" + t("features") + ": " + feats.size
                            }
                        } catch (e: Exception) {
                            status = e.message ?: e.toString()
                        } finally {
                            busy = false
                        }
                    }
                }
            ) { Text(t("export")) }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodySmall)
            if (shared.isNotEmpty()) {
                OutlinedButton(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        click()
                        val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                            type = "*/*"
                            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(shared))
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(i, null))
                    }
                ) { Text(t("share")) }
            }
        }
    }
}

@Composable
fun SettingsScreen(cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit) {
    val ctx = LocalContext.current
    val t = { k: String -> tr(cfg.lang, k) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            setCfg(cfg.copy(tree = uri.toString()))
        }
    }
    val folderName = if (cfg.tree.isEmpty()) t("default_folder")
    else DocumentFile.fromTreeUri(ctx, Uri.parse(cfg.tree))?.name ?: cfg.tree

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(t("theme"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf(t("system"), t("light"), t("dark")), cfg.theme, click) { setCfg(cfg.copy(theme = it)) }

        Text(t("language"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf("العربية", "English"), if (cfg.lang == "ar") 0 else 1, click) {
            setCfg(cfg.copy(lang = if (it == 0) "ar" else "en"))
        }

        Text(t("folder"), style = MaterialTheme.typography.titleSmall)
        Text(folderName)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { click(); launcher.launch(null) }) { Text(t("choose_folder")) }
            if (cfg.tree.isNotEmpty()) OutlinedButton(onClick = { click(); setCfg(cfg.copy(tree = "")) }) {
                Text(t("default_folder"))
            }
        }

        Text(t("fmt"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf("DD", "DMS", "UTM", "MGRS"), cfg.fmt, click) { setCfg(cfg.copy(fmt = it)) }

        Text(t("sel_mode"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf(t("center_size"), t("two_corners")), cfg.selMode, click) { setCfg(cfg.copy(selMode = it)) }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("sound"), Modifier.weight(1f))
            Switch(checked = cfg.sound, onCheckedChange = { setCfg(cfg.copy(sound = it)) })
        }
    }
}
