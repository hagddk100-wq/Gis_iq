package com.geotools.app

class Cond(
    val k: String,
    val vals: Set<String>? = null,
    val needName: Boolean = false,
    val elem: String = "nwr",
    val nameRe: String? = null
) {
    private val re: Regex? = nameRe?.let { Regex(it) }

    fun stmt(): String {
        if (nameRe != null) return "nwr[\"name\"~\"$nameRe\"]"
        val sel = if (vals == null) "[\"$k\"]" else "[\"$k\"~\"^(" + vals.joinToString("|") + ")\$\"]"
        return elem + sel + (if (needName) "[\"name\"]" else "")
    }

    fun ok(t: Map<String, String>): Boolean {
        if (re != null) return re.containsMatchIn(t["name"] ?: "")
        val x = t[k] ?: return false
        if (needName && t["name"] == null) return false
        return vals == null || x in vals
    }
}

class PlaceGroup(val key: String, val conds: List<Cond>) {
    fun match(t: Map<String, String>): Boolean = conds.any { it.ok(t) }
}

val DEFAULT_GROUPS = setOf("g_health", "g_school", "g_religion", "g_hotel")

// Order matters: the first matching group labels a feature (more specific groups first).
val PLACE_GROUPS: List<PlaceGroup> = listOf(
    PlaceGroup("g_health", listOf(
        Cond("amenity", setOf("hospital", "clinic", "doctors", "pharmacy", "dentist")), Cond("healthcare"))),
    PlaceGroup("g_school", listOf(
        Cond("amenity", setOf("school", "kindergarten", "college", "university")))),
    PlaceGroup("g_court", listOf(Cond("amenity", setOf("courthouse")))),
    PlaceGroup("g_gov", listOf(
        Cond("office", setOf("government")),
        Cond("amenity", setOf("townhall", "police", "fire_station", "public_building", "post_office", "embassy")),
        Cond("government"))),
    PlaceGroup("g_religion", listOf(
        Cond("amenity", setOf("place_of_worship")),
        Cond("building", setOf("mosque", "shrine", "church", "cathedral", "chapel", "synagogue")))),
    PlaceGroup("g_hotel", listOf(
        Cond("tourism", setOf("hotel", "guest_house", "motel", "hostel", "apartment", "chalet")))),
    PlaceGroup("g_food", listOf(
        Cond("amenity", setOf("restaurant", "cafe", "fast_food", "food_court", "bar", "pub", "ice_cream")))),
    PlaceGroup("g_shop", listOf(Cond("shop"), Cond("amenity", setOf("marketplace")))),
    PlaceGroup("g_fuel", listOf(Cond("amenity", setOf("fuel")))),
    PlaceGroup("g_parking", listOf(
        Cond("amenity", setOf("parking", "bus_station", "taxi")),
        Cond("building", setOf("garage", "garages")))),
    PlaceGroup("g_train", listOf(
        Cond("railway", setOf("station", "halt", "tram_stop", "subway_entrance")))),
    PlaceGroup("g_air", listOf(Cond("aeroway", setOf("aerodrome", "terminal", "heliport")))),
    PlaceGroup("g_border", listOf(
        Cond("barrier", setOf("border_control")), Cond("amenity", setOf("customs")))),
    PlaceGroup("g_money", listOf(
        Cond("amenity", setOf("bank", "bureau_de_change", "money_transfer")))),
    PlaceGroup("g_office", listOf(Cond("office"))),
    PlaceGroup("g_fun", listOf(
        Cond("leisure", setOf("park", "playground", "sports_centre", "stadium", "water_park",
            "amusement_arcade", "garden", "fitness_centre")),
        Cond("amenity", setOf("cinema", "theatre", "nightclub", "arts_centre")),
        Cond("tourism", setOf("theme_park", "zoo", "gallery")))),
    PlaceGroup("g_bridge", listOf(
        Cond("bridge", needName = true, elem = "way"),
        Cond("man_made", setOf("bridge"), needName = true, elem = "way"))),
    PlaceGroup("g_street", listOf(Cond("highway", needName = true, elem = "way"))),
    PlaceGroup("g_house", listOf(
        Cond("building", setOf("house", "residential", "detached", "apartments", "villa"), needName = true))),
    PlaceGroup("g_guest", listOf(Cond("name", nameRe = "مضيف|مضائف|ديوانية|mudhif|diwan"))),
    PlaceGroup("g_farm", listOf(
        Cond("landuse", setOf("farmland", "farmyard", "orchard", "vineyard"), needName = true),
        Cond("place", setOf("farm")),
        Cond("name", nameRe = "مزرعة|بستان"))),
    PlaceGroup("g_all", listOf(Cond("name")))
)
