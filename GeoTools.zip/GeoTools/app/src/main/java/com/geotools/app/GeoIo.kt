package com.geotools.app

import android.content.Context
import android.net.Uri
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ImportResult(
    val features: List<GisFeature>, val errors: List<String>, val skipped: Int,
    val format: String, val duplicates: Int
)

/** Reads and writes GeoJSON, GPX, KML, KMZ and CSV/TXT. */
object GeoIo {
    private const val MAX_ERRORS = 200

    /** Collects features while validating geometry; bad records are reported, never stop the import. */
    private class Sink(val pid: String, val source: String) {
        val out = ArrayList<GisFeature>()
        val errors = ArrayList<String>()
        var skipped = 0
        var n = 0

        fun reject(msg: String) {
            skipped++
            if (errors.size < MAX_ERRORS) errors.add("#$n: $msg")
        }

        private fun okLl(p: Ll) = p.lat in -90.0..90.0 && p.lon in -180.0..180.0 && !p.lat.isNaN() && !p.lon.isNaN()

        fun add(kind: Kind, parts: List<List<Ll>>, props: Map<String, String> = emptyMap(), nameIn: String = "", descIn: String = "") {
            n++
            if (parts.isEmpty() || parts.any { it.isEmpty() }) return reject("هندسة فارغة")
            if (parts.any { part -> part.any { !okLl(it) } }) return reject("إحداثيات خارج النطاق")
            val fixed: List<List<Ll>> = when (kind) {
                Kind.POINT -> listOf(listOf(parts[0][0]))
                Kind.LINE -> {
                    if (parts.any { it.distinct().size < 2 }) return reject("خط بأقل من نقطتين مختلفتين")
                    parts
                }
                Kind.POLYGON -> parts.map { ring ->
                    if (ring.distinct().size < 3) return reject("مضلع بأقل من ثلاثة رؤوس مختلفة")
                    if (ring.first() == ring.last()) ring else ring + ring.first()
                }
            }
            val p = LinkedHashMap(props)
            fun pick(vararg keys: String): String {
                for (k in keys) {
                    val e = p.entries.firstOrNull { it.key.equals(k, ignoreCase = true) }
                    if (e != null && e.value.isNotBlank()) return e.value
                }
                return ""
            }
            val name = nameIn.ifBlank { pick("name:ar", "name_ar", "name", "title", "label", "الاسم", "اسم") }
            val nameEn = pick("name:en", "name_en")
            val cat = pick("category", "type", "class", "fclass", "amenity", "التصنيف", "نوع")
            out.add(
                GisFeature(
                    projectId = pid, name = name, nameEn = nameEn, category = cat, kind = kind, parts = fixed,
                    gov = pick("gov", "governorate", "المحافظة"), qadha = pick("qadha", "qada", "district", "القضاء"),
                    nahiya = pick("nahiya", "nahia", "sub_district", "الناحية"),
                    description = descIn.ifBlank { pick("description", "desc", "الوصف") },
                    notes = pick("notes", "ملاحظات"), source = source, props = p
                )
            )
        }
    }

    // ------------------------------------------------------------------ reading
    fun read(ctx: Context, uri: Uri, fileName: String, pid: String, csvEpsg: Int): ImportResult {
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val sink = Sink(pid, fileName)
        val fmt = when (ext) {
            "geojson", "json" -> "GeoJSON"
            "gpx" -> "GPX"
            "kml" -> "KML"
            "kmz" -> "KMZ"
            "csv", "txt" -> "CSV"
            else -> throw IllegalArgumentException("unsupported")
        }
        ctx.contentResolver.openInputStream(uri)!!.use { ins ->
            when (fmt) {
                "GeoJSON" -> geoJson(String(ins.readBytes(), Charsets.UTF_8), sink)
                "GPX" -> gpx(ins, sink)
                "KML" -> kml(ins, sink)
                "KMZ" -> kmz(ins, sink)
                else -> csv(ins, sink, csvEpsg)
            }
        }
        val dups = if (sink.out.size <= 5000) countDuplicates(ctx, pid, sink.out) else 0
        return ImportResult(sink.out, sink.errors, sink.skipped, fmt, dups)
    }

    private fun distM(a: Ll, b: Ll): Double {
        val dLat = (a.lat - b.lat) * M_LAT
        val dLon = (a.lon - b.lon) * mLon((a.lat + b.lat) / 2)
        return Math.hypot(dLat, dLon)
    }

    /** Same name within 30 m, or two points within 3 m. */
    private fun countDuplicates(ctx: Context, pid: String, list: List<GisFeature>): Int {
        val db = GisDb.get(ctx)
        var n = 0
        for (f in list) {
            val c = f.center()
            val pad = 0.0004
            val near = db.featuresIn(pid, c.lat - pad, c.lon - pad, c.lat + pad, c.lon + pad)
            val dup = near.any { o ->
                val d = distM(c, o.center())
                (f.name.isNotBlank() && f.name.equals(o.name, ignoreCase = true) && d < 30.0) ||
                    (f.kind == Kind.POINT && o.kind == Kind.POINT && d < 3.0)
            }
            if (dup) n++
        }
        return n
    }

    private fun pos(a: JSONArray) = Ll(a.getDouble(1), a.getDouble(0))

    private fun line(a: JSONArray): List<Ll> = (0 until a.length()).map { pos(a.getJSONArray(it)) }

    private fun geoJson(text: String, sink: Sink) {
        val root = try {
            JSONTokener(text.trimStart('\uFEFF')).nextValue()
        } catch (e: Exception) {
            sink.reject("ملف JSON غير صالح")
            return
        }

        fun props(p: JSONObject?): Map<String, String> {
            val m = LinkedHashMap<String, String>()
            if (p != null) {
                val it = p.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    val v = p.opt(k)
                    if (v != null && v != JSONObject.NULL) m[k] = v.toString()
                }
            }
            return m
        }

        fun geometry(g: JSONObject, pr: Map<String, String>) {
            try {
                val co = g.opt("coordinates")
                when (g.optString("type")) {
                    "Point" -> sink.add(Kind.POINT, listOf(listOf(pos(co as JSONArray))), pr)
                    "MultiPoint" -> {
                        val a = co as JSONArray
                        for (i in 0 until a.length()) sink.add(Kind.POINT, listOf(listOf(pos(a.getJSONArray(i)))), pr)
                    }
                    "LineString" -> sink.add(Kind.LINE, listOf(line(co as JSONArray)), pr)
                    "MultiLineString" -> {
                        val a = co as JSONArray
                        sink.add(Kind.LINE, (0 until a.length()).map { line(a.getJSONArray(it)) }, pr)
                    }
                    "Polygon" -> sink.add(Kind.POLYGON, listOf(line((co as JSONArray).getJSONArray(0))), pr)
                    "MultiPolygon" -> {
                        val a = co as JSONArray
                        sink.add(Kind.POLYGON, (0 until a.length()).map { line(a.getJSONArray(it).getJSONArray(0)) }, pr)
                    }
                    "GeometryCollection" -> {
                        val a = g.getJSONArray("geometries")
                        for (i in 0 until a.length()) geometry(a.getJSONObject(i), pr)
                    }
                    else -> sink.reject("نوع هندسة غير مدعوم")
                }
            } catch (e: Exception) {
                sink.reject("هندسة غير صالحة")
            }
        }

        fun handle(o: JSONObject) {
            when (o.optString("type")) {
                "FeatureCollection" -> o.optJSONArray("features")?.let { a ->
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { handle(it) }
                }
                "Feature" -> {
                    val g = o.optJSONObject("geometry")
                    if (g == null) { sink.n++; sink.reject("بدون هندسة") } else geometry(g, props(o.optJSONObject("properties")))
                }
                else -> geometry(o, emptyMap())
            }
        }
        when (root) {
            is JSONObject -> handle(root)
            is JSONArray -> for (i in 0 until root.length()) root.optJSONObject(i)?.let { handle(it) }
            else -> sink.reject("بنية JSON غير معروفة")
        }
    }

    private fun parser(ins: InputStream): XmlPullParser {
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(ins, null)
        return p
    }

    private fun gpx(ins: InputStream, sink: Sink) {
        try {
            val p = parser(ins)
            var cur = ""
            var inPt = false
            var name = ""
            var desc = ""
            val pts = ArrayList<Ll>()
            val segs = ArrayList<List<Ll>>()
            fun ptOf(): Ll? {
                val la = p.getAttributeValue(null, "lat")?.toDoubleOrNull()
                val lo = p.getAttributeValue(null, "lon")?.toDoubleOrNull()
                return if (la != null && lo != null) Ll(la, lo) else null
            }
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "wpt" -> { cur = "wpt"; name = ""; desc = ""; pts.clear(); inPt = true; ptOf()?.let { pts.add(it) } }
                        "trk" -> { cur = "trk"; name = ""; desc = ""; segs.clear() }
                        "rte" -> { cur = "rte"; name = ""; desc = ""; pts.clear() }
                        "trkseg" -> pts.clear()
                        "trkpt", "rtept" -> { inPt = true; ptOf()?.let { pts.add(it) } }
                        "name" -> if (cur.isNotEmpty() && (!inPt || cur == "wpt")) name = p.nextText()
                        "desc" -> if (cur.isNotEmpty() && (!inPt || cur == "wpt")) desc = p.nextText()
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.name) {
                        "wpt" -> {
                            inPt = false
                            if (pts.isEmpty()) { sink.n++; sink.reject("نقطة بإحداثيات ناقصة") }
                            else sink.add(Kind.POINT, listOf(pts.toList()), emptyMap(), name, desc)
                            cur = ""
                        }
                        "trkpt", "rtept" -> inPt = false
                        "trkseg" -> if (pts.isNotEmpty()) segs.add(pts.toList())
                        "trk" -> { sink.add(Kind.LINE, segs.toList(), emptyMap(), name, desc); cur = "" }
                        "rte" -> { sink.add(Kind.LINE, listOf(pts.toList()), emptyMap(), name, desc); cur = "" }
                    }
                }
                ev = p.next()
            }
        } catch (e: Exception) {
            sink.reject("ملف GPX غير صالح")
        }
    }

    private fun coordsOf(text: String): List<Ll> {
        val out = ArrayList<Ll>()
        text.trim().split(Regex("\\s+")).forEach { t ->
            val a = t.split(",")
            if (a.size >= 2) {
                val lo = a[0].toDoubleOrNull()
                val la = a[1].toDoubleOrNull()
                if (lo != null && la != null) out.add(Ll(la, lo))
            }
        }
        return out
    }

    private fun kml(ins: InputStream, sink: Sink) {
        try {
            val p = parser(ins)
            var inPm = false
            var name = ""
            var desc = ""
            var geom = ""
            var inner = false
            var dataName: String? = null
            val props = LinkedHashMap<String, String>()
            val pointsL = ArrayList<List<Ll>>()
            val linesL = ArrayList<List<Ll>>()
            val polysL = ArrayList<List<Ll>>()
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "Placemark" -> {
                            inPm = true; name = ""; desc = ""; props.clear()
                            pointsL.clear(); linesL.clear(); polysL.clear()
                        }
                        "name" -> if (inPm && dataName == null) name = p.nextText()
                        "description" -> if (inPm) desc = p.nextText()
                        "Point", "LineString", "Polygon" -> geom = p.name
                        "innerBoundaryIs" -> inner = true
                        "Data" -> dataName = p.getAttributeValue(null, "name")
                        "SimpleData" -> if (inPm) { val k = p.getAttributeValue(null, "name"); if (k != null) props[k] = p.nextText() }
                        "value" -> if (inPm && dataName != null) { props[dataName!!] = p.nextText(); dataName = null }
                        "coordinates" -> if (inPm) {
                            val pts = coordsOf(p.nextText())
                            when (geom) {
                                "Point" -> if (pts.isNotEmpty()) pointsL.add(listOf(pts[0]))
                                "LineString" -> linesL.add(pts)
                                "Polygon" -> if (!inner) polysL.add(pts)
                            }
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.name) {
                        "innerBoundaryIs" -> inner = false
                        "Data" -> dataName = null
                        "Placemark" -> {
                            inPm = false
                            val d = desc.take(500)
                            pointsL.forEach { sink.add(Kind.POINT, listOf(it), props, name, d) }
                            if (linesL.isNotEmpty()) sink.add(Kind.LINE, linesL.toList(), props, name, d)
                            if (polysL.isNotEmpty()) sink.add(Kind.POLYGON, polysL.toList(), props, name, d)
                            if (pointsL.isEmpty() && linesL.isEmpty() && polysL.isEmpty()) { sink.n++; sink.reject("بدون هندسة") }
                        }
                    }
                }
                ev = p.next()
            }
        } catch (e: Exception) {
            sink.reject("ملف KML غير صالح")
        }
    }

    private fun kmz(ins: InputStream, sink: Sink) {
        val zis = ZipInputStream(ins)
        var e: ZipEntry? = zis.nextEntry
        while (e != null) {
            if (e.name.lowercase(Locale.ROOT).endsWith(".kml")) {
                kml(zis, sink)
                return
            }
            e = zis.nextEntry
        }
        sink.reject("لا يحتوي KMZ على ملف KML")
    }

    private fun splitCsv(line: String, d: Char): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (q) {
                if (ch == '"') {
                    if (i + 1 < line.length && line[i + 1] == '"') { sb.append('"'); i++ } else q = false
                } else sb.append(ch)
            } else if (ch == '"') q = true
            else if (ch == d) { out.add(sb.toString()); sb.setLength(0) }
            else sb.append(ch)
            i++
        }
        out.add(sb.toString())
        return out
    }

    private fun num(s: String?): Double? = s?.let { GeoConverter.normalize(it).trim().toDoubleOrNull() }

    private fun csv(ins: InputStream, sink: Sink, epsg: Int) {
        val br = BufferedReader(InputStreamReader(ins, Charsets.UTF_8))
        val first = (br.readLine() ?: return).removePrefix("\uFEFF")
        val d = listOf(',', ';', '\t').maxByOrNull { c -> first.count { it == c } } ?: ','
        var header = splitCsv(first, d)
        val headerIsData = header.count { num(it) != null } >= 2
        val low = header.map { it.lowercase(Locale.ROOT).trim() }
        var xi = low.indexOfFirst { it in setOf("lon", "lng", "long", "longitude", "x", "easting", "خط الطول") }
        var yi = low.indexOfFirst { it in setOf("lat", "latitude", "y", "northing", "خط العرض") }
        val ni = low.indexOfFirst { it in setOf("name", "title", "اسم", "الاسم") }
        val rows = ArrayList<List<String>>()
        if (headerIsData) {
            rows.add(header)
            header = emptyList()
        }
        if (xi < 0 || yi < 0) {
            // No header names: pick the first two numeric columns (latitude first unless it cannot be one).
            val sample = rows.firstOrNull() ?: splitCsv(br.readLine() ?: return, d).also { rows.add(it) }
            val numCols = sample.indices.filter { num(sample[it]) != null }
            if (numCols.size < 2) { sink.reject("لم يتم العثور على عمودي الإحداثيات"); return }
            val a = numCols[0]
            val b = numCols[1]
            if (epsg != 4326) { xi = a; yi = b }
            else if (Math.abs(num(sample[a])!!) > 90) { xi = a; yi = b }
            else { yi = a; xi = b }
        }
        var line = br.readLine()
        while (line != null) {
            if (line.isNotBlank()) rows.add(splitCsv(line, d))
            if (rows.size >= 100_000) {
                csvRows(rows, header, xi, yi, ni, epsg, sink)
                rows.clear()
            }
            line = br.readLine()
        }
        csvRows(rows, header, xi, yi, ni, epsg, sink)
    }

    private fun csvRows(rows: List<List<String>>, header: List<String>, xi: Int, yi: Int, ni: Int, epsg: Int, sink: Sink) {
        for (cells in rows) {
            val x = num(cells.getOrNull(xi))
            val y = num(cells.getOrNull(yi))
            if (x == null || y == null) { sink.n++; sink.reject("إحداثيات غير رقمية"); continue }
            val ll = if (epsg == 4326) Ll(y, x) else try {
                toWgs84(epsg, x, y)
            } catch (e: Exception) {
                sink.n++; sink.reject("تعذر تحويل الإحداثيات من EPSG:$epsg"); continue
            }
            val props = LinkedHashMap<String, String>()
            header.forEachIndexed { i, h -> if (i != xi && i != yi && i < cells.size && cells[i].isNotBlank()) props[h] = cells[i] }
            sink.add(Kind.POINT, listOf(listOf(ll)), props, if (ni >= 0) cells.getOrNull(ni) ?: "" else "")
        }
    }

    /** Converts projected coordinates to WGS84 with the project's CRS helper. */
    private fun toWgs84(code: Int, x: Double, y: Double): Ll = Crs.toWgs(code, x, y)

    // ------------------------------------------------------------------ writing
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun f7(d: Double) = String.format(Locale.US, "%.7f", d)

    private fun closed(r: List<Ll>) = if (r.isNotEmpty() && r.first() != r.last()) r + r.first() else r

    private fun lonLat(p: Ll) = JSONArray().put(p.lon).put(p.lat)

    private fun geomJson(f: GisFeature): JSONObject {
        val g = JSONObject()
        when (f.kind) {
            Kind.POINT -> g.put("type", "Point").put("coordinates", lonLat(f.parts[0][0]))
            Kind.LINE -> if (f.parts.size == 1) {
                g.put("type", "LineString").put("coordinates", JSONArray().also { a -> f.parts[0].forEach { a.put(lonLat(it)) } })
            } else {
                g.put("type", "MultiLineString").put("coordinates", JSONArray().also { m ->
                    f.parts.forEach { part -> m.put(JSONArray().also { a -> part.forEach { a.put(lonLat(it)) } }) }
                })
            }
            Kind.POLYGON -> if (f.parts.size == 1) {
                g.put("type", "Polygon").put("coordinates", JSONArray().put(JSONArray().also { a -> closed(f.parts[0]).forEach { a.put(lonLat(it)) } }))
            } else {
                g.put("type", "MultiPolygon").put("coordinates", JSONArray().also { m ->
                    f.parts.forEach { part -> m.put(JSONArray().put(JSONArray().also { a -> closed(part).forEach { a.put(lonLat(it)) } })) }
                })
            }
        }
        return g
    }

    fun writeGeoJson(feats: List<GisFeature>, out: OutputStream) {
        val w = out.bufferedWriter(Charsets.UTF_8)
        w.write("{\"type\":\"FeatureCollection\",\"name\":\"GeoTools\",\"features\":[")
        feats.forEachIndexed { i, f ->
            val pr = JSONObject()
            f.props.forEach { (k, v) -> pr.put(k, v) }
            pr.put("id", f.id).put("name", f.name).put("name_en", f.nameEn).put("category", f.category)
                .put("gov", f.gov).put("qadha", f.qadha).put("nahiya", f.nahiya)
                .put("description", f.description).put("notes", f.notes).put("source", f.source)
                .put("status", f.status).put("accuracy", f.accuracy)
            val o = JSONObject().put("type", "Feature").put("properties", pr).put("geometry", geomJson(f))
            if (i > 0) w.write(",")
            w.write(o.toString())
        }
        w.write("]}")
        w.flush()
    }

    fun writeGpx(feats: List<GisFeature>, out: OutputStream) {
        val w = out.bufferedWriter(Charsets.UTF_8)
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"GeoTools\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        for (f in feats) {
            val desc = listOf(f.description, f.notes).filter { it.isNotBlank() }.joinToString(" - ")
            if (f.kind == Kind.POINT) {
                val p = f.parts[0][0]
                w.write("<wpt lat=\"${f7(p.lat)}\" lon=\"${f7(p.lon)}\"><name>${esc(f.name)}</name>")
                if (desc.isNotEmpty()) w.write("<desc>${esc(desc)}</desc>")
                w.write("</wpt>\n")
            } else {
                w.write("<trk><name>${esc(f.name)}</name>")
                if (desc.isNotEmpty()) w.write("<desc>${esc(desc)}</desc>")
                for (part in f.parts) {
                    w.write("<trkseg>")
                    (if (f.kind == Kind.POLYGON) closed(part) else part).forEach { w.write("<trkpt lat=\"${f7(it.lat)}\" lon=\"${f7(it.lon)}\"/>") }
                    w.write("</trkseg>")
                }
                w.write("</trk>\n")
            }
        }
        w.write("</gpx>")
        w.flush()
    }

    private fun kmlCoords(pts: List<Ll>) = pts.joinToString(" ") { "${f7(it.lon)},${f7(it.lat)},0" }

    fun writeKml(feats: List<GisFeature>, out: OutputStream) {
        val w = out.bufferedWriter(Charsets.UTF_8)
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document><name>GeoTools</name>\n")
        for (f in feats) {
            w.write("<Placemark><name>${esc(f.name)}</name>")
            val desc = listOf(f.description, f.notes).filter { it.isNotBlank() }.joinToString(" - ")
            if (desc.isNotEmpty()) w.write("<description>${esc(desc)}</description>")
            w.write("<ExtendedData>")
            fun data(k: String, v: String) { if (v.isNotBlank()) w.write("<Data name=\"${esc(k)}\"><value>${esc(v)}</value></Data>") }
            data("id", f.id); data("name_en", f.nameEn); data("category", f.category)
            data("gov", f.gov); data("qadha", f.qadha); data("nahiya", f.nahiya)
            data("status", f.status); data("source", f.source)
            f.props.forEach { (k, v) -> data(k, v) }
            w.write("</ExtendedData>")
            val geoms = ArrayList<String>()
            when (f.kind) {
                Kind.POINT -> geoms.add("<Point><coordinates>${kmlCoords(listOf(f.parts[0][0]))}</coordinates></Point>")
                Kind.LINE -> f.parts.forEach { geoms.add("<LineString><coordinates>${kmlCoords(it)}</coordinates></LineString>") }
                Kind.POLYGON -> f.parts.forEach {
                    geoms.add("<Polygon><outerBoundaryIs><LinearRing><coordinates>${kmlCoords(closed(it))}</coordinates></LinearRing></outerBoundaryIs></Polygon>")
                }
            }
            if (geoms.size == 1) w.write(geoms[0]) else w.write("<MultiGeometry>${geoms.joinToString("")}</MultiGeometry>")
            w.write("</Placemark>\n")
        }
        w.write("</Document></kml>")
        w.flush()
    }

    fun writeKmz(feats: List<GisFeature>, out: OutputStream) {
        val z = ZipOutputStream(out)
        z.putNextEntry(ZipEntry("doc.kml"))
        writeKml(feats, object : OutputStream() {
            override fun write(b: Int) = z.write(b)
            override fun write(b: ByteArray, off: Int, len: Int) = z.write(b, off, len)
            override fun flush() = z.flush()
            override fun close() {}
        })
        z.closeEntry()
        z.finish()
        z.flush()
    }

    private fun wkt(f: GisFeature): String = when (f.kind) {
        Kind.POINT -> "POINT(${f7(f.parts[0][0].lon)} ${f7(f.parts[0][0].lat)})"
        Kind.LINE -> "LINESTRING(" + f.parts[0].joinToString(", ") { "${f7(it.lon)} ${f7(it.lat)}" } + ")"
        Kind.POLYGON -> "POLYGON((" + closed(f.parts[0]).joinToString(", ") { "${f7(it.lon)} ${f7(it.lat)}" } + "))"
    }

    private fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    fun writeCsv(feats: List<GisFeature>, out: OutputStream) {
        val w = out.bufferedWriter(Charsets.UTF_8)
        w.write("\uFEFFid,name,name_en,category,kind,lat,lon,gov,qadha,nahiya,description,notes,source,status,accuracy,wkt\n")
        for (f in feats) {
            val c = f.center()
            w.write(
                listOf(
                    q(f.id), q(f.name), q(f.nameEn), q(f.category), f.kind.name, f7(c.lat), f7(c.lon),
                    q(f.gov), q(f.qadha), q(f.nahiya), q(f.description), q(f.notes), q(f.source), f.status,
                    String.format(Locale.US, "%.1f", f.accuracy), q(wkt(f))
                ).joinToString(",") + "\n"
            )
        }
        w.flush()
    }
}
