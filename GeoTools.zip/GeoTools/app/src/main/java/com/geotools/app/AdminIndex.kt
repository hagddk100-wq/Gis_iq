package com.geotools.app

/** Finds the district (qadha) and sub-district (nahiya) that contain a feature, from OSM admin boundaries. */
class AdminIndex(polys: List<Feature>, private val qLvl: Int, private val nLvl: Int) {
    private class P(
        val name: String, val lvl: Int, val rings: List<List<Ll>>,
        val s: Double, val w: Double, val n: Double, val e: Double
    )

    private val items: List<P> = polys.mapNotNull { f ->
        if (f.kind != Kind.POLYGON) return@mapNotNull null
        val lvl = f.type.removePrefix("admin_level=").toIntOrNull() ?: return@mapNotNull null
        val all = f.parts.flatten()
        if (all.isEmpty()) return@mapNotNull null
        P(f.name, lvl, f.parts, all.minOf { it.lat }, all.minOf { it.lon }, all.maxOf { it.lat }, all.maxOf { it.lon })
    }

    /** Returns (qadha, nahiya) names; empty when the point is not inside a loaded boundary. */
    fun of(f: Feature): Pair<String, String> {
        val c = featureCenter(f)
        var q = ""
        var n = ""
        for (p in items) {
            if (c.lat < p.s || c.lat > p.n || c.lon < p.w || c.lon > p.e) continue
            if (p.lvl != qLvl && p.lvl != nLvl) continue
            if (p.rings.any { pointInPoly(c, it) }) {
                if (p.lvl == qLvl && q.isEmpty()) q = p.name
                if (p.lvl == nLvl && n.isEmpty()) n = p.name
            }
        }
        return q to n
    }

    companion object {
        fun load(feats: List<Feature>, qLvl: Int, nLvl: Int): AdminIndex {
            val polys = Overpass.fetch(boundsOf(feats), setOf(Cat.ADMIN), setOf(qLvl, nLvl), emptySet())
            return AdminIndex(polys, qLvl, nLvl)
        }
    }
}
