package com.geotools.app

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

/**
 * "Add a feature" window: one field per attribute-table column
 * (name, type, Gategory, gather, Nahia, mohafadha, x, y, link).
 * x and y are UTM meters without zone and without decimals.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddFeatureDialog(lang: String, at: Ll, onSave: (Feature) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val zone = remember(at) { GeoConverter.zoneOf(at.lon) }
    val x0 = remember(at) { Math.round(GeoConverter.toUtm(at.lat, at.lon, zone).e).toString() }
    val y0 = remember(at) { Math.round(GeoConverter.toUtm(at.lat, at.lon, zone).n).toString() }

    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("") }
    var gat by remember { mutableStateOf("") }
    var gather by remember { mutableStateOf("") }
    var nahia by remember { mutableStateOf("") }
    var moh by remember { mutableStateOf("") }
    var x by remember(at) { mutableStateOf(x0) }
    var y by remember(at) { mutableStateOf(y0) }
    var link by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(tx(lang, "add_at_center")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text("name") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = type, onValueChange = { type = it }, singleLine = true,
                    label = { Text("type") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = gat, onValueChange = { gat = it }, singleLine = true,
                    label = { Text("Gategory") }, modifier = Modifier.fillMaxWidth()
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SECTORS.forEach { sec ->
                        FilterChip(selected = gat == sec, onClick = { gat = sec }, label = { Text(sec) })
                    }
                }
                OutlinedTextField(
                    value = gather, onValueChange = { gather = it }, singleLine = true,
                    label = { Text("gather") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nahia, onValueChange = { nahia = it }, singleLine = true,
                    label = { Text("Nahia") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = moh, onValueChange = { moh = it }, singleLine = true,
                    label = { Text("mohafadha") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = x, onValueChange = { x = it.filter { c -> c.isDigit() } }, singleLine = true,
                    label = { Text("x") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = y, onValueChange = { y = it.filter { c -> c.isDigit() } }, singleLine = true,
                    label = { Text("y") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = link, onValueChange = { link = it }, singleLine = true,
                    label = { Text("link") }, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val xv = x.toDoubleOrNull()
                val yv = y.toDoubleOrNull()
                if (xv == null || yv == null) {
                    Toast.makeText(ctx, tx(lang, "bad_coords"), Toast.LENGTH_SHORT).show()
                    return@TextButton
                }
                val pos = if (x == x0 && y == y0) at else GeoConverter.fromUtm(zone, at.lat >= 0, xv, yv)
                onSave(
                    Feature(
                        Cat.USER, Kind.POINT, name.trim(), type.trim(), listOf(listOf(pos)), "", gat.trim(),
                        mapOf("gather" to gather.trim(), "Nahia" to nahia.trim(), "mohafadha" to moh.trim(), "link" to link.trim())
                    )
                )
            }) { Text(tr(lang, "save_feat")) }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text(tr(lang, "cancel")) } }
    )
}
