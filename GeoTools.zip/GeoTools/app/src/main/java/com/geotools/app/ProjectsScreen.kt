package com.geotools.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun fileNameOf(ctx: Context, uri: Uri): String {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "file"
    }
    return uri.lastPathSegment ?: "file"
}

private val STATUSES = listOf("new" to "st_new", "review" to "st_review", "verified" to "st_verified")
private val FORMATS = listOf("GeoJSON", "GPX", "KML", "KMZ", "CSV")

/** Projects, features, import / export, backup and undo / redo. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProjectsScreen(cfg: Cfg, click: () -> Unit, onGoto: (Ll) -> Unit) {
    val ctx = LocalContext.current
    val lang = cfg.lang
    val t = { k: String -> tx(lang, k) }
    val db = remember { GisDb.get(ctx) }
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("gis_prefs", 0) }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    var cur by remember { mutableStateOf(prefs.getString("cur", GisDb.DEFAULT_ID) ?: GisDb.DEFAULT_ID) }
    var projects by remember { mutableStateOf<List<GisProject>>(emptyList()) }
    var feats by remember { mutableStateOf<List<GisFeature>>(emptyList()) }
    var total by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var statusF by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf("") }
    var inText by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<GisFeature?>(null) }
    var target by remember { mutableStateOf<GisFeature?>(null) }
    var menuProj by remember { mutableStateOf(false) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var pendingName by remember { mutableStateOf("") }
    var epsgText by remember { mutableStateOf("4326") }
    var importRes by remember { mutableStateOf<ImportResult?>(null) }
    var busy by remember { mutableStateOf(false) }
    var restoreText by remember { mutableStateOf("") }
    var restoreCounts by remember { mutableStateOf(0 to 0) }
    var exportFmt by remember { mutableStateOf("GeoJSON") }

    fun projName(p: GisProject) = if (p.id == GisDb.DEFAULT_ID) t("default_project") else p.name
    fun setCur(id: String) { cur = id; prefs.edit().putString("cur", id).apply() }

    LaunchedEffect(Unit) { db.syncMapFeatures(UserStore.load(ctx)) }
    LaunchedEffect(cur, query, statusF, tick) {
        projects = db.projects()
        if (projects.none { it.id == cur }) setCur(GisDb.DEFAULT_ID)
        feats = db.features(cur, query, statusF, 300)
        total = db.count(cur)
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingUri = uri; pendingName = fileNameOf(ctx, uri); epsgText = "4326"; dlg = "impopt"
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)!!.use { String(it.readBytes(), Charsets.UTF_8) }
                restoreCounts = db.peekJson(text)
                restoreText = text
                dlg = "restore"
            } catch (e: Exception) {
                toast(t("bad_file"))
            }
        }
    }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(db.exportJson().toByteArray(Charsets.UTF_8)) } }
            toast(t("saved"))
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            val all = withContext(Dispatchers.IO) { db.features(cur) }
            withContext(Dispatchers.IO) {
                ctx.contentResolver.openOutputStream(uri)!!.use { os ->
                    when (exportFmt) {
                        "GeoJSON" -> GeoIo.writeGeoJson(all, os)
                        "GPX" -> GeoIo.writeGpx(all, os)
                        "KML" -> GeoIo.writeKml(all, os)
                        "KMZ" -> GeoIo.writeKmz(all, os)
                        else -> GeoIo.writeCsv(all, os)
                    }
                }
            }
            toast(t("saved"))
        }
    }

    fun copyText(s: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("coords", s))
        toast(t("copied"))
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box {
                        OutlinedButton(onClick = { click(); menuProj = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(t("project") + ": " + (projects.firstOrNull { it.id == cur }?.let { projName(it) } ?: "") + "  (" + total + ")")
                        }
                        DropdownMenu(expanded = menuProj, onDismissRequest = { menuProj = false }) {
                            projects.forEach { p ->
                                DropdownMenuItem(text = { Text(projName(p)) }, onClick = { setCur(p.id); menuProj = false })
                            }
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { click(); inText = ""; dlg = "new" }) { Text(t("new_project")) }
                        OutlinedButton(onClick = {
                            click(); inText = projects.firstOrNull { it.id == cur }?.name ?: ""; dlg = "rename"
                        }, enabled = cur != GisDb.DEFAULT_ID) { Text(t("rename")) }
                        OutlinedButton(onClick = { click(); dlg = "delproj" }) { Text(t("delete")) }
                        OutlinedButton(onClick = {
                            click(); toast(if (db.undo(cur)) t("undone") else t("nothing")); tick++
                        }, enabled = db.canUndo(cur)) { Text(t("undo")) }
                        OutlinedButton(onClick = {
                            click(); if (db.redo(cur)) toast(t("redone")); tick++
                        }, enabled = db.canRedo(cur)) { Text(t("redo")) }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { click(); openLauncher.launch(arrayOf("*/*")) }) { Text(t("import_file")) }
                        Button(onClick = { click(); dlg = "export" }, enabled = total > 0) { Text(t("export")) }
                        OutlinedButton(onClick = { click(); backupLauncher.launch("geotools-backup.json") }) { Text(t("backup")) }
                        OutlinedButton(onClick = { click(); restoreLauncher.launch(arrayOf("*/*")) }) { Text(t("restore")) }
                    }
                    if (cur == GisDb.DEFAULT_ID) Text(t("map_note"), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text(t("search")) }, modifier = Modifier.fillMaxWidth()
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = statusF == null, onClick = { click(); statusF = null }, label = { Text(t("all")) })
                    STATUSES.forEach { (k, lk) ->
                        FilterChip(selected = statusF == k, onClick = { click(); statusF = k }, label = { Text(t(lk)) })
                    }
                }
                Button(onClick = { click(); editing = null; inText = ""; dlg = "edit" }, modifier = Modifier.fillMaxWidth()) {
                    Text(t("add_feature"))
                }
            }
        }
        if (feats.isEmpty()) item { Text(t("empty"), modifier = Modifier.padding(16.dp)) }
        items(feats, key = { it.id }) { f ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name.ifBlank { "—" }, style = MaterialTheme.typography.titleSmall)
                        val st = STATUSES.firstOrNull { it.first == f.status }?.second ?: "st_new"
                        Text(
                            listOf(f.category, t(st), f.kind.name).filter { it.isNotBlank() }.joinToString(" · "),
                            style = MaterialTheme.typography.bodySmall
                        )
                        val place = listOf(f.gov, f.qadha, f.nahiya).filter { it.isNotBlank() }.joinToString(" / ")
                        if (place.isNotEmpty()) Text(place, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { click(); onGoto(f.center()) }) { Text(t("goto")) }
                    TextButton(onClick = { click(); editing = f; inText = GeoConverter.fmtDd(f.center()); dlg = "edit" }) { Text(t("edit")) }
                    TextButton(onClick = { click(); target = f; dlg = "delfeat" }) { Text(t("delete")) }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    // ---------------- dialogs ----------------
    if (dlg == "new" || dlg == "rename") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text(t(if (dlg == "new") "new_project" else "rename")) },
            text = { OutlinedTextField(value = inText, onValueChange = { inText = it }, singleLine = true, label = { Text(t("name")) }) },
            confirmButton = {
                TextButton(onClick = {
                    if (inText.isNotBlank()) {
                        if (dlg == "new") setCur(db.createProject(inText.trim())) else db.renameProject(cur, inText.trim())
                        dlg = ""; tick++
                    }
                }) { Text(t("ok")) }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("cancel")) } }
        )
    }
    if (dlg == "delproj") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            text = { Text(t("delete_project_q")) },
            confirmButton = { TextButton(onClick = { db.deleteProject(cur); setCur(GisDb.DEFAULT_ID); dlg = ""; tick++ }) { Text(t("delete")) } },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("cancel")) } }
        )
    }
    if (dlg == "delfeat") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            text = { Text(t("delete_feature_q")) },
            confirmButton = { TextButton(onClick = { target?.let { db.delete(it.id) }; dlg = ""; tick++ }) { Text(t("delete")) } },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("cancel")) } }
        )
    }
    if (dlg == "export") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text(t("export")) },
            text = {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FORMATS.forEach { fm ->
                        FilterChip(selected = exportFmt == fm, onClick = { exportFmt = fm }, label = { Text(fm) })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    dlg = ""
                    exportLauncher.launch("geotools." + exportFmt.lowercase().replace("geojson", "geojson"))
                }) { Text(t("export")) }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("cancel")) } }
        )
    }
    if (dlg == "impopt") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text(t("import_opts")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(pendingName, style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = epsgText, onValueChange = { epsgText = it.filter { c -> c.isDigit() }.take(6) }, singleLine = true,
                        label = { Text(t("epsg_in")) }
                    )
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    val uri = pendingUri ?: return@TextButton
                    val code = epsgText.toIntOrNull() ?: 4326
                    busy = true
                    scope.launch {
                        try {
                            val r = withContext(Dispatchers.IO) { GeoIo.read(ctx, uri, pendingName, cur, code) }
                            importRes = r
                            dlg = "imppreview"
                        } catch (e: IllegalArgumentException) {
                            toast(t("unsupported")); dlg = ""
                        } catch (e: Exception) {
                            toast(t("read_fail")); dlg = ""
                        }
                        busy = false
                    }
                }) { Text(t("read_file")) }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("cancel")) } }
        )
    }
    if (dlg == "imppreview") {
        val r = importRes
        if (r != null) {
            AlertDialog(
                onDismissRequest = { dlg = "" },
                title = { Text(t("import_preview") + " (" + r.format + ")") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(t("n_points") + ": " + r.features.count { it.kind == Kind.POINT })
                        Text(t("n_lines") + ": " + r.features.count { it.kind == Kind.LINE })
                        Text(t("n_polys") + ": " + r.features.count { it.kind == Kind.POLYGON })
                        Text(t("n_skipped") + ": " + r.skipped)
                        Text(t("n_errors") + ": " + r.errors.size)
                        Text(t("n_dups") + ": " + r.duplicates)
                        if (r.duplicates > 0) Text(t("dups_hint"), style = MaterialTheme.typography.bodySmall)
                        r.errors.take(8).forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                    }
                },
                confirmButton = {
                    TextButton(enabled = r.features.isNotEmpty() && !busy, onClick = {
                        busy = true
                        scope.launch {
                            withContext(Dispatchers.IO) { db.insertAll(r.features) }
                            toast(t("imported").format(r.features.size))
                            busy = false; dlg = ""; importRes = null; tick++
                        }
                    }) { Text(t("import_add")) }
                },
                dismissButton = { TextButton(onClick = { dlg = ""; importRes = null }) { Text(t("cancel")) } }
            )
        }
    }
    if (dlg == "restore") {
        AlertDialog(
            onDismissRequest = { dlg = "" },
            text = { Text(t("restore_q").format(restoreCounts.first, restoreCounts.second)) },
            confirmButton = {
                TextButton(onClick = {
                    try { db.importJson(restoreText); toast(t("restored")) } catch (e: Exception) { toast(t("bad_file")) }
                    dlg = ""; tick++
                }) { Text(t("restore")) }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("cancel")) } }
        )
    }
    if (dlg == "edit") {
        val old = editing
        var nameAr by remember(old) { mutableStateOf(old?.name ?: "") }
        var nameEn by remember(old) { mutableStateOf(old?.nameEn ?: "") }
        var category by remember(old) { mutableStateOf(old?.category ?: "") }
        var desc by remember(old) { mutableStateOf(old?.description ?: "") }
        var notes by remember(old) { mutableStateOf(old?.notes ?: "") }
        var status by remember(old) { mutableStateOf(old?.status ?: "new") }
        var acc by remember(old) { mutableStateOf(if ((old?.accuracy ?: 0.0) > 0) old!!.accuracy.toString() else "") }
        var gov by remember(old) { mutableStateOf(old?.gov ?: "") }
        var qadha by remember(old) { mutableStateOf(old?.qadha ?: "") }
        var nahiya by remember(old) { mutableStateOf(old?.nahiya ?: "") }
        var copyMenu by remember { mutableStateOf(false) }
        val editable = old == null || old.kind == Kind.POINT
        val parsed: Parsed? = remember(inText) {
            if (inText.isBlank()) null else try { GeoConverter.parseAuto(inText) } catch (e: Exception) { null }
        }
        AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text(t(if (old == null) "add_feature" else "edit")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nameAr, onValueChange = { nameAr = it }, singleLine = true, label = { Text("name") })
                    OutlinedTextField(value = category, onValueChange = { category = it }, singleLine = true, label = { Text("Gategory") })
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val options = if (category.isNotBlank() && category !in SECTORS) SECTORS + category else SECTORS
                        options.forEach { sec ->
                            FilterChip(selected = category == sec, onClick = { category = sec }, label = { Text(sec) })
                        }
                    }
                    if (editable) {
                        OutlinedTextField(
                            value = inText, onValueChange = { inText = it }, label = { Text(t("coords_in")) },
                            isError = inText.isNotBlank() && parsed == null
                        )
                    } else {
                        Text(GeoConverter.fmtDd(old!!.center()) + "  (" + old.parts.sumOf { it.size } + ")")
                    }
                    val shown = parsed?.ll ?: old?.center()
                    if (shown != null) {
                        Box {
                            OutlinedButton(onClick = { copyMenu = true }) { Text(t("copy_as")) }
                            DropdownMenu(expanded = copyMenu, onDismissRequest = { copyMenu = false }) {
                                listOf(
                                    "DD" to GeoConverter.fmtDd(shown), "DMS" to GeoConverter.fmtDms(shown),
                                    "DDM" to GeoConverter.fmtDdm(shown),
                                    "UTM" to GeoConverter.fmtUtm(GeoConverter.toUtm(shown.lat, shown.lon)),
                                    "MGRS" to GeoConverter.toMgrs(shown.lat, shown.lon)
                                ).forEach { (k, v) ->
                                    DropdownMenuItem(text = { Text("$k  $v") }, onClick = { copyText(v); copyMenu = false })
                                }
                            }
                        }
                    }
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text(t("description")) })
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(t("notes")) })
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        STATUSES.forEach { (k, lk) -> FilterChip(selected = status == k, onClick = { status = k }, label = { Text(t(lk)) }) }
                    }
                    OutlinedTextField(value = acc, onValueChange = { acc = it }, singleLine = true, label = { Text(t("accuracy")) })
                    OutlinedTextField(value = gov, onValueChange = { gov = it }, singleLine = true, label = { Text("mohafadha") })
                    OutlinedTextField(value = qadha, onValueChange = { qadha = it }, singleLine = true, label = { Text("gather") })
                    OutlinedTextField(value = nahiya, onValueChange = { nahiya = it }, singleLine = true, label = { Text("Nahia") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val accV = GeoConverter.normalize(acc).toDoubleOrNull() ?: 0.0
                    if (old == null) {
                        val p = parsed
                        if (p == null) { toast(t("bad_coords")); return@TextButton }
                        db.insert(
                            GisFeature(
                                projectId = cur, name = nameAr.trim(), nameEn = nameEn.trim(), category = category.trim(),
                                kind = Kind.POINT, parts = listOf(listOf(p.ll)), gov = gov, qadha = qadha, nahiya = nahiya,
                                description = desc, notes = notes, source = "manual", status = status, accuracy = accV
                            )
                        )
                    } else {
                        var parts = old.parts
                        if (old.kind == Kind.POINT) {
                            val p = parsed
                            if (p == null) { toast(t("bad_coords")); return@TextButton }
                            parts = listOf(listOf(p.ll))
                        }
                        db.update(
                            old.copy(
                                name = nameAr.trim(), nameEn = nameEn.trim(), category = category.trim(), parts = parts,
                                gov = gov, qadha = qadha, nahiya = nahiya, description = desc, notes = notes,
                                status = status, accuracy = accV
                            )
                        )
                    }
                    dlg = ""; tick++; toast(t("saved"))
                }) { Text(t("save")) }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text(t("cancel")) } }
        )
    }
}
