package com.geotools.app

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.view.MotionEvent
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import kotlin.math.hypot

class PPoint(val lat: Double, val lon: Double, val color: Int, val label: String)

/** Draws many features as colored dots (names appear when zoomed in) and reports taps. */
class PointsOverlay(
    private val pts: List<PPoint>,
    private val onPick: (Int) -> Unit
) : Overlay() {
    private val fill = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
    private val ring = Paint().apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = 0xFFFFFFFF.toInt(); isAntiAlias = true
    }
    private val txt = Paint().apply { textSize = 30f; isAntiAlias = true; color = 0xFF000000.toInt() }
    private val halo = Paint().apply {
        textSize = 30f; isAntiAlias = true; color = 0xFFFFFFFF.toInt()
        style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val gp = GeoPoint(0.0, 0.0)

    override fun draw(c: Canvas, mv: MapView, shadow: Boolean) {
        if (shadow) return
        val p = mv.projection
        val bb = mv.boundingBox
        val labels = mv.zoomLevelDouble >= 14.0
        val rotated = mv.mapOrientation != 0f
        val cx = mv.width / 2f
        val cy = mv.height / 2f
        val rad = Math.hypot(mv.width.toDouble(), mv.height.toDouble()) / 2 + 60
        val pt = Point()
        for (q in pts) {
            if (!rotated && (q.lat > bb.latNorth || q.lat < bb.latSouth || q.lon > bb.lonEast || q.lon < bb.lonWest)) continue
            gp.setCoords(q.lat, q.lon)
            p.toPixels(gp, pt)
            val x = pt.x.toFloat()
            val y = pt.y.toFloat()
            if (rotated && Math.hypot((x - cx).toDouble(), (y - cy).toDouble()) > rad) continue
            fill.color = q.color
            c.drawCircle(x, y, 11f, fill)
            c.drawCircle(x, y, 11f, ring)
            if (labels && q.label.isNotEmpty()) {
                c.drawText(q.label, x + 16f, y + 10f, halo)
                c.drawText(q.label, x + 16f, y + 10f, txt)
            }
        }
    }

    override fun onSingleTapConfirmed(e: MotionEvent, mv: MapView): Boolean {
        val p = mv.projection
        val pt = Point()
        var best = -1
        var bd = Float.MAX_VALUE
        pts.forEachIndexed { i, q ->
            gp.setCoords(q.lat, q.lon)
            p.toPixels(gp, pt)
            val d = hypot(e.x - pt.x, e.y - pt.y)
            if (d < 48f && d < bd) { bd = d; best = i }
        }
        if (best >= 0) { onPick(best); return true }
        return false
    }
}
