package com.geotools.app

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile

@Composable
fun SettingsScreen(cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit) {
    val ctx = LocalContext.current
    val t = { k: String -> tr(cfg.lang, k) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            setCfg(cfg.copy(tree = uri.toString()))
        }
    }
    var dlg by remember { mutableStateOf("") }
    val folderName = if (cfg.tree.isEmpty()) t("default_folder")
    else DocumentFile.fromTreeUri(ctx, Uri.parse(cfg.tree))?.name ?: cfg.tree

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(t("theme"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf(t("system"), t("light"), t("dark")), cfg.theme, click) { setCfg(cfg.copy(theme = it)) }

        Text(t("accent"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf(t("a_blue"), t("a_green"), t("a_orange"), t("a_purple")), cfg.accent, click) {
            setCfg(cfg.copy(accent = it))
        }

        Text(t("language"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf("العربية", "English"), if (cfg.lang == "ar") 0 else 1, click) {
            setCfg(cfg.copy(lang = if (it == 0) "ar" else "en"))
        }

        Text(t("map_type"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf(t("mt_std"), t("mt_topo"), t("mt_sat")), cfg.mapType, click) { setCfg(cfg.copy(mapType = it)) }

        Text(t("folder"), style = MaterialTheme.typography.titleSmall)
        Text(folderName)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { click(); launcher.launch(null) }) { Text(t("choose_folder")) }
            if (cfg.tree.isNotEmpty()) OutlinedButton(onClick = { click(); setCfg(cfg.copy(tree = "")) }) {
                Text(t("default_folder"))
            }
        }

        Text(t("fmt"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf("DD", "DMS", "UTM", "MGRS"), cfg.fmt, click) { setCfg(cfg.copy(fmt = it)) }

        Text(t("sel_mode"), style = MaterialTheme.typography.titleSmall)
        Choice(listOf(t("center_size"), t("two_corners")), cfg.selMode, click) { setCfg(cfg.copy(selMode = it)) }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("sound"), Modifier.weight(1f))
            Switch(checked = cfg.sound, onCheckedChange = { setCfg(cfg.copy(sound = it)) })
        }

        HorizontalDivider()
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("gp_layer"), Modifier.weight(1f))
            Switch(checked = cfg.gp, onCheckedChange = { setCfg(cfg.copy(gp = it)) })
        }
        if (cfg.gp) {
            Field(t("gp_key"), cfg.gpKey) { setCfg(cfg.copy(gpKey = it.trim())) }
            Text(t("gp_hint"), style = MaterialTheme.typography.bodySmall)
        }

        HorizontalDivider()
        Text(t("lock"), style = MaterialTheme.typography.titleSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("lock_enable"), Modifier.weight(1f))
            Switch(checked = cfg.lockOn, onCheckedChange = { dlg = if (it) "set" else "disable" })
        }
        if (cfg.lockOn) {
            Text(t("lock_after"), style = MaterialTheme.typography.labelLarge)
            Choice(listOf(t("s30"), t("m1"), t("m2"), t("m5"), t("never")), cfg.lockTimeout, click) {
                setCfg(cfg.copy(lockTimeout = it))
            }
            OutlinedButton(onClick = { click(); dlg = "change" }) { Text(t("change_pin")) }
        }
    }
    if (dlg.isNotEmpty()) {
        PinDialog(cfg.lang, dlg, { dlg = "" }) { pin ->
            if (dlg == "disable") PinStore.clear(ctx) else PinStore.set(ctx, pin)
            setCfg(cfg.copy(lockOn = PinStore.isSet(ctx)))
            dlg = ""
        }
    }
}
