package com.geotools.app

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Place(val name: String, val lat: Double, val lon: Double, val box: Rect?)

object Geocoder {
    fun search(q: String, lang: String): List<Place> {
        return try {
            val u = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&accept-language=$lang&q=" +
                    URLEncoder.encode(q, "UTF-8")
            val conn = URL(u).openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "GeoTools-Android/1.0")
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            val arr = JSONArray(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val bb = o.optJSONArray("boundingbox")
                val box = if (bb != null && bb.length() == 4)
                    Rect(bb.getString(0).toDouble(), bb.getString(2).toDouble(),
                        bb.getString(1).toDouble(), bb.getString(3).toDouble())
                else null
                Place(o.optString("display_name"), o.getString("lat").toDouble(), o.getString("lon").toDouble(), box)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
