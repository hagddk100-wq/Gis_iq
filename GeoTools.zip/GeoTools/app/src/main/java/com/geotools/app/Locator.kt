package com.geotools.app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper

object Locator {
    @SuppressLint("MissingPermission")
    fun once(ctx: Context, onFix: (Location) -> Unit, onFail: () -> Unit) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val provs = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter {
            try { lm.isProviderEnabled(it) } catch (e: Exception) { false }
        }
        if (provs.isEmpty()) { onFail(); return }
        val last = provs.mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null }
        }.maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 60000) { onFix(last); return }

        var done = false
        val l = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                if (done) return
                done = true
                lm.removeUpdates(this)
                onFix(loc)
            }
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        try {
            provs.forEach { lm.requestLocationUpdates(it, 0L, 0f, l, Looper.getMainLooper()) }
        } catch (e: SecurityException) {
            onFail(); return
        }
        Handler(Looper.getMainLooper()).postDelayed({
            if (!done) {
                done = true
                lm.removeUpdates(l)
                if (last != null) onFix(last) else onFail()
            }
        }, 20000)
    }
}
