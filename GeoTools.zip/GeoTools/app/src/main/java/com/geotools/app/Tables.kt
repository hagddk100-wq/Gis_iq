package com.geotools.app

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Reading CSV / TXT / XLSX tables and writing a simple XLSX. */
object Tables {
    fun xmlEsc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun splitLine(line: String, d: Char): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (q) {
                if (c == '"') {
                    if (i + 1 < line.length && line[i + 1] == '"') { sb.append('"'); i++ } else q = false
                } else sb.append(c)
            } else if (c == '"') q = true
            else if (c == d) { out.add(sb.toString().trim()); sb.setLength(0) }
            else sb.append(c)
            i++
        }
        out.add(sb.toString().trim())
        return out
    }

    private fun detectDelimiter(first: String): Char {
        val cands = charArrayOf(',', ';', '\t')
        return cands.maxByOrNull { c -> first.count { it == c } }?.takeIf { first.contains(it) } ?: ','
    }

    /** Streams the rows of a CSV/TXT file (UTF-8, BOM tolerated) without loading it whole. */
    fun csvRows(input: InputStream): Sequence<List<String>> = sequence {
        val r = BufferedReader(InputStreamReader(input, Charsets.UTF_8))
        var d: Char? = null
        var first = true
        while (true) {
            var line = r.readLine() ?: break
            if (first) { line = line.removePrefix("\uFEFF"); first = false }
            if (line.isBlank()) continue
            if (d == null) d = detectDelimiter(line)
            yield(splitLine(line, d))
        }
        r.close()
    }

    fun rows(input: InputStream, ext: String): Sequence<List<String>> =
        if (ext == "xlsx") readXlsx(input).asSequence() else csvRows(input)

    // ---------------- XLSX reading ----------------
    fun readXlsx(input: InputStream): List<List<String>> {
        val zin = ZipInputStream(input)
        var shared: List<String> = emptyList()
        val sheets = HashMap<String, ByteArray>()
        var e: ZipEntry? = zin.nextEntry
        while (e != null) {
            val n = e.name
            if (n == "xl/sharedStrings.xml") shared = parseShared(zin.readBytes())
            else if (n.startsWith("xl/worksheets/sheet") && n.endsWith(".xml")) sheets[n] = zin.readBytes()
            e = zin.nextEntry
        }
        val first = sheets.keys.minOrNull() ?: return emptyList()
        return parseSheet(sheets[first]!!, shared)
    }

    private fun parseShared(b: ByteArray): List<String> {
        val out = ArrayList<String>()
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(b), "UTF-8")
        var sb: StringBuilder? = null
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                if (p.name == "si") sb = StringBuilder() else if (p.name == "t") inT = true
            } else if (ev == XmlPullParser.TEXT) {
                if (inT) sb?.append(p.text)
            } else if (ev == XmlPullParser.END_TAG) {
                if (p.name == "t") inT = false
                else if (p.name == "si") { out.add(sb?.toString() ?: ""); sb = null }
            }
            ev = p.next()
        }
        return out
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break }
        return n - 1
    }

    private fun parseSheet(b: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(b), "UTF-8")
        var cur = ArrayList<String>()
        var idx = 0
        var type = ""
        var text = StringBuilder()
        var inV = false
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "row" -> cur = ArrayList()
                    "c" -> {
                        idx = colIndex(p.getAttributeValue(null, "r") ?: "A1")
                        type = p.getAttributeValue(null, "t") ?: ""
                        text = StringBuilder()
                    }
                    "v" -> inV = true
                    "t" -> inT = true
                }
            } else if (ev == XmlPullParser.TEXT) {
                if (inV || inT) text.append(p.text)
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val v = if (type == "s") shared.getOrElse(text.toString().trim().toIntOrNull() ?: -1) { "" } else text.toString()
                        while (cur.size <= idx) cur.add("")
                        cur[idx] = v
                    }
                    "row" -> rows.add(cur)
                }
            }
            ev = p.next()
        }
        return rows
    }

    // ---------------- XLSX writing ----------------
    private fun colName(i0: Int): String {
        var i = i0
        val sb = StringBuilder()
        while (true) {
            sb.insert(0, ('A' + i % 26))
            i = i / 26 - 1
            if (i < 0) break
        }
        return sb.toString()
    }

    /** Cells that parse as numbers are written as numbers, everything else as text. */
    fun writeXlsx(header: List<String>, rows: List<List<String>>, out: OutputStream, numericFrom: Set<Int> = emptySet()) {
        val z = ZipOutputStream(out)
        fun put(name: String, text: String) {
            z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry()
        }
        val xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        put("[Content_Types].xml", xml + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>")
        put("_rels/.rels", xml + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
        put("xl/workbook.xml", xml + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>")
        put("xl/_rels/workbook.xml.rels", xml + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>")
        val sb = StringBuilder(xml)
        sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        fun row(r: Int, cells: List<String>, isHeader: Boolean) {
            sb.append("<row r=\"").append(r).append("\">")
            cells.forEachIndexed { i, v ->
                val ref = colName(i) + r
                if (!isHeader && i in numericFrom && v.toDoubleOrNull() != null) sb.append("<c r=\"$ref\"><v>$v</v></c>")
                else sb.append("<c r=\"$ref\" t=\"inlineStr\"><is><t>").append(xmlEsc(v)).append("</t></is></c>")
            }
            sb.append("</row>")
        }
        row(1, header, true)
        rows.forEachIndexed { i, r -> row(i + 2, r, false) }
        sb.append("</sheetData></worksheet>")
        put("xl/worksheets/sheet1.xml", sb.toString())
        z.finish()
        z.flush()
    }
}
