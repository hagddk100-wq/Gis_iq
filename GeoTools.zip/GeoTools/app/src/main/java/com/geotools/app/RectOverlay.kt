package com.geotools.app

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.view.MotionEvent
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Selection rectangle: drag inside to move it, drag a corner handle to resize it. */
class RectOverlay(
    private val getRect: () -> Rect?,
    private val editable: () -> Boolean,
    private val onChange: (Rect) -> Unit
) : Overlay() {

    private val fill = Paint().apply { color = 0x330066FF; style = Paint.Style.FILL }
    private val line = Paint().apply {
        color = 0xFF0066FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = true
    }
    private val handleFill = Paint().apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.FILL; isAntiAlias = true }

    private var drag = 0 // 0 none, 1 move, 2 NW, 3 NE, 4 SE, 5 SW
    private var working: Rect? = null
    private var lastX = 0f
    private var lastY = 0f

    override fun draw(c: Canvas, mv: MapView, shadow: Boolean) {
        if (shadow) return
        val r = (if (drag != 0) working else getRect()) ?: return
        val p = mv.projection
        val a = p.toPixels(GeoPoint(r.n, r.w), Point())
        val b = p.toPixels(GeoPoint(r.s, r.e), Point())
        val x0 = a.x.toFloat(); val y0 = a.y.toFloat(); val x1 = b.x.toFloat(); val y1 = b.y.toFloat()
        c.drawRect(x0, y0, x1, y1, fill)
        c.drawRect(x0, y0, x1, y1, line)
        if (editable()) {
            for ((hx, hy) in listOf(x0 to y0, x1 to y0, x1 to y1, x0 to y1)) {
                c.drawCircle(hx, hy, 18f, handleFill)
                c.drawCircle(hx, hy, 18f, line)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent, mv: MapView): Boolean {
        if (!editable()) return false
        val p = mv.projection
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val r = getRect() ?: return false
                val a = p.toPixels(GeoPoint(r.n, r.w), Point())
                val b = p.toPixels(GeoPoint(r.s, r.e), Point())
                val x = e.x; val y = e.y; val hit = 64f
                fun near(px: Int, py: Int) = abs(x - px) < hit && abs(y - py) < hit
                drag = when {
                    near(a.x, a.y) -> 2
                    near(b.x, a.y) -> 3
                    near(b.x, b.y) -> 4
                    near(a.x, b.y) -> 5
                    x >= min(a.x, b.x) && x <= max(a.x, b.x) && y >= min(a.y, b.y) && y <= max(a.y, b.y) -> 1
                    else -> 0
                }
                working = r
                lastX = x; lastY = y
                return drag != 0
            }
            MotionEvent.ACTION_MOVE -> {
                if (drag == 0) return false
                if (e.pointerCount > 1) return true
                val r = working ?: return true
                val np = p.fromPixels(e.x.toInt(), e.y.toInt())
                val nr: Rect = when (drag) {
                    1 -> {
                        val op = p.fromPixels(lastX.toInt(), lastY.toInt())
                        val dLat = np.latitude - op.latitude
                        val dLon = np.longitude - op.longitude
                        Rect(r.s + dLat, r.w + dLon, r.n + dLat, r.e + dLon)
                    }
                    2 -> Rect(r.s, np.longitude, np.latitude, r.e)
                    3 -> Rect(r.s, r.w, np.latitude, np.longitude)
                    4 -> Rect(np.latitude, r.w, r.n, np.longitude)
                    else -> Rect(np.latitude, np.longitude, r.n, r.e)
                }
                val fixed = Rect(min(nr.s, nr.n), min(nr.w, nr.e), max(nr.s, nr.n), max(nr.w, nr.e))
                working = fixed
                lastX = e.x; lastY = e.y
                onChange(fixed)
                mv.invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (drag != 0) {
                    drag = 0
                    mv.invalidate()
                    return true
                }
                return false
            }
        }
        return drag != 0
    }
}
