package com.geotools.app

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.view.MotionEvent
import org.osmdroid.api.IGeoPoint
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Selection rectangle: drag inside to move it, drag a corner to resize it, drag the orange handle to rotate it.
 * Single-finger gestures edit the rectangle; a second finger hands control back to the map (pan / zoom / rotate).
 */
class RectOverlay(
    private val getRect: () -> Rect?,
    private val editable: () -> Boolean,
    private val onChange: (Rect) -> Unit
) : Overlay() {

    private val fill = Paint().apply { color = 0x330066FF; style = Paint.Style.FILL }
    private val line = Paint().apply {
        color = 0xFF0066FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = true
    }
    private val handleFill = Paint().apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.FILL; isAntiAlias = true }
    private val rotFill = Paint().apply { color = 0xFFFF9800.toInt(); style = Paint.Style.FILL; isAntiAlias = true }
    private val rotLine = Paint().apply {
        color = 0xFFFF9800.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true
    }

    private var drag = 0 // 0 none, 1 move, 2 NW, 3 NE, 4 SE, 5 SW, 6 rotate
    private var working: Rect? = null
    private var lastX = 0f
    private var lastY = 0f

    private fun screenCorners(mv: MapView, r: Rect): List<Point> =
        rectCorners(r).map { mv.projection.toPixels(GeoPoint(it.lat, it.lon), Point()) }

    private fun handlePos(q: List<Point>): Pair<Float, Float> {
        val mx = (q[0].x + q[1].x) / 2f
        val my = (q[0].y + q[1].y) / 2f
        val cx = (q[0].x + q[2].x) / 2f
        val cy = (q[0].y + q[2].y) / 2f
        val dx = mx - cx
        val dy = my - cy
        val d = hypot(dx, dy).coerceAtLeast(1f)
        return (mx + dx / d * 70f) to (my + dy / d * 70f)
    }

    private fun inQuad(x: Float, y: Float, q: List<Point>): Boolean {
        var inside = false
        var j = q.size - 1
        for (i in q.indices) {
            val a = q[i]
            val b = q[j]
            if ((a.y > y) != (b.y > y) && x < (b.x - a.x) * (y - a.y).toFloat() / (b.y - a.y) + a.x) inside = !inside
            j = i
        }
        return inside
    }

    override fun draw(c: Canvas, mv: MapView, shadow: Boolean) {
        if (shadow) return
        val r = (if (drag != 0) working else getRect()) ?: return
        val q = screenCorners(mv, r)
        val path = Path().apply {
            moveTo(q[0].x.toFloat(), q[0].y.toFloat())
            for (i in 1..3) lineTo(q[i].x.toFloat(), q[i].y.toFloat())
            close()
        }
        c.drawPath(path, fill)
        c.drawPath(path, line)
        if (editable()) {
            for (p in q) {
                c.drawCircle(p.x.toFloat(), p.y.toFloat(), 18f, handleFill)
                c.drawCircle(p.x.toFloat(), p.y.toFloat(), 18f, line)
            }
            val (hx, hy) = handlePos(q)
            val mx = (q[0].x + q[1].x) / 2f
            val my = (q[0].y + q[1].y) / 2f
            c.drawLine(mx, my, hx, hy, rotLine)
            c.drawCircle(hx, hy, 22f, rotFill)
            c.drawCircle(hx, hy, 22f, rotLine)
        }
    }

    private fun resize(r: Rect, h: Int, np: IGeoPoint): Rect {
        val cLat = (r.s + r.n) / 2
        val cLon = (r.w + r.e) / 2
        val ml = mLon(cLat)
        val hw = (r.e - r.w) / 2 * ml
        val hh = (r.n - r.s) / 2 * M_LAT
        val a = Math.toRadians(r.rot)
        val cs = cos(a)
        val sn = sin(a)
        val x = (np.longitude - cLon) * ml
        val y = (np.latitude - cLat) * M_LAT
        val nx = x * cs - y * sn
        val ny = x * sn + y * cs
        val (ox, oy) = when (h) {
            2 -> hw to -hh
            3 -> -hw to -hh
            4 -> -hw to hh
            else -> hw to hh
        }
        val lcx = (ox + nx) / 2
        val lcy = (oy + ny) / 2
        val nhw = max(abs(nx - ox) / 2, 0.5)
        val nhh = max(abs(ny - oy) / 2, 0.5)
        val gx = lcx * cs + lcy * sn
        val gy = -lcx * sn + lcy * cs
        val nLat = cLat + gy / M_LAT
        val nLon = cLon + gx / ml
        val ml2 = mLon(nLat)
        return Rect(nLat - nhh / M_LAT, nLon - nhw / ml2, nLat + nhh / M_LAT, nLon + nhw / ml2, r.rot)
    }

    override fun onTouchEvent(e: MotionEvent, mv: MapView): Boolean {
        if (!editable()) return false
        val p = mv.projection
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val r = getRect() ?: return false
                val q = screenCorners(mv, r)
                val (hx, hy) = handlePos(q)
                val x = e.x
                val y = e.y
                fun near(px: Float, py: Float) = hypot(x - px, y - py) < 64f
                drag = when {
                    near(hx, hy) -> 6
                    near(q[0].x.toFloat(), q[0].y.toFloat()) -> 2
                    near(q[1].x.toFloat(), q[1].y.toFloat()) -> 3
                    near(q[2].x.toFloat(), q[2].y.toFloat()) -> 4
                    near(q[3].x.toFloat(), q[3].y.toFloat()) -> 5
                    inQuad(x, y, q) -> 1
                    else -> 0
                }
                working = r
                lastX = x
                lastY = y
                // The map still sees the first finger so that a second finger can pan / zoom / rotate it.
                return false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                drag = 0
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (drag == 0) return false
                if (e.pointerCount > 1) { drag = 0; return false }
                val r = working ?: return true
                val np = p.fromPixels(e.x.toInt(), e.y.toInt())
                val nr: Rect = when (drag) {
                    1 -> {
                        val op = p.fromPixels(lastX.toInt(), lastY.toInt())
                        val dLat = np.latitude - op.latitude
                        val dLon = np.longitude - op.longitude
                        r.copy(s = r.s + dLat, w = r.w + dLon, n = r.n + dLat, e = r.e + dLon)
                    }
                    6 -> {
                        val cLat = (r.s + r.n) / 2
                        val cLon = (r.w + r.e) / 2
                        val x = (np.longitude - cLon) * mLon(cLat)
                        val y = (np.latitude - cLat) * M_LAT
                        var deg = Math.toDegrees(atan2(x, y))
                        if (deg < 0) deg += 360.0
                        for (a in listOf(0.0, 90.0, 180.0, 270.0, 360.0)) if (abs(deg - a) < 3.0) deg = a % 360.0
                        r.copy(rot = deg)
                    }
                    else -> resize(r, drag, np)
                }
                working = nr
                lastX = e.x
                lastY = e.y
                onChange(nr)
                mv.invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (drag != 0) {
                    drag = 0
                    mv.invalidate()
                    return true
                }
                return false
            }
        }
        return false
    }
}
