package com.geotools.app

/** Strings for the project / import-export / layer-manager features (kept apart from Strings.kt). */
private val TX_AR = mapOf(
    "add_at_center" to "إضافة معلم في مركز الخريطة", "layers" to "إدارة الطبقات", "layers_hint" to "غيّر اللون والشفافية والسماكة والترتيب. الطبقة العليا في القائمة تُرسم فوق ما تحتها",
    "opacity" to "الشفافية", "width" to "السماكة", "close" to "إغلاق", "gplaces" to "أماكن من الإنترنت (API)",
    "default_project" to "المشروع الافتراضي", "project" to "المشروع", "new_project" to "مشروع جديد", "rename" to "إعادة تسمية",
    "delete" to "حذف", "delete_project_q" to "حذف المشروع وكل معالمه وسجله؟", "delete_feature_q" to "حذف هذا المعلم؟ يمكنك التراجع بعده",
    "cancel" to "إلغاء", "ok" to "موافق", "save" to "حفظ", "name" to "الاسم", "name_ar" to "الاسم بالعربية", "name_en" to "الاسم بالإنجليزية",
    "category" to "التصنيف", "description" to "الوصف", "notes" to "ملاحظات", "status" to "الحالة", "accuracy" to "دقة الموقع (م)",
    "gov" to "المحافظة", "qadha" to "القضاء", "nahiya" to "الناحية", "coords_in" to "الإحداثية (يتعرف عليها تلقائياً)",
    "search" to "بحث بالاسم أو النوع", "features" to "المعالم", "add_feature" to "إضافة معلم", "edit" to "تعديل", "goto" to "انتقال",
    "undo" to "تراجع", "redo" to "إعادة", "import_file" to "استيراد ملف", "export" to "تصدير", "backup" to "نسخ احتياطي", "restore" to "استعادة",
    "st_new" to "جديد", "st_review" to "قيد المراجعة", "st_verified" to "موثّق", "all" to "الكل",
    "cat_school" to "مدرسة", "cat_hospital" to "مستشفى", "cat_mosque" to "مسجد", "cat_bridge" to "جسر", "cat_road" to "طريق",
    "cat_village" to "قرية", "cat_building" to "مبنى", "cat_well" to "بئر", "cat_archaeological" to "أثر", "cat_government" to "موقع حكومي",
    "cat_border" to "نقطة حدودية", "empty" to "لا توجد معالم في هذا المشروع بعد", "map_note" to "رسوماتك من الخريطة تُحفظ تلقائياً في المشروع الافتراضي",
    "copy_as" to "نسخ الإحداثية", "copied" to "تم النسخ", "bad_coords" to "إحداثية غير صالحة", "saved" to "تم الحفظ",
    "import_opts" to "خيارات الاستيراد", "epsg_in" to "رمز EPSG للإحداثيات (للملفات النصية فقط، الافتراضي 4326)", "read_file" to "قراءة الملف",
    "import_preview" to "معاينة الاستيراد", "import_add" to "إضافة إلى المشروع", "imported" to "تمت إضافة %d معلماً",
    "n_points" to "نقاط", "n_lines" to "خطوط", "n_polys" to "مضلعات", "n_errors" to "أخطاء", "n_skipped" to "سجلات متجاهلة", "n_dups" to "مكررة محتملة",
    "dups_hint" to "ستُضاف كلها كما هي دون حذف أي بيانات موجودة. راجع المكررات بعد الاستيراد",
    "unsupported" to "صيغة غير مدعومة (المدعوم: GeoJSON, GPX, KML, KMZ, CSV, TXT)", "read_fail" to "تعذر قراءة الملف",
    "restore_q" to "سيتم دمج النسخة الاحتياطية مع بياناتك دون حذف شيء. المشاريع: %d، المعالم: %d", "restored" to "تمت الاستعادة",
    "undone" to "تم التراجع", "redone" to "تمت الإعادة", "nothing" to "لا يوجد ما يُتراجع عنه", "bad_file" to "ملف غير صالح"
)

private val TX_EN = mapOf(
    "add_at_center" to "Add a feature at the map center", "layers" to "Layer manager", "layers_hint" to "Change color, opacity, width and order. Layers higher in the list are drawn on top",
    "opacity" to "Opacity", "width" to "Width", "close" to "Close", "gplaces" to "Online places (API)",
    "default_project" to "Default project", "project" to "Project", "new_project" to "New project", "rename" to "Rename",
    "delete" to "Delete", "delete_project_q" to "Delete the project with all its features and history?", "delete_feature_q" to "Delete this feature? You can undo afterwards",
    "cancel" to "Cancel", "ok" to "OK", "save" to "Save", "name" to "Name", "name_ar" to "Arabic name", "name_en" to "English name",
    "category" to "Category", "description" to "Description", "notes" to "Notes", "status" to "Status", "accuracy" to "Location accuracy (m)",
    "gov" to "Governorate", "qadha" to "Qadha", "nahiya" to "Nahiya", "coords_in" to "Coordinate (auto-detected)",
    "search" to "Search by name or type", "features" to "Features", "add_feature" to "Add feature", "edit" to "Edit", "goto" to "Go to",
    "undo" to "Undo", "redo" to "Redo", "import_file" to "Import file", "export" to "Export", "backup" to "Backup", "restore" to "Restore",
    "st_new" to "New", "st_review" to "Under review", "st_verified" to "Verified", "all" to "All",
    "cat_school" to "School", "cat_hospital" to "Hospital", "cat_mosque" to "Mosque", "cat_bridge" to "Bridge", "cat_road" to "Road",
    "cat_village" to "Village", "cat_building" to "Building", "cat_well" to "Well", "cat_archaeological" to "Archaeological", "cat_government" to "Government site",
    "cat_border" to "Border point", "empty" to "No features in this project yet", "map_note" to "Your map drawings are saved automatically in the default project",
    "copy_as" to "Copy coordinate", "copied" to "Copied", "bad_coords" to "Invalid coordinate", "saved" to "Saved",
    "import_opts" to "Import options", "epsg_in" to "EPSG code of the coordinates (text files only, default 4326)", "read_file" to "Read file",
    "import_preview" to "Import preview", "import_add" to "Add to project", "imported" to "%d features added",
    "n_points" to "Points", "n_lines" to "Lines", "n_polys" to "Polygons", "n_errors" to "Errors", "n_skipped" to "Skipped records", "n_dups" to "Possible duplicates",
    "dups_hint" to "Everything is added as is; no existing data is removed. Review duplicates afterwards",
    "unsupported" to "Unsupported format (supported: GeoJSON, GPX, KML, KMZ, CSV, TXT)", "read_fail" to "Could not read the file",
    "restore_q" to "The backup will be merged with your data; nothing is deleted. Projects: %d, features: %d", "restored" to "Restored",
    "undone" to "Undone", "redone" to "Redone", "nothing" to "Nothing to undo", "bad_file" to "Invalid file"
)

fun tx(lang: String, key: String): String = (if (lang == "ar") TX_AR else TX_EN)[key] ?: TX_AR[key] ?: key

/** Sectors offered in the Gategory field (kept exactly as written by the user). */
val SECTORS = listOf(
    "قطاع المواصلات", "القطاع السياحي", "القطاع السياسي", "القطاع الاداري", "القطاع المدني",
    "القطاع المالي", "القطاع التجارية", "القطاع التربوي التعليمي", "القطاع الترفيهي", "القطاع الرياضي",
    "القطاع الخدماتي", "القطاع الديني", "القطاع الزراعي", "القطاع الصحي", "القطاع الصناعي", "القطاع الثقافي"
)
