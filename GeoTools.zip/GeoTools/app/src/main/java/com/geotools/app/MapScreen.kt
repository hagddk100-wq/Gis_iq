package com.geotools.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.MapTileProviderBasic
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import org.osmdroid.views.overlay.gestures.RotationGestureOverlay
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private fun widthM(r: Rect) = (r.e - r.w) * 111320.0 * cos(Math.toRadians((r.s + r.n) / 2))
private fun heightM(r: Rect) = (r.n - r.s) * 111320.0
private fun centerOf(r: Rect) = Ll((r.s + r.n) / 2, (r.w + r.e) / 2)

private fun findActivity(c: Context): Activity? {
    var x: Context? = c
    while (x is ContextWrapper) {
        if (x is Activity) return x
        x = x.baseContext
    }
    return null
}

private fun catColor(c: Cat): Int {
    val v: Long = when (c) {
        Cat.ROADS_MAIN -> 0xFFE53935
        Cat.ROADS_SEC -> 0xFFFB8C00
        Cat.RAIL -> 0xFF37474F
        Cat.LAKES -> 0xFF1E88E5
        Cat.RIVERS -> 0xFF00ACC1
        Cat.DAMS -> 0xFF6D4C41
        Cat.TOURIST -> 0xFF8E24AA
        Cat.PLACES -> 0xFF00897B
        Cat.ADMIN -> 0xFF43A047
        Cat.AREAS -> 0xFFAD1457
        Cat.USER -> 0xFFD81B60
    }
    return v.toInt()
}

private const val ESRI_BASE = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"

private val ESRI: ITileSource = object : OnlineTileSourceBase(
    "EsriWorldImagery", 0, 19, 256, ".jpg", arrayOf(ESRI_BASE)
) {
    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "$ESRI_BASE$z/$y/$x"
    }
}

private const val REF_BASE =
    "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/"

/** Place-name labels drawn on top of the satellite imagery. */
private val REF_LABELS: ITileSource = object : OnlineTileSourceBase(
    "EsriLabels", 0, 19, 256, ".png", arrayOf(REF_BASE)
) {
    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "$REF_BASE$z/$y/$x"
    }
}

private fun tileFor(type: Int): ITileSource = when (type) {
    1 -> TileSourceFactory.OpenTopo
    2 -> ESRI
    else -> TileSourceFactory.MAPNIK
}

private fun adminLevels(opts: Set<Int>): Set<Int> {
    val l = opts.flatMap {
        when (it) { 0 -> listOf(4); 1 -> listOf(5); 2 -> listOf(6, 7); else -> listOf(8, 9, 10) }
    }.toSet()
    return if (l.isEmpty()) setOf(4) else l
}

private class MapState(ctx: Context, cfg: Cfg) {
    var rect by mutableStateOf<Rect?>(null)
    var corner by mutableStateOf<Ll?>(null)
    var syncFields by mutableStateOf(false)
    var cats by mutableStateOf(setOf(Cat.ROADS_MAIN))
    var adminOpts by mutableStateOf(setOf(0))
    var groups by mutableStateOf(DEFAULT_GROUPS)
    var features by mutableStateOf<List<Feature>>(emptyList())
    var excluded by mutableStateOf<Set<Int>>(emptySet())
    var admin by mutableStateOf(Admin())
    var previewing by mutableStateOf(false)
    var includeMine by mutableStateOf(false)
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var shared by mutableStateOf<List<Uri>>(emptyList())
    var query by mutableStateOf("")
    var results by mutableStateOf<List<Place>>(emptyList())
    var skipSearch = false
    var panelOpen by mutableStateOf(true)
    var tab by mutableIntStateOf(0)
    var drawKind by mutableIntStateOf(1)
    var drawPts by mutableStateOf<List<Ll>>(emptyList())
    var drawName by mutableStateOf("")
    var mine by mutableStateOf(UserStore.load(ctx))
    var picked by mutableStateOf<Feature?>(null)
    var gp by mutableStateOf<List<GPlace>>(emptyList())
    var gpTick by mutableIntStateOf(0)
    var gpLast by mutableStateOf<Ll?>(null)
    var gpR = 0.0
    var center by mutableStateOf<Ll?>(null)
    var bearing by mutableFloatStateOf(0f)
    var exitAsk by mutableStateOf(false)
    var rotTxt by mutableStateOf("0")
    var myLoc by mutableStateOf<Ll?>(null)
    var pin by mutableStateOf<Ll?>(null)
    var wTxt by mutableStateOf(cfg.w.roundToInt().toString())
    var hTxt by mutableStateOf(cfg.h.roundToInt().toString())
}

private class Act(
    val preview: () -> Unit,
    val export: (List<Feature>) -> Unit,
    val zoomFeature: (Feature) -> Unit,
    val saveDraw: () -> Unit,
    val deleteMine: (Feature) -> Unit,
    val share: () -> Unit
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MapScreen(
    cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit, onMenu: () -> Unit,
    target: Ll?, onTargetUsed: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val t = { k: String -> tr(cfg.lang, k) }
    val textDir = if (cfg.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    val s = remember { MapState(ctx, cfg) }
    val modeS by rememberUpdatedState(cfg.selMode)
    val cfgS by rememberUpdatedState(cfg)

    val mapView = remember {
        val cam = ctx.getSharedPreferences("cam", 0)
        MapView(ctx).apply {
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(cam.getFloat("z", 4f).toDouble())
            controller.setCenter(GeoPoint(cam.getFloat("lat", 30f).toDouble(), cam.getFloat("lon", 40f).toDouble()))
            overlays.add(RotationGestureOverlay(this).apply { isEnabled = true })
            overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    val q = Ll(p.latitude, p.longitude)
                    s.picked = null
                    if (s.tab != 1) s.panelOpen = false
                    when {
                        s.tab == 1 -> s.drawPts = if (s.drawKind == 0) listOf(q) else s.drawPts + q
                        s.tab == 2 || s.previewing -> {}
                        modeS == 0 -> {
                            s.rect = boxAround(q, cfgS.w, cfgS.h); s.corner = null; s.syncFields = true
                        }
                        else -> {
                            val c = s.corner
                            if (c == null) {
                                s.corner = q; s.rect = null
                            } else {
                                s.rect = Rect(min(c.lat, q.lat), min(c.lon, q.lon), max(c.lat, q.lat), max(c.lon, q.lon))
                                s.corner = null; s.syncFields = true
                            }
                        }
                    }
                    return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
            overlays.add(RectOverlay({ s.rect }, { !s.previewing && s.tab == 0 }) { r -> s.rect = r; s.syncFields = true })
            addMapListener(object : MapListener {
                override fun onScroll(event: ScrollEvent?): Boolean {
                    s.gpTick++
                    event?.source?.mapCenter?.let { s.center = Ll(it.latitude, it.longitude) }
                    return false
                }
                override fun onZoom(event: ZoomEvent?): Boolean {
                    s.gpTick++
                    event?.source?.mapCenter?.let { s.center = Ll(it.latitude, it.longitude) }
                    return false
                }
            })
        }
    }

    val previewOv = remember { mutableListOf<Overlay>() }
    val mineOv = remember { mutableListOf<Overlay>() }
    val drawOv = remember { mutableListOf<Overlay>() }
    val pinOv = remember { mutableListOf<Overlay>() }
    val gpOv = remember { mutableListOf<Overlay>() }
    val labelOv = remember {
        TilesOverlay(MapTileProviderBasic(ctx, REF_LABELS), ctx).apply {
            loadingBackgroundColor = android.graphics.Color.TRANSPARENT
            loadingLineColor = android.graphics.Color.TRANSPARENT
        }
    }
    fun swap(list: MutableList<Overlay>, new: List<Overlay>) {
        mapView.overlays.removeAll(list)
        list.clear()
        list.addAll(new)
        mapView.overlays.addAll(new)
        mapView.invalidate()
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        fun saveCam() {
            val c = mapView.mapCenter
            ctx.getSharedPreferences("cam", 0).edit()
                .putFloat("lat", c.latitude.toFloat()).putFloat("lon", c.longitude.toFloat())
                .putFloat("z", mapView.zoomLevelDouble.toFloat()).apply()
        }
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> { saveCam(); mapView.onPause() }
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { saveCam(); lifecycle.removeObserver(obs); mapView.onDetach() }
    }

    LaunchedEffect(cfg.mapType) {
        mapView.setTileSource(tileFor(cfg.mapType))
        mapView.overlays.remove(labelOv)
        if (cfg.mapType == 2) mapView.overlays.add(0, labelOv)
        mapView.invalidate()
    }

    LaunchedEffect(s.rect) {
        val r = s.rect
        if (s.syncFields && r != null) {
            s.wTxt = widthM(r).roundToInt().toString()
            s.hTxt = heightM(r).roundToInt().toString()
            s.rotTxt = r.rot.roundToInt().toString()
            s.syncFields = false
        }
        mapView.invalidate()
    }

    // Preview features: lines/polygons as shapes, everything else as dots.
    LaunchedEffect(s.features, s.excluded, s.previewing) {
        val list = mutableListOf<Overlay>()
        if (s.previewing) {
            val pp = ArrayList<PPoint>()
            val idx = ArrayList<Int>()
            var drawn = 0
            s.features.forEachIndexed { i, f ->
                if (i in s.excluded) return@forEachIndexed
                val col = catColor(f.cat)
                when (f.kind) {
                    Kind.POINT -> {
                        val p = f.parts[0][0]
                        pp.add(PPoint(p.lat, p.lon, col, f.name)); idx.add(i)
                    }
                    Kind.LINE -> f.parts.forEach { part ->
                        if (drawn < 3000) {
                            val pl = Polyline(mapView)
                            pl.setPoints(part.map { GeoPoint(it.lat, it.lon) })
                            pl.outlinePaint.color = col
                            pl.outlinePaint.strokeWidth = 5f
                            list.add(pl); drawn++
                        }
                    }
                    Kind.POLYGON -> f.parts.forEach { part ->
                        if (drawn < 3000) {
                            val pg = Polygon(mapView)
                            pg.points = part.map { GeoPoint(it.lat, it.lon) }
                            pg.fillPaint.color = (col and 0x00FFFFFF) or (if (f.cat == Cat.ADMIN) 0x1A000000 else 0x55000000)
                            pg.outlinePaint.color = col
                            pg.outlinePaint.strokeWidth = if (f.cat == Cat.ADMIN) 6f else 4f
                            list.add(pg); drawn++
                        }
                    }
                }
            }
            if (pp.isNotEmpty()) list.add(PointsOverlay(pp) { k -> s.picked = s.features[idx[k]] })
        }
        swap(previewOv, list)
    }

    // My saved features (always visible).
    LaunchedEffect(s.mine) {
        val list = mutableListOf<Overlay>()
        val col = catColor(Cat.USER)
        val pp = ArrayList<PPoint>()
        val pf = ArrayList<Feature>()
        s.mine.forEach { f ->
            when (f.kind) {
                Kind.POINT -> {
                    val p = f.parts[0][0]
                    pp.add(PPoint(p.lat, p.lon, col, f.name)); pf.add(f)
                }
                Kind.LINE -> {
                    val pl = Polyline(mapView)
                    pl.setPoints(f.parts[0].map { GeoPoint(it.lat, it.lon) })
                    pl.outlinePaint.color = col
                    pl.outlinePaint.strokeWidth = 7f
                    pl.title = f.name
                    pl.snippet = Measure.text(f, cfgS.lang)
                    list.add(pl)
                }
                Kind.POLYGON -> {
                    val pg = Polygon(mapView)
                    pg.points = f.parts[0].map { GeoPoint(it.lat, it.lon) }
                    pg.fillPaint.color = (col and 0x00FFFFFF) or 0x44000000
                    pg.outlinePaint.color = col
                    pg.outlinePaint.strokeWidth = 5f
                    pg.title = f.name
                    pg.snippet = Measure.text(f, cfgS.lang)
                    list.add(pg)
                }
            }
        }
        if (pp.isNotEmpty()) list.add(PointsOverlay(pp) { k -> s.picked = pf[k] })
        swap(mineOv, list)
    }

    // Shape currently being drawn.
    LaunchedEffect(s.drawPts, s.drawKind) {
        val list = mutableListOf<Overlay>()
        val pts = s.drawPts
        val red = 0xFFFF1744.toInt()
        if (pts.size >= 2 && s.drawKind == 1) {
            val pl = Polyline(mapView)
            pl.setPoints(pts.map { GeoPoint(it.lat, it.lon) })
            pl.outlinePaint.color = red
            pl.outlinePaint.strokeWidth = 6f
            list.add(pl)
        } else if (pts.size >= 3 && s.drawKind == 2) {
            val pg = Polygon(mapView)
            pg.points = pts.map { GeoPoint(it.lat, it.lon) }
            pg.fillPaint.color = 0x33FF1744
            pg.outlinePaint.color = red
            pg.outlinePaint.strokeWidth = 5f
            list.add(pg)
        } else if (pts.size == 2 && s.drawKind == 2) {
            val pl = Polyline(mapView)
            pl.setPoints(pts.map { GeoPoint(it.lat, it.lon) })
            pl.outlinePaint.color = red
            pl.outlinePaint.strokeWidth = 6f
            list.add(pl)
        }
        if (pts.isNotEmpty()) list.add(PointsOverlay(pts.map { PPoint(it.lat, it.lon, red, "") }) { })
        swap(drawOv, list)
    }

    // Converter "go to" pin and my-location dot.
    LaunchedEffect(s.pin, s.myLoc) {
        val list = mutableListOf<Overlay>()
        s.pin?.let { q ->
            val m = Marker(mapView)
            m.position = GeoPoint(q.lat, q.lon)
            m.title = GeoConverter.fmtByType(q, cfgS.fmt)
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            list.add(m)
        }
        s.myLoc?.let { q ->
            list.add(PointsOverlay(listOf(PPoint(q.lat, q.lon, 0xFF2962FF.toInt(), tr(cfgS.lang, "my_location")))) { })
        }
        swap(pinOv, list)
    }

    // Google Places layer: shown only when enabled in settings (with a key); refreshed after the map moves.
    LaunchedEffect(s.gp) {
        val list = mutableListOf<Overlay>()
        val pf = s.gp.map {
            Feature(Cat.PLACES, Kind.POINT, it.name, it.type, listOf(listOf(Ll(it.lat, it.lon))), it.addr)
        }
        if (pf.isNotEmpty()) {
            val col = 0xFFEA4335.toInt()
            list.add(PointsOverlay(pf.map { f -> PPoint(f.parts[0][0].lat, f.parts[0][0].lon, col, f.name) }) { k ->
                s.picked = pf[k]
            })
        }
        swap(gpOv, list)
    }

    LaunchedEffect(cfg.gp, cfg.gpKey, cfg.gpProv, cfg.gpUrl, cfg.gpHdr) {
        s.gpLast = null
        s.gpTick++
    }

    LaunchedEffect(cfg.gp, cfg.gpKey, cfg.gpProv, cfg.gpUrl, cfg.gpHdr, s.gpTick) {
        val ready = cfg.gp && (cfg.gpKey.isNotBlank() || (cfg.gpProv == GP_CUSTOM && cfg.gpUrl.isNotBlank()))
        if (!ready) {
            s.gp = emptyList(); s.gpLast = null
            return@LaunchedEffect
        }
        delay(900)
        if (mapView.zoomLevelDouble < 12.0) {
            s.gp = emptyList(); s.gpLast = null
            return@LaunchedEffect
        }
        val c = mapView.mapCenter
        val radius = (mapView.boundingBox.diagonalLengthInMeters / 2).coerceIn(200.0, 50000.0)
        val last = s.gpLast
        if (last != null &&
            GeoPoint(last.lat, last.lon).distanceToAsDouble(c) < radius * 0.4 &&
            kotlin.math.abs(radius - s.gpR) < s.gpR * 0.4
        ) return@LaunchedEffect
        try {
            val r = withContext(Dispatchers.IO) {
                PlacesApi.nearby(cfg.gpProv, Ll(c.latitude, c.longitude), radius, cfg.gpKey.trim(), cfg.lang, cfg.gpUrl, cfg.gpHdr)
            }
            s.gp = r
            s.gpLast = Ll(c.latitude, c.longitude)
            s.gpR = radius
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Toast.makeText(ctx, e.message ?: "Places API", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        delay(400)
        mapView.mapCenter.let { s.center = Ll(it.latitude, it.longitude) }
        while (true) {
            val o = mapView.mapOrientation
            if (o != s.bearing) s.bearing = o
            delay(100)
        }
    }

    LaunchedEffect(target) {
        target?.let { q ->
            s.pin = q
            mapView.controller.setZoom(15.0)
            mapView.controller.setCenter(GeoPoint(q.lat, q.lon))
            onTargetUsed()
        }
    }

    // Place-name search (debounced).
    LaunchedEffect(s.query) {
        if (s.skipSearch) { s.skipSearch = false; return@LaunchedEffect }
        if (s.query.trim().length < 3) { s.results = emptyList(); return@LaunchedEffect }
        delay(700)
        s.results = withContext(Dispatchers.IO) { Geocoder.search(s.query.trim(), cfg.lang) }
    }

    fun zoomToRect(r: Rect) {
        mapView.post { mapView.zoomToBoundingBox(BoundingBox(r.n, r.e, r.s, r.w), true, 80) }
    }

    fun goTo(p: Place) {
        s.skipSearch = true
        s.query = p.name.substringBefore(",")
        s.results = emptyList()
        focus.clearFocus()
        val b = p.box
        val c = Ll(p.lat, p.lon)
        val r = if (b != null && widthM(b) > 300 && widthM(b) <= 100000 && heightM(b) <= 100000) b
        else boxAround(c, cfg.w, cfg.h)
        s.previewing = false; s.features = emptyList(); s.corner = null
        s.rect = r; s.syncFields = true
        zoomToRect(r)
    }

    fun zoomToFeature(f: Feature) {
        val pts = f.parts.flatten()
        if (pts.isEmpty()) return
        if (pts.size == 1) {
            mapView.controller.setCenter(GeoPoint(pts[0].lat, pts[0].lon))
            mapView.controller.setZoom(17.0)
        } else {
            val bb = BoundingBox.fromGeoPoints(pts.map { GeoPoint(it.lat, it.lon) })
            mapView.zoomToBoundingBox(bb.increaseByScale(1.4f), true)
        }
    }

    fun runPreview() {
        val r = s.rect ?: return
        if (widthM(r) > 100000 || heightM(r) > 100000) { s.status = t("too_big"); return }
        s.busy = true
        s.status = t("fetching")
        val chosen = s.cats
        val levels = adminLevels(s.adminOpts)
        val groups = s.groups
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) { Overpass.fetch(r, chosen, levels, groups) }
                if (f.isEmpty()) {
                    s.status = t("none_found")
                } else {
                    s.admin = withContext(Dispatchers.IO) { Nominatim.reverse(centerOf(r)) }
                    s.features = f; s.excluded = emptySet(); s.shared = emptyList()
                    s.previewing = true; s.status = ""
                }
            } catch (e: Exception) {
                s.status = e.message ?: e.toString()
            } finally {
                s.busy = false
            }
        }
    }

    fun runExport(feats: List<Feature>) {
        if (feats.isEmpty() || cfg.exp == 0) { s.status = t("none_selected"); return }
        s.busy = true
        s.status = t("fetching")
        val mask = cfg.exp
        val lang = cfg.lang
        val tree = cfg.tree
        val adm = if (s.previewing) s.admin else Admin()
        val center = s.rect?.let { centerOf(it) } ?: featureCenter(feats[0])
        scope.launch {
            try {
                val res = withContext(Dispatchers.IO) {
                    val files = Exporter.build(feats, adm, GeoConverter.zoneOf(center.lon), mask, lang)
                    Exporter.save(ctx, tree, files)
                }
                s.shared = res.uris
                s.status = t("saved") + ": " + res.where
            } catch (e: Exception) {
                s.status = e.message ?: e.toString()
            } finally {
                s.busy = false
            }
        }
    }

    fun saveDraw() {
        val pts = s.drawPts
        val kind = when (s.drawKind) { 0 -> Kind.POINT; 1 -> Kind.LINE; else -> Kind.POLYGON }
        val ok = when (kind) { Kind.POINT -> pts.isNotEmpty(); Kind.LINE -> pts.size >= 2; Kind.POLYGON -> pts.size >= 3 }
        if (!ok) return
        val ring = when (kind) {
            Kind.POINT -> pts.take(1)
            Kind.LINE -> pts
            Kind.POLYGON -> pts + pts[0]
        }
        s.mine = s.mine + Feature(Cat.USER, kind, s.drawName.ifBlank { t("unnamed") }, "user", listOf(ring))
        UserStore.save(ctx, s.mine)
        s.drawPts = emptyList()
        s.drawName = ""
    }

    fun locate() {
        Locator.once(ctx, { loc ->
            val q = Ll(loc.latitude, loc.longitude)
            s.myLoc = q
            mapView.controller.setZoom(16.0)
            mapView.controller.setCenter(GeoPoint(q.lat, q.lon))
        }, { Toast.makeText(ctx, t("gps_off"), Toast.LENGTH_SHORT).show() })
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) locate() else Toast.makeText(ctx, t("gps_denied"), Toast.LENGTH_SHORT).show()
    }

    val act = Act(
        preview = { runPreview() },
        export = { runExport(it) },
        zoomFeature = { zoomToFeature(it) },
        saveDraw = { saveDraw() },
        deleteMine = { f -> s.mine = s.mine - f; UserStore.save(ctx, s.mine) },
        share = {
            val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(s.shared))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(i, null))
        }
    )

    // Back goes one step back instead of leaving the app.
    val canBack = s.results.isNotEmpty() || s.picked != null || s.tab != 0 ||
            s.previewing || s.rect != null || s.corner != null
    BackHandler(enabled = canBack) {
        when {
            s.results.isNotEmpty() -> s.results = emptyList()
            s.picked != null -> s.picked = null
            s.tab == 1 && s.drawPts.isNotEmpty() -> s.drawPts = s.drawPts.dropLast(1)
            s.tab != 0 -> { s.tab = 0; s.drawPts = emptyList() }
            s.previewing -> { s.previewing = false; s.features = emptyList(); s.shared = emptyList(); s.status = "" }
            else -> { s.rect = null; s.corner = null }
        }
    }

    BackHandler(enabled = !canBack) { s.exitAsk = true }
    if (s.exitAsk) {
        CompositionLocalProvider(LocalLayoutDirection provides textDir) {
            AlertDialog(
                onDismissRequest = { s.exitAsk = false },
                title = { Text(t("exit_q")) },
                confirmButton = { TextButton(onClick = { findActivity(ctx)?.finish() }) { Text(t("exit")) } },
                dismissButton = { TextButton(onClick = { s.exitAsk = false }) { Text(t("cancel")) } }
            )
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize()) {
            AndroidView(factory = { mapView }, modifier = Modifier.fillMaxSize())
            Canvas(Modifier.align(Alignment.Center).size(34.dp)) {
                val col = Color(0xFFD50000)
                val c = center
                drawLine(col, Offset(0f, c.y), Offset(size.width, c.y), strokeWidth = 3f)
                drawLine(col, Offset(c.x, 0f), Offset(c.x, size.height), strokeWidth = 3f)
                drawCircle(col, 7.dp.toPx(), c, style = Stroke(3f))
            }

            // ---- top: floating search, results, picked card, map buttons ----
            Column(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(28.dp), shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { click(); onMenu() }) { Icon(Icons.Default.Menu, contentDescription = null) }
                        TextField(
                            value = s.query, onValueChange = { s.query = it }, singleLine = true,
                            placeholder = { Text(t("search_hint")) },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        if (s.query.isNotEmpty()) {
                            IconButton(onClick = { s.query = ""; s.results = emptyList() }) {
                                Icon(Icons.Default.Close, contentDescription = null)
                            }
                        } else {
                            Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
                if (s.results.isEmpty()) s.center?.let { cc ->
                    val txt = GeoConverter.fmtByType(cc, cfg.fmt)
                    Surface(
                        shape = RoundedCornerShape(16.dp), shadowElevation = 6.dp,
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text(
                            txt, style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.clickable {
                                click()
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("coords", txt))
                                Toast.makeText(ctx, txt, Toast.LENGTH_SHORT).show()
                            }.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
                if (s.results.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp), shadowElevation = 8.dp,
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Column {
                            s.results.forEach { p ->
                                Text(
                                    p.name, maxLines = 2, style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.fillMaxWidth().clickable { click(); goTo(p) }.padding(14.dp)
                                )
                            }
                        }
                    }
                }
                s.picked?.let { f ->
                    Surface(
                        shape = RoundedCornerShape(16.dp), shadowElevation = 8.dp,
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(f.name.ifEmpty { f.type.ifEmpty { "—" } }, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    catLabel(f, cfg.lang) + (if (f.type.isNotEmpty() && f.cat != Cat.USER) " · " + f.type else "") +
                                            (if (f.owner.isNotEmpty()) " · " + f.owner else ""),
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(GeoConverter.fmtByType(featureCenter(f), cfg.fmt), style = MaterialTheme.typography.bodySmall)
                                val m = Measure.text(f, cfg.lang)
                                if (m.isNotEmpty()) Text(m, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { s.picked = null }) { Icon(Icons.Default.Close, contentDescription = null) }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { click(); setCfg(cfg.copy(mapType = (cfg.mapType + 1) % 3)) },
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) { Text(t(listOf("mt_std", "mt_topo", "mt_sat")[cfg.mapType.coerceIn(0, 2)])) }
                        FilledTonalButton(
                            onClick = { click(); mapView.setMapOrientation(0f); s.bearing = 0f },
                            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(44.dp)
                        ) {
                            Canvas(Modifier.size(26.dp)) {
                                rotate(s.bearing) {
                                    val w = size.width
                                    val h = size.height
                                    val north = Path().apply {
                                        moveTo(w / 2, 0f); lineTo(w * 0.8f, h / 2); lineTo(w * 0.2f, h / 2); close()
                                    }
                                    val south = Path().apply {
                                        moveTo(w / 2, h); lineTo(w * 0.8f, h / 2); lineTo(w * 0.2f, h / 2); close()
                                    }
                                    drawPath(north, Color(0xFFD32F2F))
                                    drawPath(south, Color(0xFF757575))
                                }
                            }
                        }
                        FilledTonalButton(
                            onClick = { click(); mapView.controller.zoomIn() },
                            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(44.dp)
                        ) { Text("+", style = MaterialTheme.typography.titleLarge) }
                        FilledTonalButton(
                            onClick = { click(); mapView.controller.zoomOut() },
                            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(44.dp)
                        ) { Text("\u2212", style = MaterialTheme.typography.titleLarge) }
                        GpsButton {
                            click()
                            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) ==
                                    PackageManager.PERMISSION_GRANTED
                            if (granted) locate() else permLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                        }
                    }
                }
            }

            // ---- bottom panel ----
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().animateContentSize(),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                shadowElevation = 16.dp, color = MaterialTheme.colorScheme.surface
            ) {
                Column(Modifier.navigationBarsPadding().imePadding()) {
                    Box(
                        Modifier.fillMaxWidth().height(36.dp)
                            .clickable { s.panelOpen = !s.panelOpen }
                            .pointerInput(Unit) {
                                var total = 0f
                                detectVerticalDragGestures(
                                    onDragStart = { total = 0f },
                                    onDragEnd = {
                                        if (total > 24f) s.panelOpen = false else if (total < -24f) s.panelOpen = true
                                    },
                                    onDragCancel = { total = 0f },
                                    onVerticalDrag = { change, amount -> total += amount; change.consume() }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier.width(44.dp).height(5.dp).clip(RoundedCornerShape(3.dp))
                                .background(MaterialTheme.colorScheme.outlineVariant)
                        )
                    }
                    AnimatedVisibility(s.panelOpen) {
                        CompositionLocalProvider(LocalLayoutDirection provides textDir) {
                            Column(
                                Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())
                                    .padding(horizontal = 16.dp).padding(bottom = 16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Choice(listOf(t("tab_area"), t("tab_draw"), t("tab_mine")), s.tab, click) {
                                    s.tab = it
                                    if (it != 1) s.drawPts = emptyList()
                                }
                                when (s.tab) {
                                    0 -> AreaTab(s, cfg, setCfg, click, t, act)
                                    1 -> DrawTab(s, cfg, click, t, act)
                                    else -> MineTab(s, cfg, setCfg, click, t, act)
                                }
                                CoordChoice(cfg, setCfg, click, t)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GpsButton(onClick: () -> Unit) {
    SmallFloatingActionButton(onClick = onClick) {
        val c = LocalContentColor.current
        Canvas(Modifier.size(22.dp)) {
            val m = size.minDimension / 2f
            val r = size.minDimension / 3.2f
            drawCircle(c, r, style = Stroke(width = 3f))
            drawCircle(c, r / 3f)
            drawLine(c, Offset(m, 0f), Offset(m, m - r), 3f)
            drawLine(c, Offset(m, m + r), Offset(m, size.height), 3f)
            drawLine(c, Offset(0f, m), Offset(m - r, m), 3f)
            drawLine(c, Offset(m + r, m), Offset(size.width, m), 3f)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CoordChoice(cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit, t: (String) -> String) {
    Text(t("coord_type"), style = MaterialTheme.typography.labelLarge)
    Choice(listOf("DD", "DMS", "UTM", "MGRS"), cfg.fmt, click) { setCfg(cfg.copy(fmt = it)) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FormatChips(cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit, t: (String) -> String) {
    Text(t("formats"), style = MaterialTheme.typography.labelLarge)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Fmt.SHP to "f_shp", Fmt.XLSX to "f_xlsx", Fmt.KML to "f_kml", Fmt.KMZ to "f_kmz").forEach { (bit, k) ->
            FilterChip(
                selected = cfg.exp and bit != 0,
                onClick = { click(); setCfg(cfg.copy(exp = cfg.exp xor bit)) },
                label = { Text(t(k)) })
        }
    }
}

@Composable
private fun StatusBlock(s: MapState, act: Act, click: () -> Unit, t: (String) -> String) {
    if (s.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    if (s.status.isNotEmpty()) Text(s.status, style = MaterialTheme.typography.bodySmall)
    if (s.shared.isNotEmpty()) {
        OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { click(); act.share() }) { Text(t("share")) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AreaTab(s: MapState, cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit, t: (String) -> String, act: Act) {
    if (!s.previewing) {
        val r = s.rect
        if (r == null) {
            Text(
                t(if (cfg.selMode == 0) "tap_center" else if (s.corner == null) "tap_corners" else "pick_second"),
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            val z = GeoConverter.zoneOf(centerOf(r).lon)
            Text("SW  " + GeoConverter.fmtByType(Ll(r.s, r.w), cfg.fmt, z), style = MaterialTheme.typography.bodySmall)
            Text("NE  " + GeoConverter.fmtByType(Ll(r.n, r.e), cfg.fmt, z), style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = s.wTxt, singleLine = true, label = { Text(t("width")) },
                    onValueChange = {
                        s.wTxt = it
                        val v = GeoConverter.normalize(it).toDoubleOrNull()
                        if (v != null && v > 0) {
                            setCfg(cfg.copy(w = v))
                            s.rect = boxAround(centerOf(r), v, heightM(r)).copy(rot = r.rot)
                        }
                    }, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = s.hTxt, singleLine = true, label = { Text(t("height")) },
                    onValueChange = {
                        s.hTxt = it
                        val v = GeoConverter.normalize(it).toDoubleOrNull()
                        if (v != null && v > 0) {
                            setCfg(cfg.copy(h = v))
                            s.rect = boxAround(centerOf(r), widthM(r), v).copy(rot = r.rot)
                        }
                    }, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = s.rotTxt, singleLine = true, label = { Text(t("rot")) },
                    onValueChange = {
                        s.rotTxt = it
                        val v = GeoConverter.normalize(it).toDoubleOrNull()
                        if (v != null) s.rect = r.copy(rot = ((v % 360) + 360) % 360)
                    }, modifier = Modifier.weight(1f)
                )
            }
            Text(
                t("drag_hint") + "\n" + t("rot_hint"), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(t("categories"), style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Cat.values().filter { it != Cat.USER }.forEach { c ->
                FilterChip(
                    selected = c in s.cats,
                    onClick = { click(); s.cats = if (c in s.cats) s.cats - c else s.cats + c },
                    label = { Text(t(c.key)) })
            }
        }
        if (Cat.ADMIN in s.cats) {
            Text(t("admin_levels"), style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("al_gov", "al_qada", "al_nahiya", "al_hayy").forEachIndexed { i, k ->
                    FilterChip(
                        selected = i in s.adminOpts,
                        onClick = { click(); s.adminOpts = if (i in s.adminOpts) s.adminOpts - i else s.adminOpts + i },
                        label = { Text(t(k)) })
                }
            }
        }
        if (Cat.PLACES in s.cats) {
            Text(t("place_types"), style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PLACE_GROUPS.forEach { g ->
                    FilterChip(
                        selected = g.key in s.groups,
                        onClick = { click(); s.groups = if (g.key in s.groups) s.groups - g.key else s.groups + g.key },
                        label = { Text(t(g.key)) })
                }
            }
        }
        Button(
            onClick = { click(); act.preview() },
            enabled = s.rect != null && s.cats.isNotEmpty() && !s.busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(t("preview")) }
        StatusBlock(s, act, click, t)
    } else {
        Text(
            t("features") + ": " + (s.features.size - s.excluded.size) + " / " + s.features.size,
            style = MaterialTheme.typography.titleSmall
        )
        Text(
            s.features.groupBy { it.cat }.map { t(it.key.key) + " " + it.value.size }.joinToString("  •  "),
            style = MaterialTheme.typography.bodySmall
        )
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 200.dp)) {
            itemsIndexed(s.features.take(500)) { i, f ->
                Row(
                    Modifier.fillMaxWidth().clickable { act.zoomFeature(f) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = i !in s.excluded,
                        onCheckedChange = { on -> s.excluded = if (on) s.excluded - i else s.excluded + i }
                    )
                    Column(Modifier.weight(1f)) {
                        Text(f.name.ifEmpty { f.type.ifEmpty { "—" } }, maxLines = 1)
                        Text(
                            catLabel(f, cfg.lang) + (if (f.type.isNotEmpty()) " · " + f.type else "") +
                                    (if (f.owner.isNotEmpty()) " · " + f.owner else ""),
                            style = MaterialTheme.typography.labelSmall, maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        if (s.mine.isNotEmpty()) {
            Row(Modifier.clickable { s.includeMine = !s.includeMine }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = s.includeMine, onCheckedChange = { s.includeMine = it })
                Text(t("include_mine"))
            }
        }
        FormatChips(cfg, setCfg, click, t)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                click(); s.previewing = false; s.features = emptyList(); s.shared = emptyList(); s.status = ""
            }, modifier = Modifier.weight(1f)) { Text(t("back_edit")) }
            Button(
                onClick = {
                    click()
                    val chosen = s.features.filterIndexed { i, _ -> i !in s.excluded }
                    act.export(chosen + (if (s.includeMine) s.mine else emptyList()))
                },
                enabled = !s.busy && cfg.exp != 0 && s.features.size > s.excluded.size,
                modifier = Modifier.weight(1f)
            ) { Text(t("export")) }
        }
        StatusBlock(s, act, click, t)
    }
}

@Composable
private fun DrawTab(s: MapState, cfg: Cfg, click: () -> Unit, t: (String) -> String, act: Act) {
    Choice(listOf(t("pt"), t("line"), t("poly")), s.drawKind, click) { s.drawKind = it; s.drawPts = emptyList() }
    val pts = s.drawPts
    val live = when (s.drawKind) {
        1 -> if (pts.size >= 2) t("length") + ": " + Measure.fmtLen(Measure.length(pts)) else ""
        2 -> if (pts.size >= 3) t("area") + ": " + Measure.fmtArea(Measure.area(pts), cfg.lang) +
                "\n" + t("length") + ": " + Measure.fmtLen(Measure.length(pts + pts[0])) else ""
        else -> if (pts.isNotEmpty()) GeoConverter.fmtByType(pts[0], cfg.fmt) else ""
    }
    Text(if (pts.isEmpty()) t("draw_hint") else if (live.isEmpty()) pts.size.toString() else live,
        style = MaterialTheme.typography.bodyMedium)
    Field(t("name"), s.drawName) { s.drawName = it }
    val valid = when (s.drawKind) { 0 -> pts.isNotEmpty(); 1 -> pts.size >= 2; else -> pts.size >= 3 }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { click(); s.drawPts = s.drawPts.dropLast(1) }, enabled = pts.isNotEmpty()) { Text(t("undo")) }
        OutlinedButton(onClick = { click(); s.drawPts = emptyList() }, enabled = pts.isNotEmpty()) { Text(t("clear")) }
        Button(onClick = { click(); act.saveDraw() }, enabled = valid) { Text(t("save_feat")) }
    }
}

@Composable
private fun MineTab(s: MapState, cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit, t: (String) -> String, act: Act) {
    if (s.mine.isEmpty()) {
        Text(t("mine_empty"), style = MaterialTheme.typography.bodyMedium)
    } else {
        s.mine.forEach { f ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(f.name, maxLines = 1)
                    val m = if (f.kind == Kind.POINT) GeoConverter.fmtByType(featureCenter(f), cfg.fmt) else Measure.text(f, cfg.lang)
                    Text(m, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { click(); act.zoomFeature(f) }) { Text(t("zoom")) }
                TextButton(onClick = { click(); act.deleteMine(f) }) { Text(t("delete")) }
            }
        }
        FormatChips(cfg, setCfg, click, t)
        Button(
            onClick = { click(); act.export(s.mine) },
            enabled = !s.busy && cfg.exp != 0,
            modifier = Modifier.fillMaxWidth()
        ) { Text(t("export_mine")) }
        StatusBlock(s, act, click, t)
    }
}
