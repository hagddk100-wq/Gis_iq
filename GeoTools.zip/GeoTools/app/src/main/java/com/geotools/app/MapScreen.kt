package com.geotools.app

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private fun widthM(r: Rect) = (r.e - r.w) * 111320.0 * cos(Math.toRadians((r.s + r.n) / 2))
private fun heightM(r: Rect) = (r.n - r.s) * 111320.0
private fun centerOf(r: Rect) = Ll((r.s + r.n) / 2, (r.w + r.e) / 2)

private fun catColor(c: Cat): Int {
    val v: Long = when (c) {
        Cat.ROADS_MAIN -> 0xFFE53935
        Cat.ROADS_SEC -> 0xFFFB8C00
        Cat.LAKES -> 0xFF1E88E5
        Cat.RIVERS -> 0xFF00ACC1
        Cat.DAMS -> 0xFF6D4C41
        Cat.TOURIST -> 0xFF8E24AA
        Cat.ADMIN -> 0xFF43A047
    }
    return v.toInt()
}

private const val ESRI_BASE = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"

private val ESRI: ITileSource = object : OnlineTileSourceBase(
    "EsriWorldImagery", 0, 19, 256, ".jpg", arrayOf(ESRI_BASE)
) {
    override fun getTileURLString(pMapTileIndex: Long): String {
        val z = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "$ESRI_BASE$z/$y/$x"
    }
}

private fun tileFor(type: Int): ITileSource = when (type) {
    1 -> TileSourceFactory.OpenTopo
    2 -> ESRI
    else -> TileSourceFactory.MAPNIK
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MapScreen(cfg: Cfg, setCfg: (Cfg) -> Unit, click: () -> Unit, onMenu: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val t = { k: String -> tr(cfg.lang, k) }
    val textDir = if (cfg.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

    var rect by remember { mutableStateOf<Rect?>(null) }
    var corner by remember { mutableStateOf<Ll?>(null) }
    var syncFields by remember { mutableStateOf(false) }
    var cats by remember { mutableStateOf(setOf(Cat.ROADS_MAIN)) }
    var features by remember { mutableStateOf<List<Feature>>(emptyList()) }
    var excluded by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var admin by remember { mutableStateOf(Admin()) }
    var previewing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var shared by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Place>>(emptyList()) }
    var skipSearch by remember { mutableStateOf(false) }
    var panelOpen by remember { mutableStateOf(true) }
    var wTxt by remember { mutableStateOf(cfg.w.roundToInt().toString()) }
    var hTxt by remember { mutableStateOf(cfg.h.roundToInt().toString()) }

    val modeS by rememberUpdatedState(cfg.selMode)
    val cfgS by rememberUpdatedState(cfg)
    val rectS by rememberUpdatedState(rect)
    val prevS by rememberUpdatedState(previewing)

    val mapView = remember {
        val cam = ctx.getSharedPreferences("cam", 0)
        MapView(ctx).apply {
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(cam.getFloat("z", 4f).toDouble())
            controller.setCenter(GeoPoint(cam.getFloat("lat", 30f).toDouble(), cam.getFloat("lon", 40f).toDouble()))
            overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                    if (prevS) return true
                    val q = Ll(p.latitude, p.longitude)
                    if (modeS == 0) {
                        rect = boxAround(q, cfgS.w, cfgS.h); corner = null; syncFields = true
                    } else {
                        val c = corner
                        if (c == null) {
                            corner = q; rect = null
                        } else {
                            rect = Rect(min(c.lat, q.lat), min(c.lon, q.lon), max(c.lat, q.lat), max(c.lon, q.lon))
                            corner = null; syncFields = true
                        }
                    }
                    return true
                }
                override fun longPressHelper(p: GeoPoint): Boolean = false
            }))
            overlays.add(RectOverlay({ rectS }, { !prevS }) { r -> rect = r; syncFields = true })
        }
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        fun saveCam() {
            val c = mapView.mapCenter
            ctx.getSharedPreferences("cam", 0).edit()
                .putFloat("lat", c.latitude.toFloat()).putFloat("lon", c.longitude.toFloat())
                .putFloat("z", mapView.zoomLevelDouble.toFloat()).apply()
        }
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> { saveCam(); mapView.onPause() }
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose { saveCam(); lifecycle.removeObserver(obs); mapView.onDetach() }
    }

    LaunchedEffect(cfg.mapType) {
        mapView.setTileSource(tileFor(cfg.mapType))
        mapView.invalidate()
    }

    LaunchedEffect(rect) {
        val r = rect
        if (syncFields && r != null) {
            wTxt = widthM(r).roundToInt().toString()
            hTxt = heightM(r).roundToInt().toString()
            syncFields = false
        }
        mapView.invalidate()
    }

    // Draw the previewed features on the map.
    LaunchedEffect(features, excluded, previewing) {
        mapView.overlays.removeAll { it is Marker || it is Polyline || it is Polygon }
        if (previewing) {
            var drawn = 0
            features.forEachIndexed { i, f ->
                if (i in excluded) return@forEachIndexed
                if (drawn > 3000) return@forEachIndexed
                val col = catColor(f.cat)
                when (f.kind) {
                    Kind.POINT -> {
                        val p = f.parts[0][0]
                        val m = Marker(mapView)
                        m.position = GeoPoint(p.lat, p.lon)
                        m.title = f.name.ifEmpty { f.type }
                        m.snippet = f.type
                        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        mapView.overlays.add(m); drawn++
                    }
                    Kind.LINE -> f.parts.forEach { part ->
                        val pl = Polyline(mapView)
                        pl.setPoints(part.map { GeoPoint(it.lat, it.lon) })
                        pl.outlinePaint.color = col
                        pl.outlinePaint.strokeWidth = 5f
                        mapView.overlays.add(pl); drawn++
                    }
                    Kind.POLYGON -> f.parts.forEach { part ->
                        val pg = Polygon(mapView)
                        pg.points = part.map { GeoPoint(it.lat, it.lon) }
                        pg.fillPaint.color = (col and 0x00FFFFFF) or 0x55000000
                        pg.outlinePaint.color = col
                        pg.outlinePaint.strokeWidth = 4f
                        mapView.overlays.add(pg); drawn++
                    }
                }
            }
        }
        mapView.invalidate()
    }

    // Place-name search (debounced).
    LaunchedEffect(query) {
        if (skipSearch) { skipSearch = false; return@LaunchedEffect }
        if (query.trim().length < 3) { results = emptyList(); return@LaunchedEffect }
        delay(700)
        results = withContext(Dispatchers.IO) { Geocoder.search(query.trim(), cfg.lang) }
    }

    fun zoomToRect(r: Rect) {
        mapView.post { mapView.zoomToBoundingBox(BoundingBox(r.n, r.e, r.s, r.w), true, 80) }
    }

    fun goTo(p: Place) {
        skipSearch = true
        query = p.name.substringBefore(",")
        results = emptyList()
        focus.clearFocus()
        val b = p.box
        val c = Ll(p.lat, p.lon)
        val r = if (b != null && widthM(b) > 300 && widthM(b) <= 100000 && heightM(b) <= 100000) b
        else boxAround(c, cfg.w, cfg.h)
        previewing = false; features = emptyList(); corner = null
        rect = r; syncFields = true
        zoomToRect(r)
    }

    fun zoomToFeature(f: Feature) {
        val pts = f.parts.flatten()
        if (pts.isEmpty()) return
        if (pts.size == 1) {
            mapView.controller.setCenter(GeoPoint(pts[0].lat, pts[0].lon))
            mapView.controller.setZoom(17.0)
        } else {
            val bb = BoundingBox.fromGeoPoints(pts.map { GeoPoint(it.lat, it.lon) })
            mapView.zoomToBoundingBox(bb.increaseByScale(1.4f), true)
        }
    }

    fun runPreview() {
        val r = rect ?: return
        if (widthM(r) > 100000 || heightM(r) > 100000) { status = t("too_big"); return }
        busy = true
        status = t("fetching")
        val chosen = cats
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) { Overpass.fetch(r, chosen) }
                if (f.isEmpty()) {
                    status = t("none_found")
                } else {
                    admin = withContext(Dispatchers.IO) { Nominatim.reverse(centerOf(r)) }
                    features = f; excluded = emptySet(); shared = emptyList()
                    previewing = true; status = ""
                }
            } catch (e: Exception) {
                status = e.message ?: e.toString()
            } finally {
                busy = false
            }
        }
    }

    fun runExport() {
        val r = rect ?: return
        val feats = features.filterIndexed { i, _ -> i !in excluded }
        if (feats.isEmpty() || cfg.exp == 0) { status = t("none_selected"); return }
        busy = true
        status = t("fetching")
        val mask = cfg.exp
        val lang = cfg.lang
        val tree = cfg.tree
        val adm = admin
        scope.launch {
            try {
                val res = withContext(Dispatchers.IO) {
                    val files = Exporter.build(feats, adm, GeoConverter.zoneOf(centerOf(r).lon), mask, lang)
                    Exporter.save(ctx, tree, files)
                }
                shared = res.uris
                status = t("saved") + ": " + res.where
            } catch (e: Exception) {
                status = e.message ?: e.toString()
            } finally {
                busy = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize()) {
            AndroidView(factory = { mapView }, modifier = Modifier.fillMaxSize())

            // ---- top: floating search + results + map type ----
            Column(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(28.dp), shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { click(); onMenu() }) { Icon(Icons.Default.Menu, contentDescription = null) }
                        TextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            placeholder = { Text(t("search_hint")) },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = ""; results = emptyList() }) {
                                Icon(Icons.Default.Close, contentDescription = null)
                            }
                        } else {
                            Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
                if (results.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp), shadowElevation = 8.dp,
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Column {
                            results.forEach { p ->
                                Text(
                                    p.name, maxLines = 2, style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.fillMaxWidth().clickable { click(); goTo(p) }.padding(14.dp)
                                )
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    FilledTonalButton(
                        onClick = { click(); setCfg(cfg.copy(mapType = (cfg.mapType + 1) % 3)) },
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) { Text(t(listOf("mt_std", "mt_topo", "mt_sat")[cfg.mapType.coerceIn(0, 2)])) }
                }
            }

            // ---- bottom panel ----
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().animateContentSize(),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                shadowElevation = 16.dp, color = MaterialTheme.colorScheme.surface
            ) {
                Column(Modifier.navigationBarsPadding().imePadding()) {
                    Box(
                        Modifier.fillMaxWidth().height(28.dp).clickable { panelOpen = !panelOpen },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier.width(44.dp).height(5.dp).clip(RoundedCornerShape(3.dp))
                                .background(MaterialTheme.colorScheme.outlineVariant)
                        )
                    }
                    AnimatedVisibility(panelOpen) {
                        CompositionLocalProvider(LocalLayoutDirection provides textDir) {
                            Column(
                                Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState())
                                    .padding(horizontal = 16.dp).padding(bottom = 16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                if (!previewing) {
                                    val r = rect
                                    if (r == null) {
                                        Text(
                                            t(if (cfg.selMode == 0) "tap_center" else if (corner == null) "tap_corners" else "pick_second"),
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    } else {
                                        val z = GeoConverter.zoneOf(centerOf(r).lon)
                                        Text("SW  " + GeoConverter.fmtByType(Ll(r.s, r.w), cfg.fmt, z), style = MaterialTheme.typography.bodySmall)
                                        Text("NE  " + GeoConverter.fmtByType(Ll(r.n, r.e), cfg.fmt, z), style = MaterialTheme.typography.bodySmall)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedTextField(
                                                value = wTxt, singleLine = true, label = { Text(t("width")) },
                                                onValueChange = {
                                                    wTxt = it
                                                    val v = GeoConverter.normalize(it).toDoubleOrNull()
                                                    if (v != null && v > 0) {
                                                        setCfg(cfg.copy(w = v))
                                                        rect = boxAround(centerOf(r), v, heightM(r))
                                                    }
                                                }, modifier = Modifier.weight(1f)
                                            )
                                            OutlinedTextField(
                                                value = hTxt, singleLine = true, label = { Text(t("height")) },
                                                onValueChange = {
                                                    hTxt = it
                                                    val v = GeoConverter.normalize(it).toDoubleOrNull()
                                                    if (v != null && v > 0) {
                                                        setCfg(cfg.copy(h = v))
                                                        rect = boxAround(centerOf(r), widthM(r), v)
                                                    }
                                                }, modifier = Modifier.weight(1f)
                                            )
                                        }
                                        Text(
                                            t("drag_hint"), style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(t("categories"), style = MaterialTheme.typography.labelLarge)
                                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Cat.values().forEach { c ->
                                            FilterChip(
                                                selected = c in cats,
                                                onClick = { click(); cats = if (c in cats) cats - c else cats + c },
                                                label = { Text(t(c.key)) })
                                        }
                                    }
                                    Button(
                                        onClick = { click(); runPreview() },
                                        enabled = rect != null && cats.isNotEmpty() && !busy,
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text(t("preview")) }
                                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                                    if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodySmall)
                                } else {
                                    Text(
                                        t("features") + ": " + (features.size - excluded.size) + " / " + features.size,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        features.groupBy { it.cat }.map { t(it.key.key) + " " + it.value.size }
                                            .joinToString("  •  "),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 200.dp)) {
                                        itemsIndexed(features.take(500)) { i, f ->
                                            Row(
                                                Modifier.fillMaxWidth().clickable { zoomToFeature(f) },
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Checkbox(
                                                    checked = i !in excluded,
                                                    onCheckedChange = { on -> excluded = if (on) excluded - i else excluded + i }
                                                )
                                                Column(Modifier.weight(1f)) {
                                                    Text(f.name.ifEmpty { f.type.ifEmpty { "—" } }, maxLines = 1)
                                                    Text(
                                                        t(f.cat.key) + " · " + f.type,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    Text(t("formats"), style = MaterialTheme.typography.labelLarge)
                                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf(Fmt.SHP to "f_shp", Fmt.XLSX to "f_xlsx", Fmt.KML to "f_kml", Fmt.KMZ to "f_kmz")
                                            .forEach { (bit, k) ->
                                                FilterChip(
                                                    selected = cfg.exp and bit != 0,
                                                    onClick = { click(); setCfg(cfg.copy(exp = cfg.exp xor bit)) },
                                                    label = { Text(t(k)) })
                                            }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = {
                                            click(); previewing = false; features = emptyList()
                                            shared = emptyList(); status = ""
                                        }, modifier = Modifier.weight(1f)) { Text(t("back_edit")) }
                                        Button(
                                            onClick = { click(); runExport() },
                                            enabled = !busy && cfg.exp != 0 && features.size > excluded.size,
                                            modifier = Modifier.weight(1f)
                                        ) { Text(t("export")) }
                                    }
                                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                                    if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodySmall)
                                    if (shared.isNotEmpty()) {
                                        OutlinedButton(
                                            modifier = Modifier.fillMaxWidth(),
                                            onClick = {
                                                click()
                                                val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                                                    type = "*/*"
                                                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(shared))
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                ctx.startActivity(Intent.createChooser(i, null))
                                            }
                                        ) { Text(t("share")) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
