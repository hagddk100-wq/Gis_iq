package com.geotools.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Overpass {
    private val ENDPOINTS = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter"
    )
    private const val UA = "GeoTools-Android/1.0"
    private const val EXCL = "river|canal|stream|pond|basin|ditch"
    private val MAIN = setOf("motorway", "trunk", "primary")
    private val TOUR = setOf("attraction", "museum", "viewpoint", "zoo", "theme_park", "gallery")
    private val RAILS = setOf("rail", "light_rail", "subway", "tram", "narrow_gauge", "monorail", "funicular")
    private val HOODS = setOf("suburb", "neighbourhood", "quarter")

    private fun statements(c: Cat, levels: Set<Int>): List<String> = when (c) {
        Cat.ROADS_MAIN -> listOf("way[\"highway\"~\"^(motorway|trunk|primary)(_link)?\$\"]")
        Cat.ROADS_SEC -> listOf("way[\"highway\"~\"^(secondary|tertiary|unclassified|residential)(_link)?\$\"]")
        Cat.RAIL -> listOf("way[\"railway\"~\"^(" + RAILS.joinToString("|") + ")\$\"]")
        Cat.LAKES -> listOf(
            "way[\"natural\"=\"water\"][\"water\"!~\"$EXCL\"]",
            "relation[\"natural\"=\"water\"][\"water\"!~\"$EXCL\"]"
        )
        Cat.RIVERS -> listOf("way[\"waterway\"~\"^(river|stream|canal)\$\"]")
        Cat.DAMS -> listOf("nwr[\"waterway\"=\"dam\"]", "nwr[\"man_made\"=\"dam\"]")
        Cat.TOURIST -> listOf(
            "nwr[\"tourism\"~\"^(" + TOUR.joinToString("|") + ")\$\"]",
            "nwr[\"historic\"]"
        )
        Cat.ADMIN -> {
            val out = mutableListOf(
                "relation[\"boundary\"=\"administrative\"][\"admin_level\"~\"^(" +
                        levels.joinToString("|") + ")\$\"]"
            )
            if (levels.any { it >= 8 }) out.add("nwr[\"place\"~\"^(" + HOODS.joinToString("|") + ")\$\"]")
            out
        }
        Cat.PLACES, Cat.USER -> emptyList()
    }

    private fun base(t: Map<String, String>): Cat? = when {
        t["boundary"] == "administrative" -> Cat.ADMIN
        t["place"] in HOODS -> Cat.ADMIN
        t["waterway"] == "dam" || t["man_made"] == "dam" -> Cat.DAMS
        t["waterway"] in setOf("river", "stream", "canal") -> Cat.RIVERS
        t["natural"] == "water" -> Cat.LAKES
        t["railway"] in RAILS -> Cat.RAIL
        t["highway"] != null ->
            if (t["highway"]!!.removeSuffix("_link") in MAIN) Cat.ROADS_MAIN else Cat.ROADS_SEC
        t["tourism"] in TOUR || t["historic"] != null -> Cat.TOURIST
        else -> null
    }

    private fun classify(t: Map<String, String>, cats: Set<Cat>, groups: List<PlaceGroup>): Cat? {
        val b = base(t)
        if (b != null && b in cats) return b
        if (Cat.PLACES in cats && groups.any { it.match(t) }) return Cat.PLACES
        return null
    }

    private fun typeOf(c: Cat, t: Map<String, String>): String = when (c) {
        Cat.ROADS_MAIN, Cat.ROADS_SEC -> t["highway"] ?: ""
        Cat.RAIL -> t["railway"] ?: ""
        Cat.LAKES -> t["water"] ?: "water"
        Cat.RIVERS -> t["waterway"] ?: ""
        Cat.DAMS -> "dam"
        Cat.TOURIST -> t["tourism"] ?: t["historic"] ?: ""
        Cat.ADMIN -> if (t["boundary"] == "administrative") "admin_level=" + (t["admin_level"] ?: "")
        else "place=" + (t["place"] ?: "")
        Cat.PLACES, Cat.USER -> ""
    }

    private val PLACE_KEYS = listOf(
        "amenity", "shop", "tourism", "office", "leisure", "aeroway", "barrier", "building", "highway",
        "bridge", "man_made", "landuse", "place", "railway", "healthcare", "government"
    )

    private fun placeType(t: Map<String, String>): String {
        val k = PLACE_KEYS.firstOrNull { t[it] != null } ?: return ""
        return if (k == "bridge") "bridge" else t[k] ?: ""
    }

    private fun ownerOf(t: Map<String, String>) =
        t["operator:type"] ?: t["ownership"] ?: t["operator"] ?: ""

    fun fetch(r: Rect, cats: Set<Cat>, levels: Set<Int>, groupKeys: Set<String>): List<Feature> {
        val bbox = "(${r.s},${r.w},${r.n},${r.e});"
        val groups = PLACE_GROUPS.filter { it.key in groupKeys }
        val sb = StringBuilder("[out:json][timeout:120];")
        val geom = cats.filter { it != Cat.PLACES && it != Cat.USER }.flatMap { statements(it, levels) }
        if (geom.isNotEmpty()) {
            sb.append("(")
            geom.forEach { sb.append(it).append(bbox) }
            sb.append(");out geom tags;")
        }
        if (Cat.PLACES in cats && groups.isNotEmpty()) {
            sb.append("(")
            groups.forEach { g -> g.conds.forEach { sb.append(it.stmt()).append(bbox) } }
            sb.append(");out center tags;")
        }
        if (geom.isEmpty() && (Cat.PLACES !in cats || groups.isEmpty())) return emptyList()
        val body = "data=" + URLEncoder.encode(sb.toString(), "UTF-8")

        var last: Exception? = null
        for (ep in ENDPOINTS) {
            try {
                val conn = URL(ep).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 20000
                conn.readTimeout = 150000
                conn.setRequestProperty("User-Agent", UA)
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.outputStream.use { it.write(body.toByteArray()) }
                if (conn.responseCode != 200) throw RuntimeException("Overpass HTTP ${conn.responseCode}")
                val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                return parse(text, cats, groups)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("Overpass")
    }

    private fun pts(arr: JSONArray?): List<Ll> {
        if (arr == null) return emptyList()
        val out = ArrayList<Ll>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Ll(o.getDouble("lat"), o.getDouble("lon")))
        }
        return out
    }

    private fun closed(p: List<Ll>) = p.size >= 4 && p.first() == p.last()
    private fun centroid(p: List<Ll>) = Ll(p.map { it.lat }.average(), p.map { it.lon }.average())

    private fun parse(text: String, cats: Set<Cat>, groups: List<PlaceGroup>): List<Feature> {
        val els = JSONObject(text).optJSONArray("elements") ?: return emptyList()
        val out = ArrayList<Feature>()
        val seen = HashSet<String>()
        for (i in 0 until els.length()) {
            val el = els.getJSONObject(i)
            val elType = el.optString("type")
            if (!seen.add(elType + el.optLong("id"))) continue
            val tj = el.optJSONObject("tags")
            val tags = HashMap<String, String>()
            tj?.keys()?.forEach { k -> tags[k] = tj.optString(k) }
            val cat = classify(tags, cats, groups) ?: continue
            val name = tags["name:ar"] ?: tags["name"] ?: ""

            if (cat == Cat.PLACES) {
                val g = groups.first { it.match(tags) }
                val pt: Ll? = if (elType == "node") Ll(el.getDouble("lat"), el.getDouble("lon"))
                else el.optJSONObject("center")?.let { Ll(it.getDouble("lat"), it.getDouble("lon")) }
                if (pt != null) out.add(Feature(cat, Kind.POINT, name, placeType(tags), listOf(listOf(pt)), ownerOf(tags), g.key))
                continue
            }

            val type = typeOf(cat, tags)
            val sub = if (cat == Cat.ADMIN) tags["admin_level"] ?: "" else ""
            when (elType) {
                "node" -> out.add(Feature(cat, Kind.POINT, name, type,
                    listOf(listOf(Ll(el.getDouble("lat"), el.getDouble("lon")))), ownerOf(tags), sub))
                "way" -> {
                    val p = pts(el.optJSONArray("geometry"))
                    if (p.size < 2) continue
                    when {
                        cat == Cat.TOURIST -> out.add(Feature(cat, Kind.POINT, name, type, listOf(listOf(centroid(p))), ownerOf(tags), sub))
                        (cat == Cat.LAKES || cat == Cat.DAMS) && closed(p) ->
                            out.add(Feature(cat, Kind.POLYGON, name, type, listOf(p), "", sub))
                        else -> out.add(Feature(cat, Kind.LINE, name, type, listOf(p), "", sub))
                    }
                }
                "relation" -> {
                    val mem = el.optJSONArray("members") ?: continue
                    val rings = ArrayList<List<Ll>>()
                    for (j in 0 until mem.length()) {
                        val m = mem.getJSONObject(j)
                        if (m.optString("type") != "way") continue
                        val p = pts(m.optJSONArray("geometry"))
                        if (p.size >= 2) rings.add(p)
                    }
                    if (rings.isEmpty()) continue
                    when (cat) {
                        Cat.TOURIST -> out.add(Feature(cat, Kind.POINT, name, type, listOf(listOf(centroid(rings[0]))), ownerOf(tags), sub))
                        Cat.LAKES -> {
                            val closedRings = rings.filter { closed(it) }
                            if (closedRings.isNotEmpty()) out.add(Feature(cat, Kind.POLYGON, name, type, closedRings, "", sub))
                            val open = rings.filter { !closed(it) }
                            if (open.isNotEmpty()) out.add(Feature(cat, Kind.LINE, name, type, open, "", sub))
                        }
                        else -> out.add(Feature(cat, Kind.LINE, name, type, rings, "", sub))
                    }
                }
            }
        }
        return out.take(50000)
    }
}

object Nominatim {
    fun reverse(c: Ll): Admin {
        return try {
            val u = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=12&addressdetails=1" +
                    "&accept-language=ar&lat=${c.lat}&lon=${c.lon}"
            val conn = URL(u).openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "GeoTools-Android/1.0")
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            val a = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                .optJSONObject("address") ?: return Admin()
            fun first(vararg k: String) = k.map { a.optString(it) }.firstOrNull { it.isNotEmpty() } ?: ""
            Admin(
                gov = first("state", "region"),
                qada = first("county", "state_district", "city"),
                district = first("city_district", "suburb", "town", "village", "municipality")
            )
        } catch (e: Exception) {
            Admin()
        }
    }
}
