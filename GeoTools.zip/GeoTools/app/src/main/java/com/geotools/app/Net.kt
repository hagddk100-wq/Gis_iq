package com.geotools.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Overpass {
    private val ENDPOINTS = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter"
    )
    private const val UA = "GeoTools-Android/1.0"
    private const val EXCL = "river|canal|stream|pond|basin|ditch"
    private val MAIN = setOf("motorway", "trunk", "primary")
    private val TOUR = setOf("attraction", "museum", "viewpoint", "zoo", "theme_park", "gallery")
    private val RAILS = setOf("rail", "light_rail", "subway", "tram", "narrow_gauge", "monorail", "funicular")
    private val HOODS = setOf("suburb", "neighbourhood", "quarter")
    private val AREA_PLACES = setOf(
        "city", "town", "village", "hamlet", "suburb", "neighbourhood", "quarter", "borough", "locality", "isolated_dwelling"
    )

    private fun statements(c: Cat, levels: Set<Int>): List<String> = when (c) {
        Cat.ROADS_MAIN -> listOf("way[\"highway\"~\"^(motorway|trunk|primary)(_link)?\$\"]")
        Cat.ROADS_SEC -> listOf("way[\"highway\"~\"^(secondary|tertiary|unclassified|residential)(_link)?\$\"]")
        Cat.RAIL -> listOf("way[\"railway\"~\"^(" + RAILS.joinToString("|") + ")\$\"]")
        Cat.LAKES -> listOf(
            "way[\"natural\"=\"water\"][\"water\"!~\"$EXCL\"]",
            "relation[\"natural\"=\"water\"][\"water\"!~\"$EXCL\"]"
        )
        Cat.RIVERS -> listOf("way[\"waterway\"~\"^(river|stream|canal)\$\"]")
        Cat.DAMS -> listOf("nwr[\"waterway\"=\"dam\"]", "nwr[\"man_made\"=\"dam\"]")
        Cat.TOURIST -> listOf(
            "nwr[\"tourism\"~\"^(" + TOUR.joinToString("|") + ")\$\"]",
            "nwr[\"historic\"]"
        )
        Cat.ADMIN -> {
            val out = mutableListOf(
                "relation[\"boundary\"=\"administrative\"][\"admin_level\"~\"^(" +
                        levels.joinToString("|") + ")\$\"]"
            )
            if (levels.any { it >= 8 }) out.add("nwr[\"place\"~\"^(" + HOODS.joinToString("|") + ")\$\"]")
            out
        }
        Cat.AREAS -> listOf("nwr[\"place\"~\"^(" + AREA_PLACES.joinToString("|") + ")\$\"][\"name\"]")
        Cat.PLACES, Cat.USER -> emptyList()
    }

    private fun base(t: Map<String, String>): Cat? = when {
        t["boundary"] == "administrative" -> Cat.ADMIN
        t["place"] in HOODS -> Cat.ADMIN
        t["waterway"] == "dam" || t["man_made"] == "dam" -> Cat.DAMS
        t["waterway"] in setOf("river", "stream", "canal") -> Cat.RIVERS
        t["natural"] == "water" -> Cat.LAKES
        t["railway"] in RAILS -> Cat.RAIL
        t["highway"] != null ->
            if (t["highway"]!!.removeSuffix("_link") in MAIN) Cat.ROADS_MAIN else Cat.ROADS_SEC
        t["tourism"] in TOUR || t["historic"] != null -> Cat.TOURIST
        else -> null
    }

    private fun classify(t: Map<String, String>, cats: Set<Cat>, groups: List<PlaceGroup>): Cat? {
        if (Cat.AREAS in cats && t["place"] in AREA_PLACES && t["boundary"] != "administrative") return Cat.AREAS
        val b = base(t)
        if (b != null && b in cats) return b
        if (Cat.PLACES in cats && groups.any { it.match(t) }) return Cat.PLACES
        return null
    }

    private fun typeOf(c: Cat, t: Map<String, String>): String = when (c) {
        Cat.ROADS_MAIN, Cat.ROADS_SEC -> t["highway"] ?: ""
        Cat.RAIL -> t["railway"] ?: ""
        Cat.LAKES -> t["water"] ?: "water"
        Cat.RIVERS -> t["waterway"] ?: ""
        Cat.DAMS -> "dam"
        Cat.TOURIST -> t["tourism"] ?: t["historic"] ?: ""
        Cat.ADMIN -> if (t["boundary"] == "administrative") "admin_level=" + (t["admin_level"] ?: "")
        else "place=" + (t["place"] ?: "")
        Cat.AREAS -> t["place"] ?: ""
        Cat.PLACES, Cat.USER -> ""
    }

    private val PLACE_KEYS = listOf(
        "amenity", "shop", "tourism", "office", "leisure", "aeroway", "barrier", "building", "highway",
        "bridge", "man_made", "landuse", "place", "railway", "healthcare", "government"
    )

    private fun placeType(t: Map<String, String>): String {
        val k = PLACE_KEYS.firstOrNull { t[it] != null } ?: return ""
        return if (k == "bridge") "bridge" else t[k] ?: ""
    }

    private fun ownerOf(t: Map<String, String>) =
        t["operator:type"] ?: t["ownership"] ?: t["operator"] ?: ""

    fun fetch(r: Rect, cats: Set<Cat>, levels: Set<Int>, groupKeys: Set<String>): List<Feature> {
        val bbox = if (r.rot == 0.0) "(${r.s},${r.w},${r.n},${r.e});" else {
            val q = rectCorners(r)
            "(${q.minOf { it.lat }},${q.minOf { it.lon }},${q.maxOf { it.lat }},${q.maxOf { it.lon }});"
        }
        val groups = PLACE_GROUPS.filter { it.key in groupKeys }
        val sb = StringBuilder("[out:json][timeout:120];")
        val geom = cats.filter { it != Cat.PLACES && it != Cat.USER }.flatMap { statements(it, levels) }
        if (geom.isNotEmpty()) {
            sb.append("(")
            geom.forEach { sb.append(it).append(bbox) }
            sb.append(");out geom tags;")
        }
        if (Cat.PLACES in cats && groups.isNotEmpty()) {
            sb.append("(")
            groups.forEach { g -> g.conds.forEach { sb.append(it.stmt()).append(bbox) } }
            sb.append(");out center tags;")
        }
        if (geom.isEmpty() && (Cat.PLACES !in cats || groups.isEmpty())) return emptyList()
        val body = "data=" + URLEncoder.encode(sb.toString(), "UTF-8")

        var last: Exception? = null
        for (ep in ENDPOINTS) {
            try {
                val conn = URL(ep).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 20000
                conn.readTimeout = 150000
                conn.setRequestProperty("User-Agent", UA)
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.outputStream.use { it.write(body.toByteArray()) }
                if (conn.responseCode != 200) throw RuntimeException("Overpass HTTP ${conn.responseCode}")
                val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val all = parse(text, cats, groups)
                return if (r.rot != 0.0) all.filter { touchesRect(it, r) } else all
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("Overpass")
    }

    private fun pts(arr: JSONArray?): List<Ll> {
        if (arr == null) return emptyList()
        val out = ArrayList<Ll>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Ll(o.getDouble("lat"), o.getDouble("lon")))
        }
        return out
    }

    private fun closed(p: List<Ll>) = p.size >= 4 && p.first() == p.last()

    /** Joins boundary ways end-to-end into closed rings (returns closed rings and leftover open chains). */
    private fun assemble(segs: List<List<Ll>>): Pair<List<List<Ll>>, List<List<Ll>>> {
        val pool = segs.filter { it.size >= 2 }.map { it.toMutableList() }.toMutableList()
        val done = ArrayList<List<Ll>>()
        val open = ArrayList<List<Ll>>()
        while (pool.isNotEmpty()) {
            val cur = pool.removeAt(0)
            var progressed = true
            while (progressed && cur.first() != cur.last()) {
                progressed = false
                val end = cur.last()
                val i = pool.indexOfFirst { it.first() == end || it.last() == end }
                if (i >= 0) {
                    val n = pool.removeAt(i)
                    if (n.first() == end) cur.addAll(n.drop(1)) else cur.addAll(n.reversed().drop(1))
                    progressed = true
                    continue
                }
                val st = cur.first()
                val k = pool.indexOfFirst { it.first() == st || it.last() == st }
                if (k >= 0) {
                    val n = pool.removeAt(k)
                    val add = if (n.last() == st) n.dropLast(1) else n.reversed().dropLast(1)
                    cur.addAll(0, add)
                    progressed = true
                }
            }
            if (cur.size >= 4 && cur.first() == cur.last()) done.add(cur) else open.add(cur)
        }
        return done to open
    }
    private fun centroid(p: List<Ll>) = Ll(p.map { it.lat }.average(), p.map { it.lon }.average())

    private fun parse(text: String, cats: Set<Cat>, groups: List<PlaceGroup>): List<Feature> {
        val els = JSONObject(text).optJSONArray("elements") ?: return emptyList()
        val out = ArrayList<Feature>()
        val seen = HashSet<String>()
        for (i in 0 until els.length()) {
            val el = els.getJSONObject(i)
            val elType = el.optString("type")
            if (!seen.add(elType + el.optLong("id"))) continue
            val tj = el.optJSONObject("tags")
            val tags = HashMap<String, String>()
            tj?.keys()?.forEach { k -> tags[k] = tj.optString(k) }
            val cat = classify(tags, cats, groups) ?: continue
            val name = tags["name:ar"] ?: tags["name"] ?: ""

            if (cat == Cat.PLACES) {
                val g = groups.first { it.match(tags) }
                val pt: Ll? = if (elType == "node") Ll(el.getDouble("lat"), el.getDouble("lon"))
                else el.optJSONObject("center")?.let { Ll(it.getDouble("lat"), it.getDouble("lon")) }
                if (pt != null) out.add(Feature(cat, Kind.POINT, name, placeType(tags), listOf(listOf(pt)), ownerOf(tags), g.key))
                continue
            }

            val type = typeOf(cat, tags)
            val sub = if (cat == Cat.ADMIN) tags["admin_level"] ?: "" else ""
            when (elType) {
                "node" -> out.add(Feature(cat, Kind.POINT, name, type,
                    listOf(listOf(Ll(el.getDouble("lat"), el.getDouble("lon")))), ownerOf(tags), sub))
                "way" -> {
                    val p = pts(el.optJSONArray("geometry"))
                    if (p.size < 2) continue
                    when {
                        cat == Cat.TOURIST || cat == Cat.AREAS -> out.add(Feature(cat, Kind.POINT, name, type, listOf(listOf(centroid(p))), ownerOf(tags), sub))
                        (cat == Cat.LAKES || cat == Cat.DAMS) && closed(p) ->
                            out.add(Feature(cat, Kind.POLYGON, name, type, listOf(p), "", sub))
                        else -> out.add(Feature(cat, Kind.LINE, name, type, listOf(p), "", sub))
                    }
                }
                "relation" -> {
                    val mem = el.optJSONArray("members") ?: continue
                    val rings = ArrayList<List<Ll>>()
                    val outerRings = ArrayList<List<Ll>>()
                    for (j in 0 until mem.length()) {
                        val m = mem.getJSONObject(j)
                        if (m.optString("type") != "way") continue
                        val p = pts(m.optJSONArray("geometry"))
                        if (p.size >= 2) {
                            rings.add(p)
                            if (m.optString("role") != "inner") outerRings.add(p)
                        }
                    }
                    if (rings.isEmpty()) continue
                    when (cat) {
                        Cat.TOURIST, Cat.AREAS -> out.add(Feature(cat, Kind.POINT, name, type, listOf(listOf(centroid(rings[0]))), ownerOf(tags), sub))
                        Cat.ADMIN -> {
                            val (closedR, openR) = assemble(outerRings.ifEmpty { rings })
                            if (closedR.isNotEmpty()) out.add(Feature(cat, Kind.POLYGON, name, type, closedR, "", sub))
                            if (openR.isNotEmpty()) out.add(Feature(cat, Kind.LINE, name, type, openR, "", sub))
                        }
                        Cat.LAKES -> {
                            val closedRings = rings.filter { closed(it) }
                            if (closedRings.isNotEmpty()) out.add(Feature(cat, Kind.POLYGON, name, type, closedRings, "", sub))
                            val open = rings.filter { !closed(it) }
                            if (open.isNotEmpty()) out.add(Feature(cat, Kind.LINE, name, type, open, "", sub))
                        }
                        else -> out.add(Feature(cat, Kind.LINE, name, type, rings, "", sub))
                    }
                }
            }
        }
        return out.take(50000)
    }
}

object Nominatim {
    fun reverse(c: Ll): Admin {
        return try {
            val u = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=12&addressdetails=1" +
                    "&accept-language=ar&lat=${c.lat}&lon=${c.lon}"
            val conn = URL(u).openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "GeoTools-Android/1.0")
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            val a = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                .optJSONObject("address") ?: return Admin()
            fun first(vararg k: String) = k.map { a.optString(it) }.firstOrNull { it.isNotEmpty() } ?: ""
            Admin(
                gov = first("state", "region"),
                qada = first("county", "state_district", "city"),
                district = first("city_district", "suburb", "town", "village", "municipality")
            )
        } catch (e: Exception) {
            Admin()
        }
    }
}


class GPlace(val lat: Double, val lon: Double, val name: String, val type: String, val addr: String)

val GP_PROVIDERS = listOf("Google", "Foursquare", "Geoapify", "TomTom", "HERE")
const val GP_CUSTOM = 5

/** Online places providers (any API key). Results are only displayed, never stored. */
object PlacesApi {
    private const val GEO_CATS =
        "commercial,catering,accommodation,tourism,entertainment,education,healthcare,religion,service,office,public_transport,heritage,leisure"

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    fun nearby(prov: Int, c: Ll, radiusM: Double, key: String, lang: String, url: String, hdr: String): List<GPlace> {
        val rad = radiusM.toInt().coerceIn(50, 50000)
        return when (prov) {
            0 -> google(c, rad, key, lang)
            1 -> generic(
                "https://places-api.foursquare.com/places/search?ll=${c.lat},${c.lon}&radius=$rad&limit=50",
                mapOf("Authorization" to "Bearer $key", "X-Places-Api-Version" to "2025-06-17", "Accept" to "application/json")
            )
            2 -> generic("https://api.geoapify.com/v2/places?categories=$GEO_CATS&filter=circle:${c.lon},${c.lat},$rad&limit=100&apiKey=${enc(key)}", emptyMap())
            3 -> generic("https://api.tomtom.com/search/2/nearbySearch/.json?lat=${c.lat}&lon=${c.lon}&radius=$rad&limit=100&key=${enc(key)}", emptyMap())
            4 -> generic("https://browse.search.hereapi.com/v1/browse?in=" + enc("circle:${c.lat},${c.lon};r=$rad") + "&limit=100&apiKey=${enc(key)}", emptyMap())
            else -> {
                val u = url.trim()
                    .replace("{lat}", c.lat.toString()).replace("{lon}", c.lon.toString())
                    .replace("{radius}", rad.toString()).replace("{key}", enc(key))
                val h = HashMap<String, String>()
                val line = hdr.trim()
                if (line.contains(":")) h[line.substringBefore(":").trim()] = line.substringAfter(":").trim().replace("{key}", key)
                generic(u, h)
            }
        }
    }

    private fun readError(conn: HttpURLConnection, name: String): Nothing {
        val err = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        val msg = try { JSONObject(err).getJSONObject("error").getString("message") } catch (e: Exception) { err.take(200) }
        throw RuntimeException("$name ${conn.responseCode}: $msg")
    }

    private fun google(c: Ll, rad: Int, key: String, lang: String): List<GPlace> {
        val body = JSONObject()
            .put("maxResultCount", 20)
            .put("languageCode", lang)
            .put("locationRestriction", JSONObject().put("circle", JSONObject()
                .put("center", JSONObject().put("latitude", c.lat).put("longitude", c.lon))
                .put("radius", rad.toDouble())))
        val conn = URL("https://places.googleapis.com/v1/places:searchNearby").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("X-Goog-Api-Key", key)
        conn.setRequestProperty(
            "X-Goog-FieldMask",
            "places.id,places.displayName,places.location,places.primaryTypeDisplayName,places.formattedAddress"
        )
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        if (conn.responseCode != 200) readError(conn, "Google")
        val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONObject(text).optJSONArray("places") ?: return emptyList()
        val out = ArrayList<GPlace>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val loc = p.optJSONObject("location") ?: continue
            out.add(GPlace(
                loc.getDouble("latitude"), loc.getDouble("longitude"),
                p.optJSONObject("displayName")?.optString("text") ?: "",
                p.optJSONObject("primaryTypeDisplayName")?.optString("text") ?: "",
                p.optString("formattedAddress")
            ))
        }
        return out
    }

    private fun generic(u: String, headers: Map<String, String>): List<GPlace> {
        val conn = URL(u).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("User-Agent", "GeoTools-Android/1.0")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        if (conn.responseCode !in 200..299) readError(conn, "API")
        val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val out = ArrayList<GPlace>()
        walk(org.json.JSONTokener(text).nextValue(), "", "", out, HashSet(), 0)
        return out
    }

    private fun num(o: JSONObject, vararg keys: String): Double? {
        for (k in keys) {
            when (val v = o.opt(k)) {
                is Number -> return v.toDouble()
                is String -> v.toDoubleOrNull()?.let { return it }
            }
        }
        return null
    }

    private fun textOf(v: Any?): String = when (v) {
        is String -> v
        is JSONObject -> v.optString("text").ifEmpty { v.optString("name") }.ifEmpty { v.optString("title") }
        else -> ""
    }

    private fun nameOf(o: JSONObject): String {
        for (k in listOf("name", "title", "displayName", "label")) {
            val t = textOf(o.opt(k))
            if (t.isNotEmpty()) return t
        }
        o.optJSONObject("poi")?.let { val t = textOf(it.opt("name")); if (t.isNotEmpty()) return t }
        o.optJSONObject("properties")?.let { val t = textOf(it.opt("name")); if (t.isNotEmpty()) return t }
        return ""
    }

    private fun firstCat(v: Any?): String = when (v) {
        is org.json.JSONArray -> if (v.length() > 0) textOf(v.opt(0)) else ""
        else -> textOf(v)
    }

    private fun typeOf(o: JSONObject): String {
        val t = firstCat(o.opt("categories")).ifEmpty { firstCat(o.opt("category")) }
        if (t.isNotEmpty()) return t
        o.optJSONObject("poi")?.let { val c = firstCat(it.opt("categories")); if (c.isNotEmpty()) return c }
        o.optJSONObject("properties")?.let { val c = firstCat(it.opt("categories")); if (c.isNotEmpty()) return c }
        val ty = o.optString("type")
        return if (ty in setOf("", "Feature", "Point", "FeatureCollection")) "" else ty
    }

    private fun addrOf(o: JSONObject): String {
        for (k in listOf("formattedAddress", "formatted_address", "formatted", "address", "vicinity")) {
            val v = o.opt(k)
            val t = if (v is JSONObject) v.optString("freeformAddress").ifEmpty { v.optString("label") }.ifEmpty { v.optString("formatted_address") } else textOf(v)
            if (t.isNotEmpty()) return t
        }
        o.optJSONObject("location")?.optString("formatted_address")?.let { if (it.isNotEmpty()) return it }
        o.optJSONObject("properties")?.optString("formatted")?.let { if (it.isNotEmpty()) return it }
        return ""
    }

    /** Finds every object that carries coordinates, whatever the provider's JSON layout is. */
    private fun walk(n: Any?, pName: String, pType: String, out: MutableList<GPlace>, seen: HashSet<String>, depth: Int) {
        if (out.size >= 200 || depth > 8) return
        when (n) {
            is org.json.JSONArray -> for (i in 0 until n.length()) walk(n.opt(i), pName, pType, out, seen, depth + 1)
            is JSONObject -> {
                val nm = nameOf(n).ifEmpty { pName }
                val tp = typeOf(n).ifEmpty { pType }
                var lat = num(n, "lat", "latitude")
                var lon = num(n, "lon", "lng", "longitude")
                if (lat == null || lon == null) {
                    val co = n.optJSONArray("coordinates")
                    if (n.optString("type") == "Point" && co != null && co.length() >= 2) {
                        lon = co.optDouble(0); lat = co.optDouble(1)
                    }
                }
                if (lat != null && lon != null && Math.abs(lat) <= 90 && Math.abs(lon) <= 180) {
                    if (seen.add("$lat,$lon,$nm")) out.add(GPlace(lat, lon, nm, tp, addrOf(n)))
                    return
                }
                val it = n.keys()
                while (it.hasNext()) walk(n.opt(it.next()), nm, tp, out, seen, depth + 1)
            }
        }
    }
}

/** Ground elevation (meters) at a point, from the free Open-Meteo elevation service. */
object Elevation {
    fun at(c: Ll): Int? {
        val conn = URL("https://api.open-meteo.com/v1/elevation?latitude=${c.lat}&longitude=${c.lon}")
            .openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.setRequestProperty("User-Agent", "GeoTools-Android/1.0")
        if (conn.responseCode != 200) return null
        val arr = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
            .optJSONArray("elevation") ?: return null
        return if (arr.length() > 0) Math.round(arr.getDouble(0)).toInt() else null
    }
}
