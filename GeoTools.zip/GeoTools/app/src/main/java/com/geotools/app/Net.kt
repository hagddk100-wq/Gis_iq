package com.geotools.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Overpass {
    private val ENDPOINTS = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter"
    )
    private const val UA = "GeoTools-Android/1.0"
    private const val EXCL = "river|canal|stream|pond|basin|ditch"

    private fun statements(c: Cat): List<String> = when (c) {
        Cat.ROADS_MAIN -> listOf("way[\"highway\"~\"^(motorway|trunk|primary)(_link)?\$\"]")
        Cat.ROADS_SEC -> listOf("way[\"highway\"~\"^(secondary|tertiary|unclassified|residential)(_link)?\$\"]")
        Cat.LAKES -> listOf(
            "way[\"natural\"=\"water\"][\"water\"!~\"$EXCL\"]",
            "relation[\"natural\"=\"water\"][\"water\"!~\"$EXCL\"]"
        )
        Cat.RIVERS -> listOf("way[\"waterway\"~\"^(river|stream|canal)\$\"]")
        Cat.DAMS -> listOf("nwr[\"waterway\"=\"dam\"]", "nwr[\"man_made\"=\"dam\"]")
        Cat.TOURIST -> listOf(
            "nwr[\"tourism\"~\"^(attraction|museum|viewpoint|zoo|theme_park|gallery)\$\"]",
            "nwr[\"historic\"]"
        )
        Cat.ADMIN -> listOf("relation[\"boundary\"=\"administrative\"][\"admin_level\"~\"^[4-8]\$\"]")
    }

    private fun classify(t: Map<String, String>): Cat? = when {
        t["boundary"] == "administrative" -> Cat.ADMIN
        t["waterway"] == "dam" || t["man_made"] == "dam" -> Cat.DAMS
        t["waterway"] in setOf("river", "stream", "canal") -> Cat.RIVERS
        t["natural"] == "water" -> Cat.LAKES
        t["highway"] != null -> {
            if (t["highway"]!!.removeSuffix("_link") in setOf("motorway", "trunk", "primary"))
                Cat.ROADS_MAIN else Cat.ROADS_SEC
        }
        t["tourism"] != null || t["historic"] != null -> Cat.TOURIST
        else -> null
    }

    private fun typeOf(c: Cat, t: Map<String, String>): String = when (c) {
        Cat.ROADS_MAIN, Cat.ROADS_SEC -> t["highway"] ?: ""
        Cat.LAKES -> t["water"] ?: "water"
        Cat.RIVERS -> t["waterway"] ?: ""
        Cat.DAMS -> "dam"
        Cat.TOURIST -> t["tourism"] ?: t["historic"] ?: ""
        Cat.ADMIN -> "admin_level=" + (t["admin_level"] ?: "")
    }

    fun fetch(r: Rect, cats: Set<Cat>): List<Feature> {
        val bbox = "(${r.s},${r.w},${r.n},${r.e});"
        val sb = StringBuilder("[out:json][timeout:90];(")
        cats.forEach { c -> statements(c).forEach { sb.append(it).append(bbox) } }
        sb.append(");out geom tags;")
        val body = "data=" + URLEncoder.encode(sb.toString(), "UTF-8")

        var last: Exception? = null
        for (ep in ENDPOINTS) {
            try {
                val conn = URL(ep).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 20000
                conn.readTimeout = 120000
                conn.setRequestProperty("User-Agent", UA)
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.outputStream.use { it.write(body.toByteArray()) }
                if (conn.responseCode != 200) throw RuntimeException("Overpass HTTP ${conn.responseCode}")
                val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                return parse(text, cats)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("Overpass")
    }

    private fun pts(arr: JSONArray?): List<Ll> {
        if (arr == null) return emptyList()
        val out = ArrayList<Ll>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Ll(o.getDouble("lat"), o.getDouble("lon")))
        }
        return out
    }

    private fun closed(p: List<Ll>) = p.size >= 4 && p.first() == p.last()

    private fun centroid(p: List<Ll>) = Ll(p.map { it.lat }.average(), p.map { it.lon }.average())

    private fun parse(text: String, cats: Set<Cat>): List<Feature> {
        val els = JSONObject(text).optJSONArray("elements") ?: return emptyList()
        val out = ArrayList<Feature>()
        for (i in 0 until els.length()) {
            val el = els.getJSONObject(i)
            val tj = el.optJSONObject("tags")
            val tags = HashMap<String, String>()
            tj?.keys()?.forEach { k -> tags[k] = tj.optString(k) }
            val cat = classify(tags) ?: continue
            if (cat !in cats) continue
            val name = tags["name:ar"] ?: tags["name"] ?: ""
            val type = typeOf(cat, tags)
            when (el.getString("type")) {
                "node" -> out.add(Feature(cat, Kind.POINT, name, type,
                    listOf(listOf(Ll(el.getDouble("lat"), el.getDouble("lon"))))))
                "way" -> {
                    val p = pts(el.optJSONArray("geometry"))
                    if (p.size < 2) continue
                    when {
                        cat == Cat.TOURIST -> out.add(Feature(cat, Kind.POINT, name, type, listOf(listOf(centroid(p)))))
                        (cat == Cat.LAKES || cat == Cat.DAMS) && closed(p) ->
                            out.add(Feature(cat, Kind.POLYGON, name, type, listOf(p)))
                        else -> out.add(Feature(cat, Kind.LINE, name, type, listOf(p)))
                    }
                }
                "relation" -> {
                    val mem = el.optJSONArray("members") ?: continue
                    val rings = ArrayList<List<Ll>>()
                    for (j in 0 until mem.length()) {
                        val m = mem.getJSONObject(j)
                        if (m.optString("type") != "way") continue
                        val p = pts(m.optJSONArray("geometry"))
                        if (p.size >= 2) rings.add(p)
                    }
                    if (rings.isEmpty()) continue
                    when (cat) {
                        Cat.TOURIST -> out.add(Feature(cat, Kind.POINT, name, type, listOf(listOf(centroid(rings[0])))))
                        Cat.LAKES -> {
                            val closedRings = rings.filter { closed(it) }
                            if (closedRings.isNotEmpty())
                                out.add(Feature(cat, Kind.POLYGON, name, type, closedRings))
                            val open = rings.filter { !closed(it) }
                            if (open.isNotEmpty())
                                out.add(Feature(cat, Kind.LINE, name, type, open))
                        }
                        else -> out.add(Feature(cat, Kind.LINE, name, type, rings))
                    }
                }
            }
        }
        return out
    }
}

object Nominatim {
    fun reverse(c: Ll): Admin {
        return try {
            val u = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=12&addressdetails=1" +
                    "&accept-language=ar&lat=${c.lat}&lon=${c.lon}"
            val conn = URL(u).openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "GeoTools-Android/1.0")
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            val a = JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                .optJSONObject("address") ?: return Admin()
            fun first(vararg k: String) = k.map { a.optString(it) }.firstOrNull { it.isNotEmpty() } ?: ""
            Admin(
                gov = first("state", "region"),
                qada = first("county", "state_district", "city"),
                district = first("city_district", "suburb", "town", "village", "municipality")
            )
        } catch (e: Exception) {
            Admin()
        }
    }
}
