package com.geotools.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

val ACCENT_LIGHT = listOf(0xFF1565C0, 0xFF2E7D32, 0xFFE65100, 0xFF6A1B9A)
val ACCENT_DARK = listOf(0xFF90CAF9, 0xFFA5D6A7, 0xFFFFB74D, 0xFFCE93D8)

@Composable
fun App() {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(loadCfg(ctx)) }
    val setCfg: (Cfg) -> Unit = { cfg = it; saveCfg(ctx, it) }
    var screen by remember { mutableStateOf("map") }
    var menu by remember { mutableStateOf(false) }
    val dark = when (cfg.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val dir = if (cfg.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    val click = rememberClick(cfg.sound)
    val t = { k: String -> tr(cfg.lang, k) }
    val ai = cfg.accent.coerceIn(0, 3)

    BackHandler(enabled = menu) { menu = false }
    BackHandler(enabled = !menu && screen != "map") { screen = "map" }

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Color(ACCENT_DARK[ai]))
        else lightColorScheme(primary = Color(ACCENT_LIGHT[ai]))
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            CompositionLocalProvider(LocalLayoutDirection provides dir) {
                Box(Modifier.fillMaxSize()) {
                    when (screen) {
                        "map" -> MapScreen(cfg, setCfg, click) { menu = true }
                        "conv" -> Page(t("converter"), { menu = true }, click) { ConverterScreen(cfg, click) }
                        else -> Page(t("settings"), { menu = true }, click) { SettingsScreen(cfg, setCfg, click) }
                    }
                    // The side menu is laid out LTR so it always opens from the left.
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        SideMenu(menu, { menu = false }) {
                            CompositionLocalProvider(LocalLayoutDirection provides dir) {
                                Column {
                                    Text(
                                        t("app"), style = MaterialTheme.typography.titleLarge,
                                        modifier = Modifier.padding(16.dp)
                                    )
                                    listOf("map" to "map", "conv" to "converter", "set" to "settings").forEach { (id, k) ->
                                        NavigationDrawerItem(
                                            label = { Text(t(k)) }, selected = screen == id,
                                            onClick = { click(); screen = id; menu = false }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SideMenu(open: Boolean, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(open, enter = fadeIn(), exit = fadeOut()) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose
            )
        )
    }
    AnimatedVisibility(open, enter = slideInHorizontally { -it }, exit = slideOutHorizontally { -it }) {
        Surface(
            Modifier.fillMaxHeight().width(290.dp), shadowElevation = 16.dp,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(8.dp), content = content)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Page(title: String, onMenu: () -> Unit, click: () -> Unit, content: @Composable () -> Unit) {
    Scaffold(topBar = {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = { click(); onMenu() }) { Icon(Icons.Default.Menu, contentDescription = null) }
                }
            )
        }
    }) { pad -> Box(Modifier.padding(pad).fillMaxSize()) { content() } }
}
