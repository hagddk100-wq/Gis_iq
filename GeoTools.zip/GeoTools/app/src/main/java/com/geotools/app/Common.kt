package com.geotools.app

import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp

data class Cfg(
    val theme: Int = 0, val lang: String = "ar", val sound: Boolean = true,
    val fmt: Int = 2, val selMode: Int = 0,
    val w: Double = 2000.0, val h: Double = 2000.0, val tree: String = "",
    val accent: Int = 0, val mapType: Int = 0, val exp: Int = 1,
    val lockOn: Boolean = false, val lockTimeout: Int = 0,
    val gp: Boolean = false, val gpKey: String = "",
    val gpProv: Int = 0, val gpUrl: String = "", val gpHdr: String = ""
)

fun loadCfg(c: Context): Cfg {
    val p = c.getSharedPreferences("cfg", 0)
    return Cfg(
        p.getInt("theme", 0), p.getString("lang", "ar")!!, p.getBoolean("sound", true),
        p.getInt("fmt2", 2), p.getInt("sel", 0),
        p.getFloat("w", 2000f).toDouble(), p.getFloat("h", 2000f).toDouble(),
        p.getString("tree", "")!!, p.getInt("accent", 0), p.getInt("mapType", 0), p.getInt("exp", 1),
        PinStore.isSet(c), p.getInt("lockTimeout", 0),
        p.getBoolean("gp", false), p.getString("gpKey", "")!!,
        p.getInt("gpProv", 0), p.getString("gpUrl", "")!!, p.getString("gpHdr", "")!!
    )
}

fun saveCfg(c: Context, x: Cfg) {
    c.getSharedPreferences("cfg", 0).edit()
        .putInt("theme", x.theme).putString("lang", x.lang).putBoolean("sound", x.sound)
        .putInt("fmt2", x.fmt).putInt("sel", x.selMode)
        .putFloat("w", x.w.toFloat()).putFloat("h", x.h.toFloat())
        .putString("tree", x.tree).putInt("accent", x.accent).putInt("mapType", x.mapType)
        .putInt("exp", x.exp).putInt("lockTimeout", x.lockTimeout)
        .putBoolean("gp", x.gp).putString("gpKey", x.gpKey)
        .putInt("gpProv", x.gpProv).putString("gpUrl", x.gpUrl).putString("gpHdr", x.gpHdr).apply()
}

@Composable
fun rememberClick(sound: Boolean): () -> Unit {
    val view = LocalView.current
    return {
        if (sound) view.playSoundEffect(SoundEffectConstants.CLICK)
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }
}

@Composable
fun Field(label: String, v: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = v, onValueChange = onChange, label = { Text(label) },
        singleLine = true, modifier = Modifier.fillMaxWidth()
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Choice(options: List<String>, sel: Int, click: () -> Unit, onSel: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, s ->
            FilterChip(selected = sel == i, onClick = { click(); onSel(i) }, label = { Text(s) })
        }
    }
}
