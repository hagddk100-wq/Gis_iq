package com.geotools.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object UserStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("user_features", 0)

    fun load(ctx: Context): List<Feature> = try {
        val a = JSONArray(prefs(ctx).getString("f", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val pa = o.getJSONArray("p")
            val pts = (0 until pa.length()).map { j ->
                val q = pa.getJSONArray(j)
                Ll(q.getDouble(0), q.getDouble(1))
            }
            Feature(Cat.USER, Kind.valueOf(o.getString("k")), o.getString("n"), "user", listOf(pts))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(ctx: Context, list: List<Feature>) {
        val a = JSONArray()
        list.forEach { f ->
            val pa = JSONArray()
            f.parts[0].forEach { pa.put(JSONArray().put(it.lat).put(it.lon)) }
            a.put(JSONObject().put("k", f.kind.name).put("n", f.name).put("p", pa))
        }
        prefs(ctx).edit().putString("f", a.toString()).apply()
    }
}

object Measure {
    fun dist(a: Ll, b: Ll): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * atan2(sqrt(h), sqrt(1 - h))
    }

    fun length(p: List<Ll>): Double = p.zipWithNext { a, b -> dist(a, b) }.sum()

    fun area(p: List<Ll>): Double {
        if (p.size < 3) return 0.0
        val z = GeoConverter.zoneOf(p[0].lon)
        val u = p.map { GeoConverter.toUtm(it.lat, it.lon, z) }
        var s = 0.0
        for (i in u.indices) {
            val j = (i + 1) % u.size
            s += u[i].e * u[j].n - u[j].e * u[i].n
        }
        return abs(s) / 2
    }

    fun fmtLen(m: Double): String =
        if (m >= 1000) String.format(Locale.US, "%.2f km", m / 1000) else String.format(Locale.US, "%.0f m", m)

    fun fmtArea(a: Double, lang: String): String =
        String.format(Locale.US, "%.0f m²  •  %.2f %s  •  %.2f %s", a, a / 2500, tr(lang, "dunam"), a / 10000, tr(lang, "hectare"))

    fun text(f: Feature, lang: String): String = when (f.kind) {
        Kind.POINT -> ""
        Kind.LINE -> tr(lang, "length") + ": " + fmtLen(length(f.parts[0]))
        Kind.POLYGON -> tr(lang, "area") + ": " + fmtArea(area(f.parts[0]), lang)
    }
}
