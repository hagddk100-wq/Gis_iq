package com.geotools.app

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SaveResult(val uris: List<Uri>, val where: String)

object Exporter {
    fun build(feats: List<Feature>, admin: Admin, zone: Int): Map<String, ByteArray> {
        val files = LinkedHashMap<String, ByteArray>()
        feats.groupBy { it.cat to it.kind }.forEach { (key, list) ->
            val base = key.first.key + "_" + key.second.name.lowercase()
            val attrs = list.map { f ->
                val c = center(f)
                val u = GeoConverter.toUtm(c.lat, c.lon, zone)
                Attr(f.name, f.type, f.cat.key, admin.district, admin.qada, admin.gov,
                    u.e, u.n, "$zone" + if (u.north) "N" else "S")
            }
            files.putAll(ShapefileWriter.build(base, key.second, list, attrs))
        }
        return files
    }

    private fun center(f: Feature): Ll {
        val p = f.parts[0]
        return Ll(p.map { it.lat }.average(), p.map { it.lon }.average())
    }

    fun save(ctx: Context, tree: String, files: Map<String, ByteArray>): SaveResult {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        if (tree.isNotEmpty()) {
            val root = DocumentFile.fromTreeUri(ctx, Uri.parse(tree))
                ?: throw RuntimeException("Folder")
            val dir = root.createDirectory("export_$stamp") ?: throw RuntimeException("Folder")
            val uris = files.map { (n, b) ->
                val f = dir.createFile("application/octet-stream", n) ?: throw RuntimeException(n)
                ctx.contentResolver.openOutputStream(f.uri)!!.use { it.write(b) }
                f.uri
            }
            return SaveResult(uris, (root.name ?: "") + "/export_$stamp")
        }
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "exports/export_$stamp")
        dir.mkdirs()
        val uris = files.map { (n, b) ->
            val f = File(dir, n)
            f.writeBytes(b)
            FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        }
        return SaveResult(uris, dir.absolutePath)
    }
}
