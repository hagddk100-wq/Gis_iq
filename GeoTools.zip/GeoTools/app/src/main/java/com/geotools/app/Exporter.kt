package com.geotools.app

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SaveResult(val uris: List<Uri>, val where: String)

object Fmt {
    const val SHP = 1
    const val XLSX = 2
    const val KML = 4
    const val KMZ = 8
}

object Exporter {
    fun build(feats: List<Feature>, admin: Admin, zone: Int, mask: Int, lang: String, idx: AdminIndex? = null): Map<String, ByteArray> {
        val files = LinkedHashMap<String, ByteArray>()
        if (mask and Fmt.SHP != 0) {
            feats.groupBy { it.cat to it.kind }.forEach { (key, list) ->
                val base = key.first.key + "_" + key.second.name.lowercase()
                val attrs = list.map { f ->
                    val c = featureCenter(f)
                    val u = GeoConverter.toUtm(c.lat, c.lon, zone)
                    val (qd, nh) = idx?.of(f) ?: (admin.qada to admin.district)
                    Attr(f.name, f.type, f.cat.key + (if (f.sub.isNotEmpty()) "/" + f.sub else ""),
                        nh, qd, admin.gov,
                        u.e, u.n, "$zone${u.band}", f.owner)
                }
                files.putAll(ShapefileWriter.build(base, key.second, list, attrs))
            }
        }
        if (mask and Fmt.XLSX != 0) files["geotools.xlsx"] = Xlsx.build(feats, admin, zone, lang, idx)
        if (mask and (Fmt.KML or Fmt.KMZ) != 0) {
            val kml = Kml.build(feats, admin, zone, lang, idx)
            if (mask and Fmt.KML != 0) files["geotools.kml"] = kml.toByteArray(Charsets.UTF_8)
            if (mask and Fmt.KMZ != 0) files["geotools.kmz"] = Kml.toKmz(kml)
        }
        return files
    }

    fun save(ctx: Context, tree: String, files: Map<String, ByteArray>): SaveResult {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        if (tree.isNotEmpty()) {
            val root = DocumentFile.fromTreeUri(ctx, Uri.parse(tree))
                ?: throw RuntimeException("Folder")
            val dir = root.createDirectory("export_$stamp") ?: throw RuntimeException("Folder")
            val uris = files.map { (n, b) ->
                val f = dir.createFile("application/octet-stream", n) ?: throw RuntimeException(n)
                ctx.contentResolver.openOutputStream(f.uri)!!.use { it.write(b) }
                f.uri
            }
            return SaveResult(uris, (root.name ?: "") + "/export_$stamp")
        }
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "exports/export_$stamp")
        dir.mkdirs()
        val uris = files.map { (n, b) ->
            val f = File(dir, n)
            f.writeBytes(b)
            FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        }
        return SaveResult(uris, dir.absolutePath)
    }
}
