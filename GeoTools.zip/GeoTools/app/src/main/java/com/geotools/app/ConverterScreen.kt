package com.geotools.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp

@Composable
fun ConverterScreen(cfg: Cfg, click: () -> Unit, onGoto: (Ll) -> Unit) {
    val t = { k: String -> tr(cfg.lang, k) }
    var mode by remember { mutableIntStateOf(0) }
    var f1 by remember { mutableStateOf("") }
    var f2 by remember { mutableStateOf("") }
    var f3 by remember { mutableStateOf("") }
    var res by remember { mutableStateOf<Ll?>(null) }
    var err by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Choice(listOf("DD / DMS", "UTM", "MGRS"), mode, click) { mode = it; res = null; err = false }
        when (mode) {
            0 -> { Field(t("lat"), f1) { f1 = it }; Field(t("lon"), f2) { f2 = it } }
            1 -> { Field(t("zone"), f1) { f1 = it }; Field(t("easting"), f2) { f2 = it }; Field(t("northing"), f3) { f3 = it } }
            else -> Field(t("mgrs"), f1) { f1 = it }
        }
        Button(onClick = {
            click()
            err = false
            res = try {
                when (mode) {
                    0 -> Ll(GeoConverter.parseAngle(f1), GeoConverter.parseAngle(f2)).also {
                        require(Math.abs(it.lat) <= 90 && Math.abs(it.lon) <= 180)
                    }
                    1 -> GeoConverter.parseUtm(f1, f2, f3)
                    else -> GeoConverter.mgrsToLatLon(f1)
                }
            } catch (e: Exception) { err = true; null }
        }, modifier = Modifier.fillMaxWidth()) { Text(t("convert")) }

        if (err) Text(t("invalid"), color = MaterialTheme.colorScheme.error)

        res?.let { ll ->
            val rows = listOf(
                "DD" to GeoConverter.fmtDd(ll),
                "DMS" to GeoConverter.fmtDms(ll),
                "UTM" to GeoConverter.fmtUtm(GeoConverter.toUtm(ll.lat, ll.lon)),
                "MGRS" to GeoConverter.toMgrs(ll.lat, ll.lon),
                t("meridian") to String.format(java.util.Locale.US, "%.6f°", ll.lon),
                t("parallel") to String.format(java.util.Locale.US, "%.6f°", ll.lat)
            )
            rows.forEach { (k, v) ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(k, style = MaterialTheme.typography.labelMedium)
                            Text(v, style = MaterialTheme.typography.bodyLarge)
                        }
                        TextButton(onClick = { click(); clip.setText(AnnotatedString(v)) }) { Text(t("copy")) }
                        TextButton(onClick = { click(); onGoto(ll) }) { Text(t("goto")) }
                    }
                }
            }
        }
    }
}
