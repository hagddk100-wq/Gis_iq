package com.geotools.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp

@Composable
fun ConverterScreen(cfg: Cfg, click: () -> Unit, onGoto: (Ll) -> Unit) {
    val t = { k: String -> tr(cfg.lang, k) }
    var input by remember { mutableStateOf("") }
    val clip = LocalClipboardManager.current

    // The format (DD / DMS / UTM / MGRS) is detected from the text itself while typing.
    val parsed: Parsed? = remember(input) {
        if (input.isBlank()) null else try { GeoConverter.parseAuto(input) } catch (e: Exception) { null }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = input, onValueChange = { input = it },
            label = { Text(t("coord_in")) },
            minLines = 2, modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = {
                click()
                clip.getText()?.text?.let { input = it }
            }) { Text(t("paste")) }
            if (input.isNotBlank()) OutlinedButton(onClick = { click(); input = "" }) { Text(t("clear")) }
            if (parsed != null) Text(t("detected") + ": " + parsed.kind, style = MaterialTheme.typography.labelLarge)
        }

        if (input.isNotBlank() && parsed == null) Text(t("invalid"), color = MaterialTheme.colorScheme.error)

        parsed?.ll?.let { ll ->
            val rows = listOf(
                "DD" to GeoConverter.fmtDd(ll),
                "DMS" to GeoConverter.fmtDms(ll),
                "UTM" to GeoConverter.fmtUtm(GeoConverter.toUtm(ll.lat, ll.lon)),
                "MGRS" to GeoConverter.toMgrs(ll.lat, ll.lon),
                t("meridian") to String.format(java.util.Locale.US, "%.6f°", ll.lon),
                t("parallel") to String.format(java.util.Locale.US, "%.6f°", ll.lat)
            )
            rows.forEach { (k, v) ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(k, style = MaterialTheme.typography.labelMedium)
                            Text(v, style = MaterialTheme.typography.bodyLarge)
                        }
                        TextButton(onClick = { click(); clip.setText(AnnotatedString(v)) }) { Text(t("copy")) }
                        TextButton(onClick = { click(); onGoto(ll) }) { Text(t("goto")) }
                    }
                }
            }
        }
    }
}
