package com.geotools.app

private val ar = mapOf(
    "app" to "أدوات الإحداثيات", "converter" to "محول الإحداثيات", "map" to "الخريطة والتصدير",
    "settings" to "الإعدادات", "theme" to "المظهر", "system" to "النظام", "light" to "فاتح", "dark" to "داكن",
    "accent" to "لون التطبيق", "a_blue" to "أزرق", "a_green" to "أخضر", "a_orange" to "برتقالي", "a_purple" to "بنفسجي",
    "language" to "اللغة", "folder" to "مجلد الحفظ", "choose_folder" to "اختيار مجلد",
    "default_folder" to "المجلد الافتراضي للتطبيق", "fmt" to "نوع الإحداثيات", "sel_mode" to "نوع المستطيل",
    "center_size" to "مركز + أبعاد", "two_corners" to "نقطتان (زاويتان)",
    "width" to "العرض (متر)", "height" to "الطول (متر)", "sound" to "أصوات وهزاز الأزرار",
    "map_type" to "نوع الخريطة", "mt_std" to "عادية", "mt_topo" to "طبوغرافية", "mt_sat" to "قمر صناعي",
    "convert" to "تحويل", "lat" to "خط العرض (دائرة العرض)", "lon" to "خط الطول",
    "zone" to "المنطقة (مثال 38N)", "easting" to "X (شرقي)", "northing" to "Y (شمالي)", "mgrs" to "إحداثي MGRS",
    "copy" to "نسخ", "invalid" to "قيمة غير صالحة", "meridian" to "خط الطول", "parallel" to "دائرة العرض",
    "export" to "تصدير", "share" to "مشاركة الملفات", "fetching" to "جاري تنزيل المعالم…",
    "saved" to "تم الحفظ", "tap_center" to "المس الخريطة لوضع المستطيل",
    "tap_corners" to "المس الخريطة لتحديد الزاوية الأولى", "pick_second" to "المس الزاوية الثانية",
    "drag_hint" to "اسحب المستطيل لتحريكه، واسحب الزوايا لتغيير حجمه",
    "too_big" to "المنطقة كبيرة (الحد الأقصى 100 كم)", "none_found" to "لا توجد معالم في المنطقة",
    "features" to "المعالم", "none_selected" to "لم تختر أي معلم أو صيغة",
    "roads_main" to "الطرق الرئيسية", "roads_sec" to "الطرق الثانوية", "lakes" to "البحيرات",
    "rivers" to "الأنهار", "dams" to "السدود", "tourist" to "المعالم السياحية", "admin" to "الحدود الإدارية",
    "categories" to "الطبقات", "search_hint" to "ابحث عن مكان…", "preview" to "معاينة المعالم",
    "back_edit" to "تعديل المنطقة", "formats" to "صيغ التصدير",
    "f_shp" to "Shapefile", "f_xlsx" to "Excel", "f_kml" to "KML", "f_kmz" to "KMZ"
)

private val en = mapOf(
    "app" to "Geo Tools", "converter" to "Coordinate converter", "map" to "Map & export",
    "settings" to "Settings", "theme" to "Theme", "system" to "System", "light" to "Light", "dark" to "Dark",
    "accent" to "Accent color", "a_blue" to "Blue", "a_green" to "Green", "a_orange" to "Orange", "a_purple" to "Purple",
    "language" to "Language", "folder" to "Save folder", "choose_folder" to "Choose folder",
    "default_folder" to "App default folder", "fmt" to "Coordinate type", "sel_mode" to "Rectangle type",
    "center_size" to "Center + size", "two_corners" to "Two corners",
    "width" to "Width (m)", "height" to "Height (m)", "sound" to "Button sounds & haptics",
    "map_type" to "Map type", "mt_std" to "Standard", "mt_topo" to "Topographic", "mt_sat" to "Satellite",
    "convert" to "Convert", "lat" to "Latitude", "lon" to "Longitude",
    "zone" to "Zone (e.g. 38N)", "easting" to "X (easting)", "northing" to "Y (northing)", "mgrs" to "MGRS",
    "copy" to "Copy", "invalid" to "Invalid value", "meridian" to "Meridian", "parallel" to "Parallel",
    "export" to "Export", "share" to "Share files", "fetching" to "Downloading features…",
    "saved" to "Saved", "tap_center" to "Tap the map to place the rectangle",
    "tap_corners" to "Tap the map for the first corner", "pick_second" to "Tap the second corner",
    "drag_hint" to "Drag the rectangle to move it, drag corners to resize",
    "too_big" to "Area too large (max 100 km)", "none_found" to "No features found in the area",
    "features" to "Features", "none_selected" to "Nothing selected to export",
    "roads_main" to "Main roads", "roads_sec" to "Secondary roads", "lakes" to "Lakes",
    "rivers" to "Rivers", "dams" to "Dams", "tourist" to "Tourist landmarks", "admin" to "Administrative borders",
    "categories" to "Layers", "search_hint" to "Search a place…", "preview" to "Preview features",
    "back_edit" to "Edit area", "formats" to "Export formats",
    "f_shp" to "Shapefile", "f_xlsx" to "Excel", "f_kml" to "KML", "f_kmz" to "KMZ"
)

fun tr(lang: String, k: String): String = (if (lang == "ar") ar else en)[k] ?: k
